from __future__ import annotations

import contextlib
import http.server
import socketserver
import tempfile
import threading
import unittest
from pathlib import Path

from media_collector_core import download_plan
from source_adapters import build_adapter_plan


PNG = (
    b"\x89PNG\r\n\x1a\n"
    b"\x00\x00\x00\rIHDR"
    b"\x00\x00\x00\x01\x00\x00\x00\x01"
    b"\x08\x02\x00\x00\x00"
    b"\x90wS\xde"
)
JPEG = b"\xff\xd8\xff\xe0" + b"jpeg-data"
MP4 = b"\x00\x00\x00\x18ftypisom" + b"\x00" * 20


class FixtureHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_GET(self):
        if self.path == "/a.png":
            body = PNG
            content_type = "image/png"
            declared = len(body)
        elif self.path == "/b.png":
            body = PNG
            content_type = "image/png"
            declared = len(body)
        elif self.path == "/fake.png":
            body = b"<html>not an image</html>"
            content_type = "image/png"
            declared = len(body)
        elif self.path == "/video.mp4":
            body = MP4
            content_type = "video/mp4"
            declared = len(body)
        elif self.path == "/large.jpg":
            body = JPEG
            content_type = "image/jpeg"
            declared = 9999
        else:
            self.send_response(404)
            self.end_headers()
            return

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(declared))
        self.end_headers()
        self.wfile.write(body)


@contextlib.contextmanager
def fixture_server():
    server = socketserver.TCPServer(("127.0.0.1", 0), FixtureHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server.server_address[1]
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


class Phase4IntegrationTests(unittest.TestCase):
    def test_local_http_download_pipeline(self):
        with fixture_server() as port, tempfile.TemporaryDirectory() as temp:
            base = f"http://127.0.0.1:{port}"
            plan = build_adapter_plan(
                [
                    f"{base}/a.png",
                    f"{base}/b.png",
                    f"{base}/fake.png",
                    f"{base}/video.mp4",
                    f"{base}/large.jpg",
                ]
            )
            results = download_plan(plan, Path(temp), max_bytes=100)

            self.assertEqual(
                [row.status for row in results],
                ["saved", "duplicate-content", "error", "skipped", "error"],
            )
            self.assertIn("signature", results[2].error)
            self.assertIn("disabled", results[3].error)
            self.assertIn("exceeds limit", results[4].error)

            saved = [p for p in Path(temp).iterdir() if p.suffix == ".png"]
            self.assertEqual(len(saved), 1)

    def test_existing_file_hash_prevents_same_run_duplicate(self):
        with fixture_server() as port, tempfile.TemporaryDirectory() as temp:
            base = f"http://127.0.0.1:{port}"
            plan = build_adapter_plan([f"{base}/a.png", f"{base}/b.png"])

            first = download_plan(plan, Path(temp), max_bytes=1024)
            self.assertEqual(
                [row.status for row in first],
                ["saved", "duplicate-content"],
            )

            second = download_plan(plan, Path(temp), max_bytes=1024)
            self.assertEqual(second[0].status, "exists")
            self.assertEqual(second[1].status, "duplicate-content")
            self.assertEqual(second[0].sha256, second[1].sha256)


if __name__ == "__main__":
    unittest.main()
