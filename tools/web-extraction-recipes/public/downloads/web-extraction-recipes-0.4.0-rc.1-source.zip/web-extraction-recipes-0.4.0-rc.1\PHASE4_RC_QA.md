# Phase 4 Release Candidate QA

Date: 2026-09-25
Version: `0.4.0-rc.1`

## Candidate gates

- required release files: PASS
- Python compile: PASS
- unit/regression tests: 28 / 28 PASS
- ResourceWarning promoted to error: PASS
- secret scan: PASS
- Cookie / Authorization header scan: PASS
- browser automation scan: PASS
- site-specific runtime scan: PASS
- formal Phase 3 screenshot SHA-256: PASS
- git diff check: PASS

## Distribution verification

A source ZIP was built from the repository and extracted into a separate temporary directory.
The extracted package was checked without relying on the repository `.git` directory.

- `.git` excluded: PASS
- `__pycache__` / `.pyc` excluded: PASS
- nested `dist` excluded: PASS
- extracted-package preflight: PASS
- extracted-package tests: 28 / 28 PASS

## Release boundary

The Release Candidate retains the Phase 3 safety defaults:

- HTTP/HTTPS only
- embedded credentials rejected
- private/local targets blocked by default
- same-origin enabled by default
- robots.txt respected by default
- 1 second default request delay
- retry and max-pages guards
- HTML/XHTML only, maximum 4 MiB per response
- no Cookie or Authorization injection
- no browser profile or login-session reuse
- no CAPTCHA, paywall, DRM, or access-control bypass logic

The canonical release-asset SHA-256 is published beside the ZIP as a `.sha256` asset.
