from __future__ import annotations

import http.server
import json
import threading
import unittest

from crawl_core import (
    CrawlRecipe,
    Fetcher,
    HttpPolicy,
    crawl,
    crawl_recipe_from_dict,
    normalize_http_url,
    same_origin,
)
from extraction_core import ExtractionError


class FixtureHandler(http.server.BaseHTTPRequestHandler):
    flaky_count = 0
    saw_cookie = False
    saw_authorization = False

    def log_message(self, format, *args):
        pass

    def _html(self, body: str, status: int = 200) -> None:
        raw = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        port = self.server.server_address[1]
        if self.headers.get("Cookie"):
            type(self).saw_cookie = True
        if self.headers.get("Authorization"):
            type(self).saw_authorization = True

        if self.path == "/robots.txt":
            raw = b"User-agent: *\nDisallow: /blocked\n"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            return

        if self.path == "/list-a":
            self._html(f"""
            <article class="card"><a class="detail" href="/detail/1">One</a></article>
            <article class="card"><a class="detail" href="/detail/2">Two</a></article>
            <article class="card"><a class="detail" href="/detail/2">Two again</a></article>
            <article class="card"><a class="detail" href="/blocked">Blocked</a></article>
            <article class="card"><a class="detail" href="http://localhost:{port}/detail/external">Other host spelling</a></article>
            """)
            return

        if self.path == "/list-b":
            self._html("""
            <article class="card"><a class="detail" href="/detail/2">Two</a></article>
            <article class="card"><a class="detail" href="/flaky">Flaky</a></article>
            """)
            return

        if self.path == "/detail/1":
            self._html('<main class="detail" data-item-id="one"><h1>First Detail</h1></main>')
            return

        if self.path == "/detail/2":
            self._html('<main class="detail" data-item-id="two"><h1>Second Detail</h1></main>')
            return

        if self.path == "/flaky":
            type(self).flaky_count += 1
            if type(self).flaky_count == 1:
                self._html("temporary", status=500)
            else:
                self._html('<main class="detail" data-item-id="retry"><h1>Retry Detail</h1></main>')
            return

        if self.path == "/blocked":
            self._html('<main class="detail"><h1>Should not fetch</h1></main>')
            return

        if self.path == "/xhtml":
            raw = "<html><body>日本語</body></html>".encode("cp932")
            self.send_response(200)
            self.send_header(
                "Content-Type",
                "application/xhtml+xml; charset=cp932",
            )
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            return

        if self.path == "/redirect-other":
            self.send_response(302)
            self.send_header(
                "Location",
                f"http://localhost:{port}/detail/1",
            )
            self.end_headers()
            return

        if self.path == "/plain":
            raw = b"plain text"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            return

        self.send_error(404)


class LocalServer:
    def __enter__(self):
        FixtureHandler.flaky_count = 0
        FixtureHandler.saw_cookie = False
        FixtureHandler.saw_authorization = False
        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), FixtureHandler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        port = self.server.server_address[1]
        return f"http://127.0.0.1:{port}"

    def __exit__(self, exc_type, exc, tb):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)


def recipe_dict(delay: float = 0.0) -> dict:
    return {
        "name": "Fixture crawl",
        "link_selector": "article.card a.detail[href]",
        "link_attr": "href",
        "http": {
            "delay_seconds": delay,
            "timeout_seconds": 5,
            "max_retries": 2,
            "max_pages": 20,
            "same_origin": True,
            "respect_robots": True,
            "allow_private_hosts": True,
            "user_agent": "WebExtractionRecipesTest/1.0",
        },
        "detail_recipe": {
            "name": "Fixture detail",
            "row_selector": "main.detail",
            "fields": [
                {"name": "title", "selector": "h1", "source": "text"},
                {
                    "name": "item_id",
                    "selector": "",
                    "source": "attr",
                    "attr": "data-item-id",
                },
            ],
        },
    }


class UrlPolicyTests(unittest.TestCase):
    def test_http_url_normalization(self):
        self.assertEqual(
            normalize_http_url("HTTPS://Example.COM/a#frag"),
            "https://example.com/a",
        )

    def test_embedded_credentials_rejected(self):
        with self.assertRaises(ExtractionError):
            normalize_http_url("https://user:pass@example.com/a")

    def test_same_origin(self):
        self.assertTrue(same_origin("https://example.com/a", "https://example.com/b"))
        self.assertFalse(same_origin("https://example.com/a", "http://example.com/b"))

    def test_private_host_blocked_by_default(self):
        policy = HttpPolicy(respect_robots=False)
        fetcher = Fetcher(policy)
        from crawl_core import CrawlStats
        stats = CrawlStats()
        with self.assertRaises(ExtractionError):
            fetcher.fetch("http://127.0.0.1/test", stats)


class CrawlRecipeTests(unittest.TestCase):
    def test_parse_policy(self):
        recipe = crawl_recipe_from_dict(recipe_dict())
        self.assertEqual(recipe.name, "Fixture crawl")
        self.assertTrue(recipe.policy.same_origin)
        self.assertTrue(recipe.policy.respect_robots)
        self.assertTrue(recipe.policy.allow_private_hosts)
        self.assertEqual(recipe.policy.max_retries, 2)


class CrawlIntegrationTests(unittest.TestCase):
    def test_list_to_detail_retry_robots_and_dedup(self):
        with LocalServer() as base:
            recipe = crawl_recipe_from_dict(recipe_dict())
            result = crawl([base + "/list-a", base + "/list-b"], recipe)

        rows = list(result.records)
        self.assertEqual(
            [row["item_id"] for row in rows],
            ["one", "two", "two", "retry"],
        )
        self.assertEqual(result.stats.unique_detail_links, 4)
        self.assertEqual(result.stats.skipped_cross_origin, 1)
        self.assertEqual(result.stats.skipped_robots, 1)
        self.assertEqual(FixtureHandler.flaky_count, 2)
        self.assertEqual(result.stats.fetched_pages, 5)
        self.assertEqual(result.stats.cache_hits, 1)
        self.assertNotEqual(rows[1]["source_url"], rows[2]["source_url"])
        self.assertTrue(all("source_url" in row for row in rows))
        self.assertTrue(all("detail_url" in row for row in rows))
        self.assertFalse(FixtureHandler.saw_cookie)
        self.assertFalse(FixtureHandler.saw_authorization)

    def test_fetcher_cache(self):
        with LocalServer() as base:
            policy = crawl_recipe_from_dict(recipe_dict()).policy
            fetcher = Fetcher(policy)
            from crawl_core import CrawlStats
            stats = CrawlStats()
            first = fetcher.fetch(base + "/detail/1", stats)
            second = fetcher.fetch(base + "/detail/1", stats)

        self.assertEqual(first, second)
        self.assertEqual(stats.fetched_pages, 1)
        self.assertEqual(stats.cache_hits, 1)

    def test_non_html_rejected(self):
        with LocalServer() as base:
            policy = crawl_recipe_from_dict(recipe_dict()).policy
            fetcher = Fetcher(policy)
            from crawl_core import CrawlStats
            stats = CrawlStats()
            with self.assertRaises(ExtractionError):
                fetcher.fetch(base + "/plain", stats)

    def test_cross_origin_redirect_rejected(self):
        with LocalServer() as base:
            policy = crawl_recipe_from_dict(recipe_dict()).policy
            fetcher = Fetcher(policy)
            from crawl_core import CrawlStats
            stats = CrawlStats()
            with self.assertRaises(ExtractionError):
                fetcher.fetch(base + "/redirect-other", stats)

    def test_xhtml_charset_is_supported(self):
        with LocalServer() as base:
            policy = crawl_recipe_from_dict(recipe_dict()).policy
            fetcher = Fetcher(policy)
            from crawl_core import CrawlStats
            stats = CrawlStats()
            text = fetcher.fetch(base + "/xhtml", stats)
        self.assertIn("日本語", text)

    def test_max_pages_stops_detail_fetches(self):
        data = recipe_dict()
        data["http"]["max_pages"] = 1
        recipe = crawl_recipe_from_dict(data)
        with LocalServer() as base:
            result = crawl([base + "/list-a"], recipe)
        self.assertEqual(result.stats.fetched_pages, 1)
        self.assertEqual(len(result.records), 0)
        self.assertTrue(
            any("maximum fetched page limit" in item for item in result.stats.errors)
        )


if __name__ == "__main__":
    unittest.main()