from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from video_workbench_core import (
    _prepare_output_file,
    default_frame_dir,
    default_trim_path,
    parse_time,
)


class CoreValidationTests(unittest.TestCase):
    def test_seconds(self) -> None:
        self.assertEqual(parse_time("12.5"), 12.5)

    def test_mm_ss(self) -> None:
        self.assertEqual(parse_time("1:23.5"), 83.5)

    def test_hh_mm_ss(self) -> None:
        self.assertEqual(parse_time("01:02:03.25"), 3723.25)
    def test_negative_rejected(self) -> None:
        with self.assertRaises(ValueError):
            parse_time("-1")

    def test_invalid_seconds_component_rejected(self) -> None:
        with self.assertRaises(ValueError):
            parse_time("00:61")

    def test_fast_trim_keeps_extension(self) -> None:
        source = Path("sample.mkv")
        target = default_trim_path(source, "1", "2", precise=False)
        self.assertEqual(target.suffix, ".mkv")
        self.assertIn("_fast", target.stem)

    def test_precise_trim_defaults_to_mp4(self) -> None:
        source = Path("sample.webm")
        target = default_trim_path(source, "1", "2", precise=True)
        self.assertEqual(target.suffix, ".mp4")
        self.assertIn("_precise", target.stem)

    def test_frame_dir_contains_fps(self) -> None:
        source = Path("sample.mp4")
        target = default_frame_dir(source, "png", 2.5)
        self.assertIn("2p5fps_png", target.name)
    def test_input_cannot_be_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "sample.mp4"
            source.write_bytes(b"x")
            with self.assertRaises(ValueError):
                _prepare_output_file(source.resolve(), source, overwrite=False)


if __name__ == "__main__":
    unittest.main()
