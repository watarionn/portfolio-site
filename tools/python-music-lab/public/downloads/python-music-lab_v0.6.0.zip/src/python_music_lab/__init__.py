"""Python作曲研究所 core package."""
