# Origin

Video Workbench consolidates two earlier personal utilities:

- video trimming
- video frame export

The original utilities were reviewed before consolidation. The new implementation keeps their useful roles while replacing unsafe or ambiguous behavior around invalid time ranges, FPS values, overwrite handling, FFmpeg interactivity, path handling and output verification.

The current product intentionally stays narrow. It is a workbench for cutting a range from a video and exporting frames, not a general-purpose nonlinear video editor.
