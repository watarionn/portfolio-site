# Changelog

## 0.4.0 - 2026-09-24

First portfolio-ready Video Workbench release candidate.

- unified the previous trim and frame-export tools into one GUI
- added Fast Cut and Precise Cut as explicit modes
- added ffprobe metadata inspection
- added PNG/JPG frame export with all-frame or FPS modes
- added overwrite guards and output verification
- added Japanese/space path support
- added live trim-duration and frame-count estimates
- added contextual control states and one-click trim endpoints
- added automated unit, UI-logic and real-FFmpeg smoke tests
- added preflight and reproducible source-package tooling
