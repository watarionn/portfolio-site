from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app import MediaCollectorApp, build_plan_for_ui, format_bytes, summarize_plan
from media_collector_core import DownloadResult


class AppLogicTests(unittest.TestCase):
    def test_build_plan_for_ui_reports_duplicates(self) -> None:
        text = "\n".join(
            [
                "https://pbs.twimg.com/media/A?format=jpg&name=small",
                "https://pbs.twimg.com/media/A?format=jpg&name=orig",
                "https://example.com/b.png",
            ]
        )
        plan, duplicates = build_plan_for_ui(text, "自動判定")
        self.assertEqual(len(plan), 2)
        self.assertEqual(duplicates, 1)

    def test_source_choice_can_force_generic(self) -> None:
        plan, _ = build_plan_for_ui(
            "https://example.com/a.jpg",
            "Generic URL",
        )
        self.assertEqual(plan[0].source, "generic")

    def test_source_choice_can_force_pixiv(self) -> None:
        plan, _ = build_plan_for_ui(
            "https://i.pximg.net/img-original/img/2026/09/24/00/00/00/123_p0.jpg?cache=1",
            "Pixiv media",
        )
        self.assertEqual(plan[0].source, "pixiv")
        self.assertEqual(plan[0].media_id, "123_p0")
        self.assertNotIn("?", plan[0].normalized_url)

    def test_summary_counts(self) -> None:
        plan, duplicates = build_plan_for_ui(
            "\n".join(
                [
                    "https://example.com/a.jpg",
                    "https://example.com/b.mp4",
                    "https://example.com/c.bin",
                ]
            ),
            "自動判定",
        )
        summary = summarize_plan(plan, duplicates)
        self.assertEqual(summary["unique"], "3")
        self.assertEqual(summary["images"], "1")
        self.assertEqual(summary["videos"], "1")
        self.assertEqual(summary["unknown"], "1")

    def test_gui_renders_plan(self) -> None:
        app = MediaCollectorApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app.input_text.insert(
            "1.0",
            "https://pbs.twimg.com/media/A?format=png&name=small\n"
            "https://example.com/photo.webp",
        )
        app.build_plan()
        self.assertEqual(len(app.current_plan), 2)
        self.assertEqual(len(app.plan_tree.get_children()), 2)
        self.assertEqual(app.summary_vars["images"].get(), "2")
        preview = app.manifest_text.get("1.0", "end")
        self.assertIn("name=orig", preview)

    def test_plan_display_redacts_sensitive_query_values(self) -> None:
        app = MediaCollectorApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app.input_text.insert(
            "1.0",
            "https://example.com/a.jpg?token=super-secret&safe=yes",
        )
        app.build_plan()
        row = app.plan_tree.item(app.plan_tree.get_children()[0], "values")
        self.assertNotIn("super-secret", row[-1])
        self.assertIn("REDACTED", row[-1])
        preview = app.manifest_text.get("1.0", "end")
        self.assertNotIn("super-secret", preview)
        self.assertIn("REDACTED", preview)

    def test_clear_input_resets_plan(self) -> None:
        app = MediaCollectorApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app.input_text.insert("1.0", "https://example.com/a.jpg")
        app.build_plan()
        self.assertEqual(len(app.current_plan), 1)
        app.clear_input()
        self.assertEqual(app.current_plan, [])
        self.assertEqual(app.summary_vars["unique"].get(), "0")

    def test_invalid_max_size_rejected(self) -> None:
        app = MediaCollectorApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app.max_mib_var.set("0")
        with self.assertRaises(ValueError):
            app._validate_max_bytes()
        app.max_mib_var.set("abc")
        with self.assertRaises(ValueError):
            app._validate_max_bytes()

    def test_format_bytes(self) -> None:
        self.assertEqual(format_bytes(0), "0 B")
        self.assertEqual(format_bytes(1024), "1.0 KiB")
        self.assertEqual(format_bytes(1024 * 1024), "1.0 MiB")

    def test_download_results_table_renders(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            app = MediaCollectorApp()
            app.withdraw()
            self.addCleanup(app.destroy)
            result = DownloadResult(
                source="generic",
                normalized_url="https://example.com/a.jpg?token=secret",
                filename="generic_000001_a.jpg",
                status="saved",
                size_bytes=2048,
                sha256="a" * 64,
            )
            app._download_finished([result], Path(temp))
            rows = app.results_tree.get_children()
            self.assertEqual(len(rows), 1)
            values = app.results_tree.item(rows[0], "values")
            self.assertEqual(values[0], "saved")
            self.assertEqual(values[2], "generic_000001_a.jpg")
            self.assertEqual(values[3], "2.0 KiB")
            self.assertNotIn("secret", values[-1])
            self.assertIn("REDACTED", values[-1])

    def test_output_dir_resolves(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            app = MediaCollectorApp()
            app.withdraw()
            self.addCleanup(app.destroy)
            app.output_var.set(temp)
            self.assertEqual(app._output_dir(), Path(temp).resolve())


if __name__ == "__main__":
    unittest.main()
