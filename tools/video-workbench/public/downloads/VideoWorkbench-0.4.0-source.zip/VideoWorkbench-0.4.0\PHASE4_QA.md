# Phase 4 QA

Date: 2026-09-24
Version: 0.4.0

## Packaging scope

- added an explicit VERSION file
- added CHANGELOG.md
- added environment preflight checks
- launcher now runs preflight before opening the GUI
- added a reproducible source-package build script
- added origin/provenance documentation
- dist output is excluded from Git

## Preflight

Environment used for the release candidate:

- Python: 3.14.5
- Tkinter: 8.6
- ffmpeg: 2026-06-04 git c27a3b12e3 essentials build
- ffprobe: 2026-06-04 git c27a3b12e3 essentials build
- preflight: PASS

## Regression

- unit/UI logic tests: 12 / 12 PASS
- real FFmpeg smoke: PASS
- precise trim 1.0 -> 3.0 sec: 2.000 sec
- fast copy trim 1.0 -> 3.0 sec: 2.167 sec
- PNG 2 fps: 8 frames
- JPG 1 fps: 4 frames
- Unicode and spaces path: PASS

## Release artifact

File: VideoWorkbench-0.4.0-source.zip
SHA-256: F98EE79448D9E50A600F818431D9193BA8AC35AAFB50680E1C82B3E9C75C6BE8

The source archive is reproducible from build_release.ps1 and is not committed to Git.
