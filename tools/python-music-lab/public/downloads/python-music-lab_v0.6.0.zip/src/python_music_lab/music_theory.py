from __future__ import annotations

NOTE_TO_PC = {
    "C": 0,
    "C#": 1,
    "Db": 1,
    "D": 2,
    "D#": 3,
    "Eb": 3,
    "E": 4,
    "F": 5,
    "F#": 6,
    "Gb": 6,
    "G": 7,
    "G#": 8,
    "Ab": 8,
    "A": 9,
    "A#": 10,
    "Bb": 10,
    "B": 11,
}

MAJOR_SCALE = (0, 2, 4, 5, 7, 9, 11)
NATURAL_MINOR_SCALE = (0, 2, 3, 5, 7, 8, 10)

MAJOR_DEGREE_INDEX = {
    "I": 0,
    "ii": 1,
    "iii": 2,
    "IV": 3,
    "V": 4,
    "vi": 5,
    "vii°": 6,
}

MINOR_DEGREE_INDEX = {
    "i": 0,
    "ii°": 1,
    "III": 2,
    "iv": 3,
    "v": 4,
    "V": 4,  # harmonic-minor dominant, handled specially below
    "VI": 5,
    "VII": 6,
}

# Backward-compatible alias used by Phase 01/02A.
DEGREE_INDEX = MAJOR_DEGREE_INDEX


def normalize_mode(mode: str) -> str:
    value = mode.lower().strip()
    if value in {"minor", "natural_minor", "natural minor"}:
        return "minor"
    if value == "major":
        return "major"
    raise ValueError(f"Unsupported mode: {mode}")


def supported_degrees(mode: str) -> set[str]:
    mode = normalize_mode(mode)
    if mode == "major":
        return set(MAJOR_DEGREE_INDEX)
    return set(MINOR_DEGREE_INDEX)


def scale_midi(root: str, mode: str = "major", octave: int = 4) -> list[int]:
    if root not in NOTE_TO_PC:
        raise ValueError(f"Unsupported key root: {root}")
    mode = normalize_mode(mode)
    intervals = MAJOR_SCALE if mode == "major" else NATURAL_MINOR_SCALE
    root_midi = 12 * (octave + 1) + NOTE_TO_PC[root]
    return [root_midi + interval for interval in intervals]


def major_scale_midi(root: str, octave: int = 4) -> list[int]:
    """Backward-compatible major-scale helper."""
    return scale_midi(root, "major", octave)


def diatonic_triad(root: str, degree: str, octave: int = 4, mode: str = "major") -> list[int]:
    """Build a diatonic triad for major or natural minor.

    In minor mode, uppercase V is interpreted as a harmonic-minor dominant,
    raising the chord third by one semitone. Lowercase v remains natural minor.
    """
    mode = normalize_mode(mode)
    degree_map = MAJOR_DEGREE_INDEX if mode == "major" else MINOR_DEGREE_INDEX
    if degree not in degree_map:
        raise ValueError(f"Unsupported degree {degree!r} for mode {mode!r}")

    scale = scale_midi(root, mode, octave)
    idx = degree_map[degree]
    extended = scale + [n + 12 for n in scale] + [n + 24 for n in scale]
    triad = [extended[idx], extended[idx + 2], extended[idx + 4]]

    # A strong dominant cadence in minor benefits from a raised leading tone.
    if mode == "minor" and degree == "V":
        triad[1] += 1
    return triad
