from __future__ import annotations

import hashlib
import json
from pathlib import Path

from python_music_lab.midi_writer import write_song
from python_music_lab.structured_composer import (
    compose_structured_song,
    load_structured_config,
    section_markers,
)


TRACK_SPECS = [
    ("Melody", 0, 0),
    ("Chords", 4, 1),
    ("Bass", 33, 2),
    ("Drums", 0, 9),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    config_path = project_root / "config" / "phase02_song.json"
    output_dir = project_root / "output" / "phase02"
    output_path = output_dir / "structured_song.mid"
    manifest_path = output_dir / "manifest.json"

    config = load_structured_config(config_path)
    song, motif = compose_structured_song(config)
    tracks = [(name, song[name], program, channel) for name, program, channel in TRACK_SPECS]

    write_song(
        output_path=output_path,
        bpm=config.bpm,
        ticks_per_beat=config.ticks_per_beat,
        tracks=tracks,
        markers=section_markers(config),
    )

    section_data = []
    start_bar = 1
    for section in config.sections:
        section_data.append(
            {
                "name": section.name,
                "start_bar": start_bar,
                "bars": section.bars,
                "progression": section.progression,
                "melody_density": section.melody_density,
                "register_shift": section.register_shift,
                "energy": section.energy,
            }
        )
        start_bar += section.bars

    duration_seconds = config.total_bars * 4 * 60.0 / config.bpm
    manifest = {
        "schema_version": 2,
        "generator": "Python Music Lab Phase 02",
        "title": config.title,
        "seed": config.seed,
        "bpm": config.bpm,
        "key": f"{config.key_root} {config.mode}",
        "bars": config.total_bars,
        "duration_seconds": round(duration_seconds, 3),
        "sections": section_data,
        "motif": [
            {"scale_offset": step.scale_offset, "duration_steps": step.duration_steps}
            for step in motif
        ],
        "note_counts": {name: len(song[name]) for name, _, _ in TRACK_SPECS},
        "midi_file": output_path.name,
        "sha256": sha256(output_path),
        "portfolio_ready": True,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"Title     : {config.title}")
    print(f"Structure : {' -> '.join(section.name for section in config.sections)}")
    print(f"Bars      : {config.total_bars}")
    print(f"BPM / Key : {config.bpm} / {config.key_root} {config.mode}")
    print(f"Seed      : {config.seed}")
    print(f"MIDI      : {output_path}")
    print(f"Manifest  : {manifest_path}")
    print(f"SHA256    : {manifest['sha256']}")


if __name__ == "__main__":
    main()
