(() => {
  "use strict";
  const normalize = (raw) => {
    try {
      const url = new URL(raw, location.href);
      if (url.hostname !== "pbs.twimg.com" || !url.pathname.startsWith("/media/")) return null;
      let format = (url.searchParams.get("format") || "").toLowerCase();
      const old = url.pathname.match(/\.([a-zA-Z0-9]+)(?::[^/]*)?$/);
      if (!format && old) format = old[1].toLowerCase();
      let path = url.pathname.replace(/:(?:orig|large|medium|small)$/i, "");
      if (format) path = path.replace(new RegExp("\\." + format + "$", "i"), "");
      const out = new URL("https://pbs.twimg.com");
      out.pathname = path;
      out.searchParams.set("format", format || "jpg");
      out.searchParams.set("name", "orig");
      return out.href;
    } catch (_) { return null; }
  };
  const found = new Set();
  for (const image of document.querySelectorAll("img")) {
    for (const raw of [image.currentSrc, image.src, image.getAttribute("src")]) {
      const normalized = raw && normalize(raw);
      if (normalized) found.add(normalized);
    }
  }
  const urls = [...found].sort();
  const text = urls.join("\n") + (urls.length ? "\n" : "");
  console.log("[Media Collector / X] " + urls.length + " media URL(s)");
  console.log(text);
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).catch(() => {});
  }
  return urls;
})();
