from __future__ import annotations

import argparse
from pathlib import Path

from media_collector_core import (
    DEFAULT_MAX_BYTES,
    download_plan,
    extract_urls,
    write_download_manifest,
    write_plan_manifest,
)
from source_adapters import build_adapter_plan


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Normalize, deduplicate and optionally download user-supplied media URLs."
    )
    parser.add_argument("input", type=Path, help="Text/TSV/CSV file containing URLs")
    parser.add_argument("-o", "--output", type=Path, default=Path("collected"))
    parser.add_argument(
        "--source",
        choices=("auto", "x", "pixiv", "generic"),
        default="auto",
        help="Source adapter hint. Default: auto",
    )
    parser.add_argument(
        "--download",
        action="store_true",
        help="Download supported direct media URLs after building the plan",
    )
    parser.add_argument(
        "--allow-videos",
        action="store_true",
        help="Allow direct video downloads. Disabled by default.",
    )
    parser.add_argument(
        "--max-mib",
        type=float,
        default=DEFAULT_MAX_BYTES / (1024 * 1024),
        help="Maximum size per downloaded item in MiB",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow replacing an existing generated filename",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.max_mib <= 0:
        raise SystemExit("--max-mib must be positive")
    if not args.input.is_file():
        raise SystemExit(f"input file not found: {args.input}")

    text = args.input.read_text(encoding="utf-8-sig", errors="replace")
    plan = build_adapter_plan(
        extract_urls(text),
        adapter=args.source,
    )
    plan_json, plan_tsv = write_plan_manifest(plan, args.output)

    print(f"Media Collector plan: {len(plan)} unique URL(s)")
    print(f"Plan JSON: {plan_json}")
    print(f"Plan TSV : {plan_tsv}")

    if not args.download:
        print("Plan-only mode. No network download was performed.")
        return 0

    results = download_plan(
        plan,
        args.output,
        allow_videos=args.allow_videos,
        max_bytes=int(args.max_mib * 1024 * 1024),
        overwrite=args.overwrite,
    )
    result_json, result_tsv = write_download_manifest(results, args.output)
    saved = sum(row.status == "saved" for row in results)
    errors = sum(row.status == "error" for row in results)
    skipped = len(results) - saved - errors

    print(f"Saved: {saved} / Errors: {errors} / Other: {skipped}")
    print(f"Result JSON: {result_json}")
    print(f"Result TSV : {result_tsv}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
