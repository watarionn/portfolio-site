# Phase 4 QA

Date: 2026-09-24
Version: 0.4.0 Release Candidate

## Goal

Close the product-quality and distribution boundary for Media Collector before public release.

## Runtime safety improvements

- supported media types are checked by Content-Type
- supported media types are also checked by file signature
- empty media responses are rejected
- per-file byte limit is checked before and during transfer
- existing output files contribute their SHA-256 to same-run duplicate detection
- signed/sensitive URL query values are redacted in manifests and parsed GUI result views
- video downloads remain disabled by default

## Local HTTP integration QA

A controlled localhost HTTP server was used to exercise the real urllib download pipeline.

Verified:
- valid PNG saves successfully
- same-content second URL is suppressed
- mislabeled HTML served as image/png is rejected by signature check
- direct MP4 is skipped while videos are disabled
- declared oversized JPEG is rejected before body processing
- rerunning with an existing first file still prevents a same-content second URL

## GUI polish

- Download Results tab added
- status, source, output filename, human-readable size, SHA-256 prefix and detail are visible in one table
- sensitive URL query values remain redacted in the results table

## Automated QA

- Python: 3.14.5
- Tkinter: 8.6
- Tk GUI availability: PASS
- preflight: PASS
- Python compile: PASS
- Phase 1–4 tests: 39 / 39 PASS
- Bridge JavaScript syntax: PASS
- Bridge credential-access static scan: PASS
- repository secret scan: PASS
- CLI plan-only smoke: PASS
- manifest sensitive-query redaction: PASS
- git diff check: PASS

## Visual QA

- real application screenshot: `qa/screenshots/phase4-main.png`
- direct target-window capture using PrintWindow
- screenshot size: 1216 x 839
- Download Results shows saved / duplicate-content / skipped / error examples
- no taskbar or overlapping application window

## Distribution

- preflight.py validates Python, Tkinter and required project files
- run_media_collector.bat runs preflight before the GUI
- build_release.ps1 generates a clean source release package
- no third-party Python packages are required for the application runtime
- Browser Bridges are plain JavaScript intended for manual execution in a browser page console

## Extracted-package verification

The generated source ZIP was expanded into a separate temporary directory and tested from there.

- package preflight: PASS
- package unit/integration tests: 39 / 39 PASS
- packaged X Bridge syntax: PASS
- packaged Pixiv Bridge syntax: PASS
- packaged Generic DOM Bridge syntax: PASS

This verifies that the release package does not depend on unlisted files in the development working tree.
