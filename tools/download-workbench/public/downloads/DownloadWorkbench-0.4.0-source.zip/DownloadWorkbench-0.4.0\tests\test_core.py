from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from download_workbench_core import (
    DownloadRequest,
    DownloadWorkbenchError,
    build_analyze_args,
    build_download_args,
    format_command_preview,
    format_timecode,
    media_info_from_json,
    parse_timecode,
    redact_url,
    validate_http_url,
)


class UrlSafetyTests(unittest.TestCase):
    def test_http_url_is_accepted(self) -> None:
        self.assertEqual(
            validate_http_url("https://example.com/watch?v=1"),
            "https://example.com/watch?v=1",
        )

    def test_non_http_url_is_rejected(self) -> None:
        with self.assertRaises(DownloadWorkbenchError):
            validate_http_url("file:///C:/secret.txt")

    def test_embedded_credentials_are_rejected(self) -> None:
        with self.assertRaises(DownloadWorkbenchError):
            validate_http_url("https://user:pass@example.com/video")

    def test_redact_url(self) -> None:
        value = redact_url(
            "https://Example.com/a?token=secret&safe=1&X-Amz-Signature=abc#frag"
        )
        self.assertNotIn("secret", value)
        self.assertNotIn("abc", value)
        self.assertIn("token=REDACTED", value)
        self.assertIn("safe=1", value)


class TimecodeTests(unittest.TestCase):
    def test_seconds(self) -> None:
        self.assertEqual(parse_timecode("90.5"), 90.5)

    def test_mm_ss(self) -> None:
        self.assertEqual(parse_timecode("01:30"), 90)

    def test_hh_mm_ss(self) -> None:
        self.assertEqual(parse_timecode("01:02:03"), 3723)

    def test_format_timecode(self) -> None:
        self.assertEqual(format_timecode(3723), "01:02:03")

    def test_invalid_component(self) -> None:
        with self.assertRaises(ValueError):
            parse_timecode("00:61")


class AnalyzeCommandTests(unittest.TestCase):
    def test_analyze_command_ignores_user_config(self) -> None:
        args = build_analyze_args("https://example.com/video")
        self.assertIn("--ignore-config", args)
        self.assertIn("--skip-download", args)
        self.assertIn("--no-playlist", args)
        self.assertEqual(args[-2:], ["--", "https://example.com/video"])


class CommandPreviewTests(unittest.TestCase):
    def test_preview_keeps_argument_boundaries(self) -> None:
        preview = format_command_preview(
            ["tool", r"C:\path with space\output", "https://example.com/video"]
        )
        self.assertIn("path with space", preview)
        self.assertIn("https://example.com/video", preview)


class MediaInfoTests(unittest.TestCase):
    def test_media_info_parses_formats_and_subtitles(self) -> None:
        data = {
            "id": "abc",
            "title": "Demo",
            "uploader": "Tester",
            "duration": 12.5,
            "webpage_url": "https://example.com/watch/abc",
            "extractor_key": "Generic",
            "formats": [
                {
                    "format_id": "137",
                    "ext": "mp4",
                    "width": 1920,
                    "height": 1080,
                    "fps": 30,
                    "vcodec": "avc1",
                    "acodec": "none",
                    "filesize": 1000,
                    "protocol": "https",
                },
                {
                    "format_id": "140",
                    "ext": "m4a",
                    "vcodec": "none",
                    "acodec": "mp4a",
                    "filesize_approx": 200,
                },
            ],
            "subtitles": {"ja": [{"ext": "vtt"}]},
            "automatic_captions": {"en": [{"ext": "vtt"}]},
        }
        info = media_info_from_json(data, "https://example.com/watch/abc")
        self.assertEqual(info.title, "Demo")
        self.assertEqual(len(info.formats), 2)
        self.assertEqual(info.formats[0].resolution, "1920x1080")
        self.assertEqual(info.formats[1].resolution, "audio only")
        self.assertEqual(len(info.subtitles), 2)
        self.assertFalse(info.subtitles[0].automatic)
        self.assertTrue(info.subtitles[1].automatic)


class DownloadCommandTests(unittest.TestCase):
    def test_video_command(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            request = DownloadRequest(
                url="https://example.com/video",
                output_dir=Path(temp),
            )
            args = build_download_args(request)
            self.assertIn("--ignore-config", args)
            self.assertIn("bv*+ba/b", args)
            self.assertIn("--merge-output-format", args)
            self.assertIn("--no-overwrites", args)

    def test_audio_command(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            request = DownloadRequest(
                url="https://example.com/video",
                output_dir=Path(temp),
                mode="audio",
                audio_format="mp3",
            )
            args = build_download_args(request)
            self.assertIn("-x", args)
            self.assertIn("mp3", args)

    def test_selected_format_command(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            request = DownloadRequest(
                url="https://example.com/video",
                output_dir=Path(temp),
                mode="format",
                format_id="137+140",
            )
            args = build_download_args(request)
            self.assertIn("137+140", args)

    def test_range_command(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            request = DownloadRequest(
                url="https://example.com/video",
                output_dir=Path(temp),
                range_start="00:00:10",
                range_end="00:00:20.5",
                precise_range=True,
            )
            args = build_download_args(request)
            section = args[args.index("--download-sections") + 1]
            self.assertEqual(section, "*00:00:10-00:00:20.5")
            self.assertIn("--force-keyframes-at-cuts", args)

    def test_partial_range_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            request = DownloadRequest(
                url="https://example.com/video",
                output_dir=Path(temp),
                range_start="10",
            )
            with self.assertRaises(DownloadWorkbenchError):
                build_download_args(request)

    def test_subtitles_metadata_thumbnail(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            request = DownloadRequest(
                url="https://example.com/video",
                output_dir=Path(temp),
                subtitle_languages=("ja", "en"),
                include_auto_subtitles=True,
                write_metadata=True,
                write_thumbnail=True,
            )
            args = build_download_args(request)
            self.assertIn("--write-subs", args)
            self.assertIn("ja,en", args)
            self.assertIn("--write-auto-subs", args)
            self.assertIn("--write-info-json", args)
            self.assertIn("--write-thumbnail", args)


if __name__ == "__main__":
    unittest.main()
