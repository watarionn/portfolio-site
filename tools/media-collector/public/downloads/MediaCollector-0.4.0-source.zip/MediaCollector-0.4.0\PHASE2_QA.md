# Phase 2 QA

Date: 2026-09-24

## Goal

Put the clean Phase 1 core behind a Windows desktop GUI without duplicating normalization or download logic.

## GUI scope

- paste URL list
- load TXT / TSV / CSV
- source adapter hint: Auto / X media / Generic URL
- plan generation before network access
- summary cards for unique/image/video/unknown/duplicates
- normalized URL table
- manifest preview
- output-folder picker
- manifest save
- direct media download
- videos disabled by default
- per-file MiB limit
- background-thread download
- activity log
- keyboard shortcuts

## Safety boundary

Building a plan performs no network download.

Downloads only start after the user presses Download.

The GUI does not request, store or persist account passwords, browser cookies or authentication tokens.

## Automated QA

- Python compile: PASS
- Phase 1 + Phase 2 tests: 22 / 22 PASS
- GUI construction: PASS
- plan rendering: PASS
- duplicate summary: PASS
- max-size validation: PASS

## Visual QA

- real application screenshot: `qa/screenshots/phase2-main.png`
- direct target-window capture using PrintWindow
- screenshot size: 1216 x 839
- no taskbar or overlapping application window
- demo plan: 4 unique items, 3 images, 1 video, 1 duplicate removed

## Shortcuts

- Ctrl+O: load URL list
- Ctrl+L: focus URL input
- F5: rebuild plan
- Ctrl+S: save plan manifest
