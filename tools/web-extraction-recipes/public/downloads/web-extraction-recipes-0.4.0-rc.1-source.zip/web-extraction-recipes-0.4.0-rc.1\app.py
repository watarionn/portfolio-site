from __future__ import annotations

import json
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from crawl_core import CrawlRecipe, CrawlResult, crawl, crawl_recipe_from_dict
from extraction_core import (
    ExtractionError,
    Recipe,
    extract_records,
    read_html_file,
    recipe_from_dict,
    write_records,
)


APP_TITLE = "Web Extraction Recipes"


def recipe_from_text(text: str) -> Recipe:
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ExtractionError(f"Recipe JSON error: {exc}") from exc
    return recipe_from_dict(data)


def crawl_recipe_from_text(text: str) -> CrawlRecipe:
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ExtractionError(f"Crawl Recipe JSON error: {exc}") from exc
    return crawl_recipe_from_dict(data)


def parse_start_urls(text: str) -> list[str]:
    values = []
    for raw in text.splitlines():
        value = raw.strip()
        if value and not value.startswith("#"):
            values.append(value)
    return list(dict.fromkeys(values))


def format_bytes(value: int) -> str:
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB"):
        if size < 1024 or unit == "GiB":
            return f"{int(size)} B" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{value} B"


class ExtractionApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1240x820")
        self.minsize(1020, 680)

        self.html_var = tk.StringVar()
        self.recipe_path_var = tk.StringVar()
        self.crawl_recipe_path_var = tk.StringVar()
        self.crawl_permission_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="HTMLとレシピを選択してください。")
        self.summary_vars = {
            key: tk.StringVar(value="—")
            for key in ("recipe", "rows", "fields", "input")
        }

        self.current_records: list[dict[str, str]] = []
        self.current_recipe: Recipe | None = None
        self.current_crawl_recipe: CrawlRecipe | None = None
        self.current_html_path: Path | None = None
        self.current_mode: str | None = None
        self._busy = False
        self._suspend_recipe_dirty = False
        self._suspend_crawl_dirty = False

        self._build_ui()
        self.html_var.trace_add("write", lambda *_: self._invalidate_results("offline"))
        self.recipe_text.bind("<<Modified>>", self._recipe_modified)
        self.start_urls_text.bind("<<Modified>>", self._crawl_setup_modified)
        self.crawl_recipe_text.bind("<<Modified>>", self._crawl_setup_modified)
        self.crawl_permission_var.trace_add("write", lambda *_: self._refresh_crawl_state())

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(3, weight=1)

        source = ttk.LabelFrame(outer, text="Offline Input", padding=10)
        source.grid(row=0, column=0, sticky="ew")
        source.columnconfigure(1, weight=1)

        ttk.Label(source, text="HTML").grid(row=0, column=0, sticky="w")
        ttk.Entry(source, textvariable=self.html_var).grid(
            row=0, column=1, sticky="ew", padx=(8, 8)
        )
        ttk.Button(source, text="選択", command=self.browse_html).grid(row=0, column=2)

        ttk.Label(source, text="Recipe").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(source, textvariable=self.recipe_path_var).grid(
            row=1, column=1, sticky="ew", padx=(8, 8), pady=(8, 0)
        )
        ttk.Button(source, text="読込", command=self.browse_recipe).grid(
            row=1, column=2, pady=(8, 0)
        )

        actions = ttk.Frame(outer)
        actions.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        self.extract_button = ttk.Button(
            actions, text="抽出 Preview", command=self.extract_preview
        )
        self.extract_button.pack(side="left")
        ttk.Button(actions, text="レシピ検証", command=self.validate_recipe).pack(
            side="left", padx=(8, 0)
        )
        ttk.Button(actions, text="レシピ保存", command=self.save_recipe).pack(
            side="left", padx=(8, 0)
        )
        self.crawl_button = ttk.Button(
            actions,
            text="HTTP Crawl",
            command=self.start_http_crawl,
            state="disabled",
        )
        self.crawl_button.pack(side="left", padx=(18, 0))
        ttk.Checkbutton(
            actions,
            text="HTTP取得の権限・許可があります",
            variable=self.crawl_permission_var,
        ).pack(side="left", padx=(8, 0))
        self.export_button = ttk.Button(
            actions, text="結果を保存", command=self.export_records, state="disabled"
        )
        self.export_button.pack(side="right")

        summary = ttk.LabelFrame(outer, text="Summary", padding=10)
        summary.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        for col in range(4):
            summary.columnconfigure(col, weight=1)

        for index, (label, key) in enumerate(
            (("Recipe", "recipe"), ("Rows", "rows"), ("Fields", "fields"), ("Input", "input"))
        ):
            frame = ttk.Frame(summary)
            frame.grid(row=0, column=index, sticky="ew", padx=(0 if index == 0 else 10, 0))
            ttk.Label(frame, text=label + ":").pack(side="left")
            ttk.Label(frame, textvariable=self.summary_vars[key]).pack(
                side="left", padx=(6, 0)
            )

        self.notebook = ttk.Notebook(outer)
        self.notebook.grid(row=3, column=0, sticky="nsew", pady=(10, 0))

        preview_frame = ttk.Frame(self.notebook, padding=8)
        preview_frame.rowconfigure(0, weight=1)
        preview_frame.columnconfigure(0, weight=1)
        self.notebook.add(preview_frame, text="Preview")

        self.preview_tree = ttk.Treeview(preview_frame, show="headings")
        self.preview_tree.grid(row=0, column=0, sticky="nsew")
        py = ttk.Scrollbar(preview_frame, orient="vertical", command=self.preview_tree.yview)
        px = ttk.Scrollbar(preview_frame, orient="horizontal", command=self.preview_tree.xview)
        self.preview_tree.configure(yscrollcommand=py.set, xscrollcommand=px.set)
        py.grid(row=0, column=1, sticky="ns")
        px.grid(row=1, column=0, sticky="ew")

        recipe_frame = ttk.Frame(self.notebook, padding=8)
        recipe_frame.rowconfigure(0, weight=1)
        recipe_frame.columnconfigure(0, weight=1)
        self.notebook.add(recipe_frame, text="Recipe JSON")

        self.recipe_text = tk.Text(
            recipe_frame, wrap="none", font=("Consolas", 10), undo=True
        )
        self.recipe_text.grid(row=0, column=0, sticky="nsew")
        ry = ttk.Scrollbar(recipe_frame, orient="vertical", command=self.recipe_text.yview)
        rx = ttk.Scrollbar(recipe_frame, orient="horizontal", command=self.recipe_text.xview)
        self.recipe_text.configure(yscrollcommand=ry.set, xscrollcommand=rx.set)
        ry.grid(row=0, column=1, sticky="ns")
        rx.grid(row=1, column=0, sticky="ew")

        crawl_frame = ttk.Frame(self.notebook, padding=8)
        crawl_frame.rowconfigure(2, weight=1)
        crawl_frame.columnconfigure(0, weight=1)
        crawl_frame.columnconfigure(1, weight=1)
        self.notebook.add(crawl_frame, text="HTTP Crawl")

        crawl_top = ttk.Frame(crawl_frame)
        crawl_top.grid(row=0, column=0, columnspan=2, sticky="ew")
        crawl_top.columnconfigure(1, weight=1)
        ttk.Label(crawl_top, text="Crawl Recipe").grid(row=0, column=0, sticky="w")
        ttk.Entry(crawl_top, textvariable=self.crawl_recipe_path_var).grid(
            row=0, column=1, sticky="ew", padx=(8, 8)
        )
        ttk.Button(crawl_top, text="読込", command=self.browse_crawl_recipe).grid(
            row=0, column=2
        )
        ttk.Button(
            crawl_top, text="検証", command=self.validate_crawl_recipe
        ).grid(row=0, column=3, padx=(8, 0))
        ttk.Button(
            crawl_top, text="保存", command=self.save_crawl_recipe
        ).grid(row=0, column=4, padx=(8, 0))

        ttk.Label(
            crawl_frame,
            text="Sample default: robots.txt遵守 / same-origin / private host block / 1秒間隔 / 最大100ページ",
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(8, 6))

        urls_box = ttk.LabelFrame(crawl_frame, text="Start URLs", padding=6)
        urls_box.grid(row=2, column=0, sticky="nsew", padx=(0, 4))
        urls_box.rowconfigure(0, weight=1)
        urls_box.columnconfigure(0, weight=1)
        self.start_urls_text = tk.Text(
            urls_box, wrap="none", font=("Consolas", 10), undo=True
        )
        self.start_urls_text.grid(row=0, column=0, sticky="nsew")
        uy = ttk.Scrollbar(urls_box, orient="vertical", command=self.start_urls_text.yview)
        self.start_urls_text.configure(yscrollcommand=uy.set)
        uy.grid(row=0, column=1, sticky="ns")

        crawl_recipe_box = ttk.LabelFrame(crawl_frame, text="Crawl Recipe JSON", padding=6)
        crawl_recipe_box.grid(row=2, column=1, sticky="nsew", padx=(4, 0))
        crawl_recipe_box.rowconfigure(0, weight=1)
        crawl_recipe_box.columnconfigure(0, weight=1)
        self.crawl_recipe_text = tk.Text(
            crawl_recipe_box, wrap="none", font=("Consolas", 10), undo=True
        )
        self.crawl_recipe_text.grid(row=0, column=0, sticky="nsew")
        cy = ttk.Scrollbar(
            crawl_recipe_box, orient="vertical", command=self.crawl_recipe_text.yview
        )
        cx = ttk.Scrollbar(
            crawl_recipe_box, orient="horizontal", command=self.crawl_recipe_text.xview
        )
        self.crawl_recipe_text.configure(yscrollcommand=cy.set, xscrollcommand=cx.set)
        cy.grid(row=0, column=1, sticky="ns")
        cx.grid(row=1, column=0, sticky="ew")

        log_frame = ttk.Frame(self.notebook, padding=8)
        log_frame.rowconfigure(0, weight=1)
        log_frame.columnconfigure(0, weight=1)
        self.notebook.add(log_frame, text="Log")

        self.log_text = tk.Text(
            log_frame, wrap="word", font=("Consolas", 10), state="disabled"
        )
        self.log_text.grid(row=0, column=0, sticky="nsew")
        ly = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=ly.set)
        ly.grid(row=0, column=1, sticky="ns")

        bottom = ttk.Frame(outer)
        bottom.grid(row=4, column=0, sticky="ew", pady=(8, 0))
        ttk.Label(bottom, textvariable=self.status_var).pack(side="left")
        self.progress = ttk.Progressbar(bottom, mode="indeterminate", length=150)
        self.progress.pack(side="right")

    def _append_log(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text.rstrip() + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _recipe_modified(self, _event=None) -> None:
        if self._suspend_recipe_dirty:
            self.recipe_text.edit_modified(False)
            return
        if self.recipe_text.edit_modified():
            self._invalidate_results("offline")
            self.recipe_text.edit_modified(False)

    def _crawl_setup_modified(self, event=None) -> None:
        widget = getattr(event, "widget", None)
        if self._suspend_crawl_dirty:
            if isinstance(widget, tk.Text):
                widget.edit_modified(False)
            return
        if isinstance(widget, tk.Text) and widget.edit_modified():
            self._invalidate_results("crawl")
            widget.edit_modified(False)

    def _invalidate_results(self, mode: str | None = None) -> None:
        if self._busy:
            return
        if mode is not None and self.current_mode not in {None, mode}:
            return
        if self.current_records or self.current_recipe is not None or self.current_crawl_recipe is not None:
            self.current_records = []
            self.current_recipe = None
            self.current_crawl_recipe = None
            self.current_html_path = None
            self.current_mode = None
            self._render_preview([])
            self.export_button.configure(state="disabled")
            self.summary_vars["rows"].set("—")
            self.summary_vars["fields"].set("—")
            self.summary_vars["input"].set("—")
            self.status_var.set("入力が変更されました。再抽出してください。")

    def _refresh_crawl_state(self) -> None:
        enabled = self.crawl_permission_var.get() and not self._busy
        self.crawl_button.configure(state="normal" if enabled else "disabled")

    def browse_crawl_recipe(self) -> None:
        selected = filedialog.askopenfilename(
            title="Crawl Recipe JSONを選択",
            filetypes=(("JSON", "*.json"), ("All files", "*.*")),
        )
        if not selected:
            return
        self.crawl_recipe_path_var.set(selected)
        self._load_crawl_recipe_file(Path(selected))

    def _load_crawl_recipe_file(self, path: Path) -> None:
        try:
            text = path.read_text(encoding="utf-8")
            recipe = crawl_recipe_from_text(text)
            pretty = json.dumps(json.loads(text), ensure_ascii=False, indent=2)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self._suspend_crawl_dirty = True
        self.crawl_recipe_text.delete("1.0", "end")
        self.crawl_recipe_text.insert("1.0", pretty)
        self.crawl_recipe_text.edit_modified(False)
        self._suspend_crawl_dirty = False
        self.summary_vars["recipe"].set(recipe.name)
        self.status_var.set("Crawl Recipeを読み込みました。")
        self._append_log(f"[CRAWL RECIPE] {recipe.name}")

    def validate_crawl_recipe(self) -> None:
        try:
            recipe = crawl_recipe_from_text(
                self.crawl_recipe_text.get("1.0", "end")
            )
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            self.status_var.set("Crawl Recipe検証に失敗しました。")
            return
        self.summary_vars["recipe"].set(recipe.name)
        self.status_var.set("Crawl Recipeは有効です。")
        self._append_log(
            f"[CRAWL VALID] {recipe.name} / max_pages={recipe.policy.max_pages}"
        )

    def save_crawl_recipe(self) -> None:
        try:
            crawl_recipe_from_text(self.crawl_recipe_text.get("1.0", "end"))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        current = self.crawl_recipe_path_var.get().strip()
        selected = filedialog.asksaveasfilename(
            title="Crawl Recipe JSONを保存",
            defaultextension=".json",
            initialfile=Path(current).name if current else "crawl_recipe.json",
            filetypes=(("JSON", "*.json"),),
        )
        if not selected:
            return
        text = self.crawl_recipe_text.get("1.0", "end").strip() + "\n"
        Path(selected).write_text(text, encoding="utf-8")
        self.crawl_recipe_path_var.set(selected)
        self.status_var.set("Crawl Recipeを保存しました。")

    def start_http_crawl(self) -> None:
        if self._busy:
            return
        if not self.crawl_permission_var.get():
            messagebox.showinfo(
                APP_TITLE,
                "HTTP取得の権限・許可を確認してください。",
            )
            return

        start_urls = parse_start_urls(self.start_urls_text.get("1.0", "end"))
        if not start_urls:
            messagebox.showerror(APP_TITLE, "Start URLを1件以上入力してください。")
            return
        try:
            recipe = crawl_recipe_from_text(
                self.crawl_recipe_text.get("1.0", "end")
            )
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self._set_busy(True, "HTTP巡回中…")
        self._append_log(
            f"[CRAWL START] recipe={recipe.name} / start_urls={len(start_urls)}"
        )

        def progress(message: str) -> None:
            self.after(
                0,
                lambda message=message: self._append_log(f"[CRAWL] {message}"),
            )

        def worker() -> None:
            try:
                result = crawl(start_urls, recipe, progress=progress)
            except Exception as exc:
                self.after(0, lambda exc=exc: self._crawl_failed(exc))
                return
            self.after(
                0,
                lambda: self._crawl_finished(start_urls, recipe, result),
            )

        threading.Thread(target=worker, daemon=True).start()

    def _crawl_failed(self, exc: Exception) -> None:
        self._append_log(f"[CRAWL ERROR] {exc}")
        self._set_busy(False, "HTTP巡回に失敗しました。")
        messagebox.showerror(APP_TITLE, str(exc))

    def _crawl_finished(
        self,
        start_urls: list[str],
        recipe: CrawlRecipe,
        result: CrawlResult,
    ) -> None:
        records = list(result.records)
        stats = result.stats
        self.current_records = records
        self.current_recipe = recipe.detail_recipe
        self.current_crawl_recipe = recipe
        self.current_html_path = None
        self.current_mode = "crawl"

        self.summary_vars["recipe"].set(recipe.name)
        self.summary_vars["rows"].set(str(len(records)))
        field_count = (
            len(records[0])
            if records
            else len(recipe.detail_recipe.fields) + 2
        )
        self.summary_vars["fields"].set(str(field_count))
        self.summary_vars["input"].set(
            f"{len(start_urls)} URLs / {stats.fetched_pages} fetched"
        )
        self._render_preview(records)
        self.export_button.configure(state="normal" if records else "disabled")

        self._append_log(
            "[CRAWL DONE] "
            f"rows={len(records)} / fetched={stats.fetched_pages} / "
            f"cache={stats.cache_hits} / detail={stats.unique_detail_links} / "
            f"robots={stats.skipped_robots} / cross-origin={stats.skipped_cross_origin}"
        )
        for error in stats.errors[:20]:
            self._append_log(f"[CRAWL NOTE] {error}")

        self._set_busy(
            False,
            f"HTTP巡回完了: {len(records)}件 / {stats.fetched_pages}ページ取得",
        )

    def browse_html(self) -> None:
        selected = filedialog.askopenfilename(
            title="HTMLファイルを選択",
            filetypes=(("HTML", "*.html *.htm *.txt"), ("All files", "*.*")),
        )
        if selected:
            self.html_var.set(selected)

    def browse_recipe(self) -> None:
        selected = filedialog.askopenfilename(
            title="Recipe JSONを選択",
            filetypes=(("JSON", "*.json"), ("All files", "*.*")),
        )
        if not selected:
            return
        self.recipe_path_var.set(selected)
        self._load_recipe_file(Path(selected))

    def _load_recipe_file(self, path: Path) -> None:
        try:
            text = path.read_text(encoding="utf-8")
            recipe = recipe_from_text(text)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self._suspend_recipe_dirty = True
        self.recipe_text.delete("1.0", "end")
        self.recipe_text.insert("1.0", json.dumps(json.loads(text), ensure_ascii=False, indent=2))
        self.recipe_text.edit_modified(False)
        self._suspend_recipe_dirty = False
        self.summary_vars["recipe"].set(recipe.name)
        self.status_var.set("レシピを読み込みました。")
        self._append_log(f"[RECIPE] {recipe.name}")

    def validate_recipe(self) -> None:
        try:
            recipe = recipe_from_text(self.recipe_text.get("1.0", "end"))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            self.status_var.set("レシピ検証に失敗しました。")
            return
        self.summary_vars["recipe"].set(recipe.name)
        self.status_var.set("レシピは有効です。")
        self._append_log(f"[VALID] {recipe.name}")

    def save_recipe(self) -> None:
        try:
            recipe_from_text(self.recipe_text.get("1.0", "end"))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        current = self.recipe_path_var.get().strip()
        selected = filedialog.asksaveasfilename(
            title="Recipe JSONを保存",
            defaultextension=".json",
            initialfile=Path(current).name if current else "recipe.json",
            filetypes=(("JSON", "*.json"),),
        )
        if not selected:
            return
        text = self.recipe_text.get("1.0", "end").strip() + "\n"
        Path(selected).write_text(text, encoding="utf-8")
        self.recipe_path_var.set(selected)
        self.status_var.set("レシピを保存しました。")

    def extract_preview(self) -> None:
        if self._busy:
            return
        html_path = Path(self.html_var.get().strip())
        if not html_path.is_file():
            messagebox.showerror(APP_TITLE, "HTMLファイルが見つかりません。")
            return
        try:
            recipe = recipe_from_text(self.recipe_text.get("1.0", "end"))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self._set_busy(True, "抽出中…")

        def worker() -> None:
            try:
                html_text = read_html_file(html_path)
                records = extract_records(html_text, recipe)
                size = html_path.stat().st_size
            except Exception as exc:
                self.after(0, lambda exc=exc: self._extract_failed(exc))
                return
            self.after(
                0,
                lambda: self._extract_finished(html_path, recipe, records, size),
            )

        threading.Thread(target=worker, daemon=True).start()

    def _extract_failed(self, exc: Exception) -> None:
        self._set_busy(False, "抽出に失敗しました。")
        self._append_log(f"[ERROR] {exc}")
        messagebox.showerror(APP_TITLE, str(exc))

    def _extract_finished(
        self,
        html_path: Path,
        recipe: Recipe,
        records: list[dict[str, str]],
        size: int,
    ) -> None:
        self.current_html_path = html_path
        self.current_recipe = recipe
        self.current_crawl_recipe = None
        self.current_mode = "offline"
        self.current_records = records
        self.summary_vars["recipe"].set(recipe.name)
        self.summary_vars["rows"].set(str(len(records)))
        self.summary_vars["fields"].set(str(len(recipe.fields)))
        self.summary_vars["input"].set(format_bytes(size))
        self._render_preview(records)
        self.export_button.configure(state="normal")
        self._append_log(
            f"[EXTRACT] {html_path.name} / recipe={recipe.name} / rows={len(records)}"
        )
        self._set_busy(False, f"{len(records)}件を抽出しました。")

    def _render_preview(self, records: list[dict[str, str]]) -> None:
        for row in self.preview_tree.get_children():
            self.preview_tree.delete(row)

        columns = list(records[0].keys()) if records else []
        self.preview_tree.configure(columns=columns)
        for name in columns:
            self.preview_tree.heading(name, text=name)
            self.preview_tree.column(name, width=180, minwidth=80, anchor="w")

        for record in records[:2000]:
            self.preview_tree.insert(
                "", "end", values=[record.get(name, "") for name in columns]
            )

    def export_records(self) -> None:
        if not self.current_records:
            messagebox.showinfo(APP_TITLE, "保存できる抽出結果がありません。")
            return
        selected = filedialog.asksaveasfilename(
            title="抽出結果を保存",
            defaultextension=".tsv",
            filetypes=(
                ("TSV", "*.tsv"),
                ("CSV", "*.csv"),
                ("JSON", "*.json"),
            ),
        )
        if not selected:
            return
        try:
            output = write_records(self.current_records, selected)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return
        self.status_var.set(f"保存しました: {output.name}")
        self._append_log(f"[EXPORT] {output}")

    def _set_busy(self, busy: bool, status: str) -> None:
        self._busy = busy
        self.status_var.set(status)
        self.extract_button.configure(state="disabled" if busy else "normal")
        self._refresh_crawl_state()
        if busy:
            self.progress.start(10)
        else:
            self.progress.stop()


def main() -> None:
    app = ExtractionApp()
    app.mainloop()


if __name__ == "__main__":
    main()