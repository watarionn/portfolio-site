# Phase 1 QA

Date: 2026-09-25

## Goal

Turn two older site-specific R extraction scripts into a reusable offline recipe engine.

## Environment decision

The current PC does not have Rscript or BeautifulSoup installed.

Phase 1 therefore uses only the Python standard library so the extraction core can run without package installation.

## Implemented

- lightweight HTML tree parser
- recipe-driven repeated-row extraction
- tag / class / id selectors
- attribute existence selector
- exact, contains and token attribute selectors
- descendant selectors
- text extraction
- attribute extraction
- relative URL resolution
- regex capture groups
- default values for missing fields
- TSV / CSV / JSON export
- UTF-8 / CP932 local HTML reading

## Boundary

- no network access in Phase 1
- no cookies
- no authentication
- no browser automation
- no access-control bypass

## Next

Phase 2 will add a Windows GUI with HTML preview, recipe editing, extraction preview and export.
Network crawling remains a later layer so offline extraction stays independently testable.
