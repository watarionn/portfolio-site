from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from video_workbench_core import export_frames, probe_media, trim_video


def main() -> None:
    root = Path(tempfile.gettempdir()) / "Video Workbench \u65e5\u672c\u8a9e smoke"
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)

    source = root / "\u5165\u529b \u52d5\u753b.mp4"
    subprocess.run(
        [
            "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=30",
            "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
            "-t", "4",
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            "-g", "90",
            "-c:a", "aac",
            str(source),
        ],
        check=True,
    )

    precise, precise_info = trim_video(source, "1", "3", precise=True)
    fast, fast_info = trim_video(source, "1", "3", precise=False)
    _, png_count = export_frames(source, image_format="png", fps=2)
    _, jpg_count = export_frames(
        source,
        image_format="jpg",
        fps=1,
        jpg_quality=2,
    )

    result = {
        "source_duration": round(probe_media(source).duration, 3),
        "precise_duration": round(precise_info.duration, 3),
        "fast_duration": round(fast_info.duration, 3),
        "png_2fps_count": png_count,
        "jpg_1fps_count": jpg_count,
        "unicode_path_ok": (
            source.exists() and precise.exists() and fast.exists()
        ),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))

    assert result["precise_duration"] == 2.0
    assert result["png_2fps_count"] == 8
    assert result["jpg_1fps_count"] == 4
    assert result["unicode_path_ok"] is True


if __name__ == "__main__":
    main()
