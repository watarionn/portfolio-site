# Changelog

## 0.4.0 - 2026-09-24

Initial release candidate of Media Collector.

### Added

- clean rebuild of several personal media-collection utilities
- Windows Tkinter GUI and command-line interface
- plan-first workflow with no network download until explicitly requested
- X media URL normalization to `name=orig`
- Pixiv direct-media adapter with illustration/page identity extraction
- Generic direct-media URL adapter
- X / Pixiv / Generic browser console bridges
- JSON / TSV plan and download manifests
- URL deduplication
- SHA-256 content deduplication
- existing-file hashing during repeated runs
- image/video type classification
- per-file size limit
- video downloads disabled by default
- Content-Type verification
- file-signature verification for supported image/video types
- signed/query URL redaction in manifests and parsed GUI results
- Pixiv public Referer handling without cookies or authorization tokens
- Download Results table
- real local HTTP integration tests
- direct-window QA screenshots

### Security boundary

The legacy tools contained hard-coded credentials. They are not copied into this repository.

The release contains no account token, browser cookie, password, authorization header, refresh token, or private key.
