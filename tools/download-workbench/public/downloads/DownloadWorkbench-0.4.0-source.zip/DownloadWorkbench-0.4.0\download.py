from __future__ import annotations

import argparse
from pathlib import Path

from download_workbench_core import (
    DownloadRequest,
    analyze_url,
    build_download_args,
    detect_tools,
    format_size,
    redact_url,
    run_download,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Download Workbench CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    analyze = sub.add_parser("analyze", help="Inspect a URL without downloading")
    analyze.add_argument("url")

    download = sub.add_parser("download", help="Download an authorized media URL")
    download.add_argument("url")
    download.add_argument("-o", "--output", type=Path, default=Path("downloads"))
    download.add_argument("--mode", choices=("video", "audio", "format"), default="video")
    download.add_argument("--format-id", default="")
    download.add_argument("--audio-format", choices=("m4a", "mp3", "wav", "flac", "opus"), default="m4a")
    download.add_argument("--start", default="")
    download.add_argument("--end", default="")
    download.add_argument("--precise-range", action="store_true")
    download.add_argument("--subs", default="")
    download.add_argument("--auto-subs", action="store_true")
    download.add_argument("--thumbnail", action="store_true")
    download.add_argument("--no-metadata", action="store_true")
    download.add_argument("--show-command", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    yt, ff = detect_tools()
    if not yt.available:
        raise SystemExit("yt-dlp was not found on PATH.")

    if args.command == "analyze":
        info = analyze_url(args.url, ytdlp_executable=yt.path or "yt-dlp")
        print(f"Title     : {info.title}")
        print(f"Uploader  : {info.uploader}")
        print(f"Duration  : {info.duration if info.duration is not None else 'unknown'}")
        print(f"Extractor : {info.extractor}")
        print(f"URL       : {redact_url(info.webpage_url)}")
        print(f"Formats   : {len(info.formats)}")
        for item in info.formats:
            print(
                f"  {item.format_id:>8}  {item.ext:<5}  {item.resolution:<12} "
                f"{item.vcodec}/{item.acodec}  {format_size(item.filesize)}"
            )
        print(f"Subtitles : {len(info.subtitles)}")
        return 0

    if not ff.available:
        raise SystemExit("ffmpeg was not found on PATH. Download operations require ffmpeg.")

    languages = tuple(
        part.strip()
        for part in args.subs.split(",")
        if part.strip()
    )
    request = DownloadRequest(
        url=args.url,
        output_dir=args.output,
        mode=args.mode,
        format_id=args.format_id,
        audio_format=args.audio_format,
        range_start=args.start,
        range_end=args.end,
        precise_range=args.precise_range,
        subtitle_languages=languages,
        include_auto_subtitles=args.auto_subs,
        write_metadata=not args.no_metadata,
        write_thumbnail=args.thumbnail,
    )
    command = build_download_args(request, ytdlp_executable=yt.path or "yt-dlp")
    if args.show_command:
        print("Command:")
        print(" ".join(command[:-1] + [redact_url(command[-1])]))
    result = run_download(
        request,
        ytdlp_executable=yt.path or "yt-dlp",
        line_callback=print,
    )
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
