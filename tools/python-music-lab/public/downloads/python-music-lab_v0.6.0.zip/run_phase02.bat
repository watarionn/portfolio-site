@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Python virtual environment not found. Run setup.bat first.
  exit /b 1
)

".venv\Scripts\python.exe" src\phase02_generate_song.py
if errorlevel 1 exit /b %errorlevel%

echo.
echo Phase 02A complete. See output\phase02\structured_song.mid
endlocal
