param(
    [string]$Version = "0.4.0"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dist = Join-Path $Root "dist"
$Stage = Join-Path $Dist "DownloadWorkbench-$Version"
$Zip = Join-Path $Dist "DownloadWorkbench-$Version-source.zip"

if (Test-Path $Stage) { Remove-Item -Recurse -Force $Stage }
if (Test-Path $Zip) { Remove-Item -Force $Zip }
New-Item -ItemType Directory -Path $Stage -Force | Out-Null

$Files = @(
    ".gitattributes",
    ".gitignore",
    "CHANGELOG.md",
    "PHASE1_QA.md",
    "PHASE2_QA.md",
    "PHASE3_QA.md",
    "PHASE4_QA.md",
    "README.md",
    "VERSION",
    "app.py",
    "build_release.ps1",
    "download.py",
    "download_workbench_core.py",
    "preflight.py",
    "run_download_workbench.bat"
)

foreach ($Relative in $Files) {
    Copy-Item (Join-Path $Root $Relative) (Join-Path $Stage $Relative)
}

New-Item -ItemType Directory -Path (Join-Path $Stage "docs") -Force | Out-Null
Copy-Item (Join-Path $Root "docs\ORIGIN.md") (Join-Path $Stage "docs\ORIGIN.md")

New-Item -ItemType Directory -Path (Join-Path $Stage "tests") -Force | Out-Null
Copy-Item (Join-Path $Root "tests\test_core.py") (Join-Path $Stage "tests\test_core.py")
Copy-Item (Join-Path $Root "tests\test_app_ui_logic.py") (Join-Path $Stage "tests\test_app_ui_logic.py")
Copy-Item (Join-Path $Root "tests\test_phase3_integration.py") (Join-Path $Stage "tests\test_phase3_integration.py")

New-Item -ItemType Directory -Path (Join-Path $Stage "qa\screenshots") -Force | Out-Null
Copy-Item (Join-Path $Root "qa\screenshots\phase3-main.png") (Join-Path $Stage "qa\screenshots\phase3-main.png")
Copy-Item (Join-Path $Root "qa\screenshots\phase4-main.png") (Join-Path $Stage "qa\screenshots\phase4-main.png")

Compress-Archive -Path $Stage -DestinationPath $Zip -CompressionLevel Optimal
Write-Host "Built $Zip"
