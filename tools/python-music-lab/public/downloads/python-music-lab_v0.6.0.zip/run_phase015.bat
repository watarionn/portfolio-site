@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Python virtual environment was not found.
  echo Run setup.bat first.
  pause
  exit /b 1
)

set "PRESET=%~1"
if "%PRESET%"=="" set "PRESET=bright_pop"

".venv\Scripts\python.exe" "src\phase015_generate_candidates.py" --preset "%PRESET%"
if errorlevel 1 (
  echo [ERROR] Candidate generation failed.
  pause
  exit /b 1
)

echo.
echo Done. See output\candidates\%PRESET%\
pause
