# Phase 03B Sound Design

## Purpose

Phase 03BはComposition Layerを変更せず、Phase 02Bの同じ`best_candidate.mid`をRendering Layerだけで聴きやすくする工程。

## Signal flow

```text
MIDI / TimedNote
  ↓
track voice
  ├─ Melody: detuned saw + sine
  ├─ Chords: triangle + sine
  ├─ Bass: square + sine
  └─ Drums: procedural synthesis from Phase 03A
  ↓
ADSR / Pan
  ↓
track low-pass
  ↓
track gain
  ↓
Delay / Reverb send-like finite taps
  ↓
track sum
  ↓
soft saturation
  ↓
peak normalization
  ↓
PCM16 WAV
  ↓ optional
ffmpeg/libvorbis OGG preview
```

## Design constraints

- CompositionとRenderingを混ぜない。
- NumPy以外のDSP Python依存を追加しない。
- Noiseを含む合成はdeterministicのまま維持する。
- WAVは同一input/config/runtimeでbyte-level reproducibleにする。
- OGGはencoder/container依存のため、成果物hashをmanifestへ記録する方式とする。
- ffmpegが無くてもWAV生成は成功させる。

## Filter

Phase 03Bでは透明性と依存の少なさを優先し、cumulative-sumで実装したmoving-average low-passを採用する。高品質EQやband-limited oscillatorは将来のRendering改善候補。

## Space effects

Delay / Reverbはfeedback recurrenceではなく有限tapとして実装する。これにより処理結果が明示的で、同じ設定から同じWAVを再生成しやすい。

## Reference render

- Source: `output/phase02b/best_candidate.mid`
- Sample rate: 44.1 kHz
- Channels: stereo
- PCM: 16 bit
- Duration: 47.4 sec
- Notes: 614
- Target peak: 0.92
- Full-scale samples: 0
- OGG preview: Vorbis, 44.1 kHz stereo when ffmpeg is available

## Portfolio contract

`output/phase03b/portfolio_audio.json`をフロントエンド用の最小契約とする。

- `sources`: OGG preferred / WAV fallback
- `duration_seconds`
- `sections`: MIDI markerのtickと`start_seconds`
- `metadata`: BPM / source MIDI hash / manifest filename

Portfolio CityはPython runtimeを必要としない。
