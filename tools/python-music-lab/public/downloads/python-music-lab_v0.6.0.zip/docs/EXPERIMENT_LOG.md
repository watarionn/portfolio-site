# Experiment Log

生成結果を比較するときは、Seed、Key、BPM、構成、採否と所感を残す。

| Date | Phase | Seed | Key | BPM | Result | Notes |
|---|---|---:|---|---:|---|---|
| 2026-09-04 | 01 | 20260904 | C major | 128 | initial | 初期MVP |
| 2026-09-16 | 01.5 | 2026091601+ | C/G/D major | 104-136 | pass | 複数候補とmanifest出力を導入 |
| 2026-09-18 | 02A | 2026091801 | C major | 132 | reference | A/B/Chorus、モチーフ反復・変奏、section marker。QA PASS |

## Phase 03A - MIDI to WAV MVP

Phase 02B `best_candidate.mid` をPython synthでrender。

- 44.1 kHz stereo PCM16
- 45.600 sec
- 614 note events
- peak 0.920000 after deterministic normalization
- RMS 0.13336065
- SHA-256 `35e1aa23eb1e4e32c3387e6ec102614b1616f13fcb5d54d4a364a9113d32c471`
- full regression: 13/13 tests PASS

Phase 03Aでは音質の完成よりも、Composition LayerとRendering Layerを分離した状態で再現可能な自前audio artifactを作ることを優先した。
