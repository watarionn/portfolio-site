from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app import DownloadWorkbenchApp, build_request_from_fields
from download_workbench_core import FormatOption, MediaInfo, SubtitleTrack, ToolStatus


class AppLogicTests(unittest.TestCase):
    def test_build_request_from_fields(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            request = build_request_from_fields(
                url="https://example.com/video",
                output_dir=temp,
                mode_label="Audio",
                format_id="",
                audio_format="mp3",
                range_start="10",
                range_end="20",
                precise_range=True,
                subtitle_text="ja, en,ja",
                include_auto_subtitles=True,
                write_metadata=True,
                write_thumbnail=False,
            )
            self.assertEqual(request.mode, "audio")
            self.assertEqual(request.audio_format, "mp3")
            self.assertEqual(request.subtitle_languages, ("ja", "en"))
            self.assertTrue(request.precise_range)

    def test_gui_constructs(self) -> None:
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        self.assertEqual(app.title(), "Download Workbench")
        self.assertTrue(app.ytdlp_status.available)
        self.assertTrue(app.ffmpeg_status.available)

    def test_rights_gate_controls_download_button(self) -> None:
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app.url_var.set("https://example.com/video")
        app.rights_var.set(False)
        app._refresh_download_state()
        self.assertEqual(str(app.download_button.cget("state")), "disabled")
        app.rights_var.set(True)
        app._refresh_download_state()
        self.assertEqual(str(app.download_button.cget("state")), "normal")

    def test_download_button_requires_ffmpeg(self) -> None:
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app.url_var.set("https://example.com/video")
        app.rights_var.set(True)
        app.ffmpeg_status = ToolStatus(
            name="ffmpeg",
            path=None,
            version=None,
            available=False,
        )
        app._refresh_download_state()
        self.assertEqual(str(app.download_button.cget("state")), "disabled")

    def test_metadata_is_opt_in_by_default(self) -> None:
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        self.assertFalse(app.metadata_var.get())

    def test_render_media_info(self) -> None:
        info = MediaInfo(
            url="https://example.com/video",
            webpage_url="https://example.com/video",
            media_id="abc",
            title="Demo video",
            uploader="Tester",
            duration=65.0,
            extractor="Generic",
            formats=(
                FormatOption(
                    "137", "mp4", "1920x1080", 30, "avc1", "none", 1000, "https", "1080p"
                ),
                FormatOption(
                    "140", "m4a", "audio only", None, "none", "mp4a", 200, "https", "audio"
                ),
            ),
            subtitles=(
                SubtitleTrack("ja", False, "vtt"),
                SubtitleTrack("en", True, "vtt"),
            ),
        )
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app._analyze_finished(info)
        self.assertEqual(app.summary_vars["title"].get(), "Demo video")
        self.assertEqual(app.summary_vars["duration"].get(), "00:01:05")
        self.assertEqual(len(app.formats_tree.get_children()), 2)
        self.assertEqual(len(app.subtitles_tree.get_children()), 2)

    def test_double_click_format_moves_to_format_mode(self) -> None:
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        item = app.formats_tree.insert(
            "",
            "end",
            values=("137", "mp4", "1920x1080", "30", "avc1", "none", "1 MiB", ""),
        )
        app.formats_tree.selection_set(item)
        app._use_selected_format()
        self.assertEqual(app.format_id_var.get(), "137")
        self.assertEqual(app.mode_var.get(), "Format ID")

    def test_subtitle_selection_appends_language(self) -> None:
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        item = app.subtitles_tree.insert("", "end", values=("ja", "Subtitle", "vtt"))
        app.subtitles_tree.selection_set(item)
        app.subtitle_var.set("en")
        app._use_selected_subtitle()
        self.assertEqual(app.subtitle_var.get(), "en,ja")

    def test_command_preview_redacts_sensitive_query(self) -> None:
        app = DownloadWorkbenchApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        app.url_var.set("https://example.com/video?token=super-secret&safe=yes")
        app._refresh_command_preview()
        preview = app.command_text.get("1.0", "end")
        self.assertNotIn("super-secret", preview)
        self.assertIn("REDACTED", preview)
        self.assertIn("safe=yes", preview)


if __name__ == "__main__":
    unittest.main()
