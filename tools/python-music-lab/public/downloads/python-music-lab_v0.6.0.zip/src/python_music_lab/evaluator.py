from __future__ import annotations

from dataclasses import asdict, dataclass

from .midi_writer import NoteEvent
from .music_theory import scale_midi
from .structured_composer import StructuredSongConfig, chord_for_global_bar


@dataclass(frozen=True)
class EvaluationResult:
    total_score: float
    harmony_score: float
    motion_score: float
    range_score: float
    section_contrast_score: float
    cadence_score: float
    rhythm_score: float
    strong_beat_chord_tone_ratio: float
    stepwise_motion_ratio: float
    melodic_range_semitones: int
    cadence_resolution_ratio: float

    def to_dict(self) -> dict[str, float | int]:
        return asdict(self)


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def _target_score(value: float, target: float, tolerance: float) -> float:
    if tolerance <= 0:
        return 100.0 if value == target else 0.0
    return _clamp(100.0 * (1.0 - abs(value - target) / tolerance))


def _section_ranges(config: StructuredSongConfig) -> list[tuple[str, int, int]]:
    ranges: list[tuple[str, int, int]] = []
    cursor = 0
    for section in config.sections:
        start = cursor * config.bar_ticks
        cursor += section.bars
        ranges.append((section.name, start, cursor * config.bar_ticks))
    return ranges


def _events_in_range(events: list[NoteEvent], start: int, end: int) -> list[NoteEvent]:
    return [event for event in events if start <= event.start < end]


def _strong_beat_chord_tone_ratio(config: StructuredSongConfig, melody: list[NoteEvent]) -> float:
    strong = 0
    chord_tones = 0
    for event in melody:
        position = event.start % config.bar_ticks
        beat_index = position // config.ticks_per_beat
        if position % config.ticks_per_beat == 0 and beat_index in (0, 2):
            strong += 1
            bar = event.start // config.bar_ticks
            chord_pcs = {note % 12 for note in chord_for_global_bar(config, bar, octave=4)}
            if event.note % 12 in chord_pcs:
                chord_tones += 1
    return chord_tones / strong if strong else 0.0


def _stepwise_ratio(melody: list[NoteEvent]) -> float:
    ordered = sorted(melody, key=lambda event: event.start)
    if len(ordered) < 2:
        return 0.0
    intervals = [abs(b.note - a.note) for a, b in zip(ordered, ordered[1:])]
    return sum(interval <= 4 for interval in intervals) / len(intervals)


def _melodic_range(melody: list[NoteEvent]) -> int:
    if not melody:
        return 0
    notes = [event.note for event in melody]
    return max(notes) - min(notes)


def _section_contrast(config: StructuredSongConfig, melody: list[NoteEvent]) -> float:
    ranges = _section_ranges(config)
    if len(ranges) < 2:
        return 50.0
    _, first_start, first_end = ranges[0]
    _, last_start, last_end = ranges[-1]
    first = _events_in_range(melody, first_start, first_end)
    last = _events_in_range(melody, last_start, last_end)
    if not first or not last:
        return 0.0

    first_pitch = sum(event.note for event in first) / len(first)
    last_pitch = sum(event.note for event in last) / len(last)
    pitch_lift = last_pitch - first_pitch
    pitch_score = _target_score(pitch_lift, target=8.0, tolerance=8.0)

    first_bars = config.sections[0].bars
    last_bars = config.sections[-1].bars
    first_density = len(first) / first_bars
    last_density = len(last) / last_bars
    density_ratio = last_density / max(0.01, first_density)
    density_score = _target_score(density_ratio, target=1.30, tolerance=0.80)
    return (pitch_score * 0.65) + (density_score * 0.35)


def _cadence_ratio(config: StructuredSongConfig, melody: list[NoteEvent]) -> float:
    scale = scale_midi(config.key_root, config.mode, octave=4)
    tonic_pc = scale[0] % 12
    dominant_pc = scale[4] % 12
    ranges = _section_ranges(config)
    resolved = 0
    total = 0
    for section, (_, start, end) in zip(config.sections, ranges):
        if section.cadence == "none":
            continue
        events = _events_in_range(melody, start, end)
        if not events:
            continue
        final = max(events, key=lambda event: event.start)
        expected = tonic_pc if section.cadence == "authentic" else dominant_pc
        total += 1
        if final.note % 12 == expected:
            resolved += 1
    return resolved / total if total else 1.0


def _rhythm_score(config: StructuredSongConfig, melody: list[NoteEvent]) -> float:
    if not melody:
        return 0.0
    eighth = config.ticks_per_beat // 2
    onset_slots = {(event.start % config.bar_ticks) // eighth for event in melody}
    durations = {max(1, round(event.duration / eighth)) for event in melody}
    onset_score = _target_score(len(onset_slots), target=6.0, tolerance=4.0)
    duration_score = _target_score(len(durations), target=2.0, tolerance=2.0)
    return onset_score * 0.65 + duration_score * 0.35


def evaluate_song(config: StructuredSongConfig, song: dict[str, list[NoteEvent]]) -> EvaluationResult:
    melody = song["Melody"]
    chord_ratio = _strong_beat_chord_tone_ratio(config, melody)
    stepwise = _stepwise_ratio(melody)
    pitch_range = _melodic_range(melody)
    cadence_ratio = _cadence_ratio(config, melody)

    harmony_score = _target_score(chord_ratio, target=0.82, tolerance=0.45)
    motion_score = _target_score(stepwise, target=0.72, tolerance=0.45)
    range_score = _target_score(float(pitch_range), target=20.0, tolerance=15.0)
    contrast_score = _section_contrast(config, melody)
    cadence_score = cadence_ratio * 100.0
    rhythm_score = _rhythm_score(config, melody)

    total = (
        harmony_score * 0.25
        + motion_score * 0.20
        + range_score * 0.15
        + contrast_score * 0.15
        + cadence_score * 0.15
        + rhythm_score * 0.10
    )
    return EvaluationResult(
        total_score=round(total, 3),
        harmony_score=round(harmony_score, 3),
        motion_score=round(motion_score, 3),
        range_score=round(range_score, 3),
        section_contrast_score=round(contrast_score, 3),
        cadence_score=round(cadence_score, 3),
        rhythm_score=round(rhythm_score, 3),
        strong_beat_chord_tone_ratio=round(chord_ratio, 4),
        stepwise_motion_ratio=round(stepwise, 4),
        melodic_range_semitones=pitch_range,
        cadence_resolution_ratio=round(cadence_ratio, 4),
    )
