# Phase 3 QA

Date: 2026-09-25

## Goal

Add controlled HTTP collection and reusable list-to-detail crawling on top of the already-tested offline recipe engine.

## Architecture

The network layer does not duplicate HTML extraction logic.

1. Fetch one or more start/list pages.
2. Discover detail links with the configured selector.
3. Resolve relative URLs.
4. Apply same-origin and robots rules.
5. Fetch each unique detail body through the cache.
6. Apply the Phase 1 detail Recipe.
7. Preserve each source_url -> detail_url relationship in output rows.

A detail page referenced from multiple source lists is fetched once, but each source/detail relationship remains visible in output.

## HTTP policy

Defaults:

- delay_seconds: 1.0
- timeout_seconds: 20
- max_retries: 2
- max_pages: 100
- same_origin: true
- respect_robots: true
- allow_private_hosts: false
- User-Agent: WebExtractionRecipes/0.3 (+local desktop extraction tool)

Additional limits:

- http / https only
- embedded URL credentials rejected
- cross-origin redirects blocked when same_origin is enabled
- HTML / XHTML only
- maximum response body: 4 MiB
- response charset honored when supplied
- localhost / loopback / private / link-local / reserved hosts blocked by default
- private/local hosts require explicit allow_private_hosts: true
- robots fetch failures other than 404 / 410 fail closed

## Authentication boundary

Runtime requests do not add:

- Cookie
- Authorization
- browser profile
- login session
- access-control bypass

Local integration tests inspect the received request headers and verify Cookie and Authorization are absent.

## Retry and caching

- HTTP 429 and 5xx are retryable.
- network/timeout failures are retryable.
- request delay also applies between retry attempts.
- fetched detail pages are cached by normalized URL.
- max_pages prevents unbounded page collection.

## Automated QA

- Phase 1-3 test suite: 28 / 28 PASS
- tests also pass with ResourceWarning promoted to error
- list -> detail localhost integration: PASS
- retry after HTTP 500: PASS
- robots.txt deny: PASS
- same-origin filter: PASS
- cross-origin redirect block: PASS
- duplicate detail body cache: PASS
- multi-source provenance retention: PASS
- max_pages stop: PASS
- XHTML + declared charset: PASS
- no Cookie / Authorization received: PASS
- private/local host default block: PASS
- HTTPError response cleanup / ResourceWarning gate: PASS
- GUI HTTP permission gate: PASS
- GUI Crawl Recipe validation: PASS
- GUI crawl result Preview: PASS

## CLI smoke

A localhost server exposed one list page and two detail pages. The smoke recipe explicitly enabled `allow_private_hosts: true`; localhost remains blocked by default.

Result:

- Rows: 2
- Fetched pages: 3
- Detail links: 2
- TSV columns: title / item_id / source_url / detail_url
- CLI smoke: PASS

No external website or authenticated account was used.

## Visual QA

- real application screenshot: `qa/screenshots/phase3-main.png`
- direct target-window PrintWindow capture
- screenshot size: 1256 x 859
- screenshot SHA-256: `FFFEB4403393A617FC9050E732FD6D640EB5FFF7510ECBA2092AB68188E32204`
- no taskbar or overlapping application window
- actual localhost crawl result shown in Preview
- HTTP permission gate visible
- summary shows 2 rows / 4 fields / 1 URL / 3 fetched pages