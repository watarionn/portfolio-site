from __future__ import annotations

import io
import tempfile
import unittest
from email.message import Message
from pathlib import Path

from media_collector_core import MediaCollectorError, download_plan
from source_adapters import (
    build_adapter_plan,
    make_adapter_item,
    normalize_pixiv_media_url,
)


class FakeResponse:
    def __init__(self, body: bytes, content_type: str):
        self._stream = io.BytesIO(body)
        self.headers = Message()
        self.headers["Content-Type"] = content_type

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self, size=-1):
        return self._stream.read(size)


class SourceAdapterTests(unittest.TestCase):
    def test_pixiv_original_url(self) -> None:
        url, media_id, ext = normalize_pixiv_media_url(
            "https://i.pximg.net/img-original/img/2026/09/24/12/34/56/12345678_p0.png?token=x"
        )
        self.assertEqual(
            url,
            "https://i.pximg.net/img-original/img/2026/09/24/12/34/56/12345678_p0.png",
        )
        self.assertEqual(media_id, "12345678_p0")
        self.assertEqual(ext, "png")

    def test_pixiv_master_identity(self) -> None:
        url, media_id, ext = normalize_pixiv_media_url(
            "https://i.pximg.net/c/540x540_70/img-master/img/2026/09/24/12/34/56/22222222_p3_master1200.jpg"
        )
        self.assertIn("i.pximg.net", url)
        self.assertEqual(media_id, "22222222_p3")
        self.assertEqual(ext, "jpg")

    def test_pixiv_rejects_other_host(self) -> None:
        with self.assertRaises(MediaCollectorError):
            normalize_pixiv_media_url("https://example.com/123_p0.jpg")

    def test_auto_detects_pixiv(self) -> None:
        item = make_adapter_item(
            "https://i.pximg.net/img-original/img/2026/09/24/00/00/00/123_p0.jpg"
        )
        self.assertEqual(item.source, "pixiv")
        self.assertEqual(item.kind, "image")
        self.assertEqual(item.media_id, "123_p0")

    def test_auto_keeps_x_adapter(self) -> None:
        item = make_adapter_item(
            "https://pbs.twimg.com/media/ABC?format=webp&name=small"
        )
        self.assertEqual(item.source, "x")
        self.assertTrue(item.normalized_url.endswith("name=orig"))

    def test_adapter_plan_deduplicates_pixiv_query_variants(self) -> None:
        plan = build_adapter_plan(
            [
                "https://i.pximg.net/img-original/img/2026/09/24/00/00/00/123_p0.jpg?a=1",
                "https://i.pximg.net/img-original/img/2026/09/24/00/00/00/123_p0.jpg?b=2",
            ]
        )
        self.assertEqual(len(plan), 1)

    def test_pixiv_download_uses_public_referer_not_credentials(self) -> None:
        item = make_adapter_item(
            "https://i.pximg.net/img-original/img/2026/09/24/00/00/00/123_p0.jpg"
        )
        seen = {}

        def opener(request, timeout):
            seen["referer"] = request.get_header("Referer")
            seen["authorization"] = request.get_header("Authorization")
            return FakeResponse(b"\xff\xd8\xff\xe0image-bytes", "image/jpeg")

        with tempfile.TemporaryDirectory() as temp:
            results = download_plan([item], Path(temp), opener=opener)
            self.assertEqual(results[0].status, "saved")

        self.assertEqual(seen["referer"], "https://www.pixiv.net/")
        self.assertIsNone(seen["authorization"])


if __name__ == "__main__":
    unittest.main()
