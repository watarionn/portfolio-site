(() => {
  "use strict";
  const normalize = (raw) => {
    try {
      const url = new URL(raw, location.href);
      if (url.hostname !== "i.pximg.net") return null;
      if (!/\.(?:jpe?g|png|webp|gif|avif)$/i.test(url.pathname)) return null;
      url.hash = "";
      url.search = "";
      return url.href;
    } catch (_) { return null; }
  };
  const found = new Set();
  const add = (raw) => {
    const normalized = raw && normalize(raw);
    if (normalized) found.add(normalized);
  };
  for (const image of document.querySelectorAll("img")) {
    add(image.currentSrc); add(image.src); add(image.getAttribute("src"));
    const srcset = image.getAttribute("srcset") || "";
    for (const part of srcset.split(",")) add(part.trim().split(/\s+/)[0]);
  }
  for (const source of document.querySelectorAll("source[srcset]")) {
    for (const part of source.srcset.split(",")) add(part.trim().split(/\s+/)[0]);
  }
  for (const anchor of document.querySelectorAll("a[href]")) add(anchor.href);
  const urls = [...found].sort();
  const text = urls.join("\n") + (urls.length ? "\n" : "");
  console.log("[Media Collector / Pixiv] " + urls.length + " media URL(s)");
  console.log(text);
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).catch(() => {});
  }
  return urls;
})();
