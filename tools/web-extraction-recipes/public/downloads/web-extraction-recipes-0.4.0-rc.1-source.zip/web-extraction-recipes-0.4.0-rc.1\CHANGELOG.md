# Changelog

## 0.4.0-rc.1 - 2026-09-25

Release Candidate for the clean rebuild of Web Extraction Recipes.

### Added

- reusable JSON extraction recipes for local HTML
- Windows GUI for recipe editing, preview, validation, and export
- HTTP Collection with list -> detail crawling
- request delay, timeout, retry, cache, max-pages, robots, and same-origin policies
- provenance fields for source and detail URLs
- TSV / CSV / JSON output

### Safety defaults

- HTTP/HTTPS only
- embedded URL credentials rejected
- private/local networks blocked unless explicitly enabled in the recipe
- Cookie and Authorization headers are not added
- no browser-profile, login, CAPTCHA, paywall, DRM, or access-control bypass logic
- HTML/XHTML only with a 4 MiB response limit

### Verification

- Phase 1-3 regression suite passes
- ResourceWarning-as-error gate passes
- release preflight and extracted-ZIP verification are required before publication
