# Download Workbench

URL解析、形式選択、動画・音声保存、範囲指定、字幕・メタデータ出力を1つにまとめるWindows向けローカルツールです。

旧 `C:\Tools\ytdlp_desktop` を参考にしつつ、認証状態・Cookie・ブラウザプロファイル・Docker provider・過去ログを持ち込まずに作り直しています。

## Current status

Phase 3まで完了しています。実yt-dlp / ffmpeg経路でVideo、Audio、Format ID、範囲クリップをローカルHTTP配信から検証済みです。

## Features

- yt-dlp / ffmpeg 状態検出
- URL解析（ダウンロードなし）
- タイトル / 投稿者 / 長さ / extractor
- format一覧
- 字幕 / 自動字幕一覧
- video / audio / format ID指定
- 範囲指定（seconds / MM:SS / HH:MM:SS）
- precise range option
- 字幕言語指定
- info JSON / thumbnail（既定OFF）
- platform-aware Command Preview quoting
- rights/permission gate
- output folder
- no-overwrite
- CLI
- query内のtoken/signature類をログ表示時に伏せる

## Security boundary

Download Workbenchは、利用者自身が保存権限を持つコンテンツや、ダウンロードが許可されているコンテンツを扱うためのツールです。

この新作では次を実装しません。

- DRM回避
- paywall回避
- access-control回避
- Cookieの自動抽出・保存
- browser profileの持ち込み
- 認証トークンの保存
- 旧ツールのdownload archive / logsの移植

さらにyt-dlpには常に `--ignore-config` を付け、PC上の既存設定ファイルからCookieや認証設定を暗黙に読み込まないようにします。

## Windows GUI

    run_download_workbench.bat

または:

    py -3 app.py

GUIではURLをAnalyzeしてから、形式・字幕・範囲・出力オプションを確認できます。Downloadは「保存権限・許可があります」のチェックを入れた場合だけ有効になります。

## Environment check

    py -3 preflight.py

`run_download_workbench.bat` から起動した場合も同じpreflightを先に実行します。

必要環境:

- Windows
- Python 3.10以上
- Tkinter
- yt-dlp
- ffmpeg

追加のPythonパッケージは不要です。

## Distribution

ソースリリースを再生成する場合:

    powershell -ExecutionPolicy Bypass -File .\build_release.ps1 -Version 0.4.0

生成物:

    dist\DownloadWorkbench-0.4.0-source.zip

## Current release

Release Candidate: **0.4.0**

## CLI

解析のみ:

    py -3 download.py analyze "https://example.com/video"

動画:

    py -3 download.py download "https://example.com/video" -o downloads

音声:

    py -3 download.py download "https://example.com/video" -o downloads --mode audio --audio-format m4a

範囲指定:

    py -3 download.py download "https://example.com/video" -o downloads --start 00:01:00 --end 00:02:30
