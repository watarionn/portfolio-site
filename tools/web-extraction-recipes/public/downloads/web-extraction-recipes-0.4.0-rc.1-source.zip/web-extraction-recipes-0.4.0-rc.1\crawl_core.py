from __future__ import annotations

import ipaddress
import json
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from extraction_core import (
    ExtractionError,
    Recipe,
    extract_records,
    parse_html,
    recipe_from_dict,
    select,
)


DEFAULT_USER_AGENT = "WebExtractionRecipes/0.3 (+local desktop extraction tool)"


@dataclass(frozen=True)
class HttpPolicy:
    delay_seconds: float = 1.0
    timeout_seconds: float = 20.0
    max_retries: int = 2
    max_pages: int = 100
    same_origin: bool = True
    respect_robots: bool = True
    allow_private_hosts: bool = False
    user_agent: str = DEFAULT_USER_AGENT


@dataclass(frozen=True)
class CrawlRecipe:
    name: str
    link_selector: str
    link_attr: str
    detail_recipe: Recipe
    policy: HttpPolicy = HttpPolicy()


@dataclass
class CrawlStats:
    fetched_pages: int = 0
    cache_hits: int = 0
    skipped_cross_origin: int = 0
    skipped_robots: int = 0
    failed_pages: int = 0
    discovered_links: int = 0
    unique_detail_links: int = 0
    errors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class CrawlResult:
    records: tuple[dict[str, str], ...]
    stats: CrawlStats


class Fetcher:
    def __init__(
        self,
        policy: HttpPolicy,
        *,
        opener: Callable | None = None,
        sleep_fn: Callable[[float], None] = time.sleep,
    ) -> None:
        self.policy = policy
        self.opener = opener or urllib.request.urlopen
        self.sleep_fn = sleep_fn
        self.cache: dict[str, str] = {}
        self._robots: dict[str, urllib.robotparser.RobotFileParser] = {}
        self._last_request_at: float | None = None

    def _wait(self) -> None:
        if self.policy.delay_seconds <= 0:
            return
        now = time.monotonic()
        if self._last_request_at is None:
            return
        remaining = self.policy.delay_seconds - (now - self._last_request_at)
        if remaining > 0:
            self.sleep_fn(remaining)

    def _robots_parser(self, url: str) -> urllib.robotparser.RobotFileParser:
        parsed = urllib.parse.urlsplit(url)
        origin = f"{parsed.scheme.lower()}://{parsed.netloc.lower()}"
        if origin in self._robots:
            return self._robots[origin]

        robots_url = urllib.parse.urljoin(origin + "/", "robots.txt")
        parser = urllib.robotparser.RobotFileParser()
        parser.set_url(robots_url)
        try:
            request = urllib.request.Request(
                robots_url,
                headers={"User-Agent": self.policy.user_agent},
            )
            with self.opener(request, timeout=self.policy.timeout_seconds) as response:
                body = response.read(512 * 1024).decode("utf-8", errors="replace")
            parser.parse(body.splitlines())
        except urllib.error.HTTPError as exc:
            try:
                if exc.code in {404, 410}:
                    parser.parse(["User-agent: *", "Disallow:"])
                else:
                    parser.parse(["User-agent: *", "Disallow: /"])
            finally:
                exc.close()
        except Exception:
            parser.parse(["User-agent: *", "Disallow: /"])
        self._robots[origin] = parser
        return parser

    def allowed_by_robots(self, url: str) -> bool:
        if not self.policy.respect_robots:
            return True
        return self._robots_parser(url).can_fetch(self.policy.user_agent, url)

    def fetch(self, url: str, stats: CrawlStats) -> str:
        normalized = normalize_http_url(url)
        if not self.policy.allow_private_hosts and is_private_or_local_url(normalized):
            raise ExtractionError(
                f"private/local host blocked by policy: {normalized}"
            )
        if normalized in self.cache:
            stats.cache_hits += 1
            return self.cache[normalized]

        if stats.fetched_pages >= self.policy.max_pages:
            raise ExtractionError(
                f"maximum fetched page limit reached: {self.policy.max_pages}"
            )

        if not self.allowed_by_robots(normalized):
            stats.skipped_robots += 1
            raise ExtractionError(f"robots.txt disallows URL: {normalized}")

        attempts = self.policy.max_retries + 1
        last_error: Exception | None = None

        for attempt in range(attempts):
            try:
                self._wait()
                self._last_request_at = time.monotonic()
                request = urllib.request.Request(
                    normalized,
                    headers={
                        "User-Agent": self.policy.user_agent,
                        "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.1",
                    },
                )
                with self.opener(request, timeout=self.policy.timeout_seconds) as response:
                    final_url = normalize_http_url(
                        getattr(response, "geturl", lambda: normalized)()
                    )
                    if self.policy.same_origin and not same_origin(normalized, final_url):
                        raise ExtractionError(
                            f"cross-origin redirect blocked: {normalized} -> {final_url}"
                        )
                    content_type = str(response.headers.get("Content-Type") or "")
                    media_type = content_type.split(";", 1)[0].strip().lower()
                    if media_type not in {"text/html", "application/xhtml+xml"}:
                        raise ExtractionError(
                            f"non-HTML Content-Type for {normalized}: {content_type or '(missing)'}"
                        )
                    charset = None
                    get_charset = getattr(response.headers, "get_content_charset", None)
                    if callable(get_charset):
                        charset = get_charset()
                    raw = response.read(4 * 1024 * 1024 + 1)
                if len(raw) > 4 * 1024 * 1024:
                    raise ExtractionError(f"HTML response exceeds 4 MiB: {normalized}")
                text = decode_html(raw, preferred=charset)
                self.cache[normalized] = text
                stats.fetched_pages += 1
                return text
            except urllib.error.HTTPError as exc:
                last_error = exc
                retryable = exc.code == 429 or 500 <= exc.code <= 599
                exc.close()
                if not retryable or attempt == attempts - 1:
                    break
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last_error = exc
                if attempt == attempts - 1:
                    break
            except ExtractionError:
                raise

        stats.failed_pages += 1
        message = f"failed to fetch {normalized}: {last_error}"
        raise ExtractionError(message)


def decode_html(raw: bytes, preferred: str | None = None) -> str:
    encodings = []
    if preferred:
        encodings.append(preferred)
    encodings.extend(("utf-8-sig", "utf-8", "cp932"))

    for encoding in dict.fromkeys(encodings):
        try:
            return raw.decode(encoding)
        except (LookupError, UnicodeDecodeError):
            continue
    return raw.decode("utf-8", errors="replace")


def normalize_http_url(raw_url: str) -> str:
    value = raw_url.strip()
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise ExtractionError("crawl URLs must use http or https")
    if not parsed.hostname:
        raise ExtractionError("crawl URL has no hostname")
    if parsed.username is not None or parsed.password is not None:
        raise ExtractionError("URLs containing embedded credentials are not accepted")
    netloc = parsed.hostname.lower()
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"
    return urllib.parse.urlunsplit(
        (parsed.scheme.lower(), netloc, parsed.path or "/", parsed.query, "")
    )


def is_private_or_local_url(url: str) -> bool:
    parsed = urllib.parse.urlsplit(normalize_http_url(url))
    host = parsed.hostname or ""
    lowered = host.lower()
    if lowered == "localhost" or lowered.endswith(".localhost"):
        return True

    try:
        addresses = {
            info[4][0]
            for info in socket.getaddrinfo(host, parsed.port or 80, type=socket.SOCK_STREAM)
        }
    except socket.gaierror:
        return False

    for address in addresses:
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            continue
        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        ):
            return True
    return False


def same_origin(left: str, right: str) -> bool:
    a = urllib.parse.urlsplit(normalize_http_url(left))
    b = urllib.parse.urlsplit(normalize_http_url(right))
    return (a.scheme, a.hostname, a.port) == (b.scheme, b.hostname, b.port)


def _policy_from_dict(data: dict) -> HttpPolicy:
    return HttpPolicy(
        delay_seconds=max(0.0, float(data.get("delay_seconds", 1.0))),
        timeout_seconds=max(1.0, float(data.get("timeout_seconds", 20.0))),
        max_retries=max(0, int(data.get("max_retries", 2))),
        max_pages=max(1, min(int(data.get("max_pages", 100)), 1000)),
        same_origin=bool(data.get("same_origin", True)),
        respect_robots=bool(data.get("respect_robots", True)),
        allow_private_hosts=bool(data.get("allow_private_hosts", False)),
        user_agent=str(data.get("user_agent") or DEFAULT_USER_AGENT).strip(),
    )


def crawl_recipe_from_dict(data: dict) -> CrawlRecipe:
    if not isinstance(data, dict):
        raise ExtractionError("crawl recipe must be an object")
    name = str(data.get("name") or "").strip()
    link_selector = str(data.get("link_selector") or "").strip()
    link_attr = str(data.get("link_attr") or "href").strip()
    detail_data = data.get("detail_recipe")
    policy_data = data.get("http") or {}

    if not name:
        raise ExtractionError("crawl recipe name is required")
    if not link_selector:
        raise ExtractionError("link_selector is required")
    if not link_attr:
        raise ExtractionError("link_attr is required")
    if not isinstance(detail_data, dict):
        raise ExtractionError("detail_recipe must be an object")
    if not isinstance(policy_data, dict):
        raise ExtractionError("http must be an object")

    detail_recipe = recipe_from_dict(detail_data)
    return CrawlRecipe(
        name=name,
        link_selector=link_selector,
        link_attr=link_attr,
        detail_recipe=detail_recipe,
        policy=_policy_from_dict(policy_data),
    )


def load_crawl_recipe(path: str | Path) -> CrawlRecipe:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return crawl_recipe_from_dict(data)


def discover_links(html_text: str, source_url: str, recipe: CrawlRecipe) -> list[str]:
    root = parse_html(html_text)
    links: list[str] = []
    seen: set[str] = set()

    for node in select(root, recipe.link_selector):
        value = node.attr(recipe.link_attr)
        if not value:
            continue
        joined = urllib.parse.urljoin(source_url, value)
        try:
            normalized = normalize_http_url(joined)
        except ExtractionError:
            continue
        if normalized not in seen:
            seen.add(normalized)
            links.append(normalized)
    return links


def crawl(
    start_urls: list[str],
    recipe: CrawlRecipe,
    *,
    fetcher: Fetcher | None = None,
    progress: Callable[[str], None] | None = None,
) -> CrawlResult:
    normalized_starts = list(dict.fromkeys(normalize_http_url(url) for url in start_urls))
    if not normalized_starts:
        raise ExtractionError("at least one start URL is required")

    stats = CrawlStats()
    client = fetcher or Fetcher(recipe.policy)
    detail_pairs: list[tuple[str, str]] = []
    seen_pairs: set[tuple[str, str]] = set()
    unique_details: set[str] = set()

    for source_url in normalized_starts:
        if progress:
            progress(f"LIST {source_url}")
        try:
            html_text = client.fetch(source_url, stats)
        except ExtractionError as exc:
            stats.errors.append(str(exc))
            continue

        links = discover_links(html_text, source_url, recipe)
        stats.discovered_links += len(links)
        for detail_url in links:
            if recipe.policy.same_origin and not same_origin(source_url, detail_url):
                stats.skipped_cross_origin += 1
                continue
            pair = (source_url, detail_url)
            if pair not in seen_pairs:
                seen_pairs.add(pair)
                detail_pairs.append(pair)
                unique_details.add(detail_url)

    stats.unique_detail_links = len(unique_details)
    output: list[dict[str, str]] = []

    for source_url, detail_url in detail_pairs:
        if progress:
            progress(f"DETAIL {detail_url}")
        try:
            html_text = client.fetch(detail_url, stats)
        except ExtractionError as exc:
            stats.errors.append(str(exc))
            continue

        detail_recipe = Recipe(
            name=recipe.detail_recipe.name,
            row_selector=recipe.detail_recipe.row_selector,
            fields=recipe.detail_recipe.fields,
            base_url=detail_url,
        )
        for record in extract_records(html_text, detail_recipe):
            enriched = dict(record)
            enriched.setdefault("source_url", source_url)
            enriched.setdefault("detail_url", detail_url)
            output.append(enriched)

    return CrawlResult(tuple(output), stats)