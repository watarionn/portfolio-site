from __future__ import annotations

import os
import threading
import traceback
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from media_collector_core import (
    DEFAULT_MAX_BYTES,
    DownloadResult,
    MediaItem,
    download_plan,
    extract_urls,
    redact_url_for_manifest,
    write_download_manifest,
    write_plan_manifest,
)
from source_adapters import build_adapter_plan


APP_TITLE = "Media Collector"
SOURCE_CHOICES = {
    "自動判定": "auto",
    "X media": "x",
    "Pixiv media": "pixiv",
    "Generic URL": "generic",
}


def build_plan_for_ui(text: str, source_choice: str) -> tuple[list[MediaItem], int]:
    raw_urls = extract_urls(text)
    adapter = SOURCE_CHOICES.get(source_choice, "auto")
    plan = build_adapter_plan(raw_urls, adapter=adapter)
    duplicates = max(0, len(raw_urls) - len(plan))
    return plan, duplicates


def format_bytes(value: int) -> str:
    size = float(value)
    units = ["B", "KiB", "MiB", "GiB"]
    for unit in units:
        if size < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(size):,} {unit}"
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{value:,} B"


def summarize_plan(plan: list[MediaItem], duplicates: int = 0) -> dict[str, str]:
    images = sum(item.kind == "image" for item in plan)
    videos = sum(item.kind == "video" for item in plan)
    unknown = sum(item.kind == "unknown" for item in plan)
    return {
        "unique": f"{len(plan):,}",
        "images": f"{images:,}",
        "videos": f"{videos:,}",
        "unknown": f"{unknown:,}",
        "duplicates": f"{duplicates:,}",
    }


class MediaCollectorApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1200x800")
        self.minsize(1000, 680)

        self.source_var = tk.StringVar(value="自動判定")
        self.output_var = tk.StringVar(value=str(Path.cwd() / "collected"))
        self.allow_videos_var = tk.BooleanVar(value=False)
        self.max_mib_var = tk.StringVar(
            value=str(int(DEFAULT_MAX_BYTES / (1024 * 1024)))
        )
        self.status_var = tk.StringVar(value="URLを貼り付けるか、一覧ファイルを読み込んでください。")
        self.current_plan: list[MediaItem] = []
        self.current_results: list[DownloadResult] = []
        self.duplicates_removed = 0
        self._busy = False

        self.summary_vars = {
            key: tk.StringVar(value="—")
            for key in ("unique", "images", "videos", "unknown", "duplicates")
        }

        self._configure_style()
        self._build_ui()
        self._bind_shortcuts()

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        style.configure("Summary.TLabel", font=("TkDefaultFont", 13, "bold"))
        style.configure("Action.TButton", padding=(12, 6))
        style.configure("Treeview", rowheight=24)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(3, weight=1)

        source = ttk.LabelFrame(outer, text="収集候補", padding=12)
        source.grid(row=0, column=0, sticky="ew")
        source.columnconfigure(0, weight=1)

        toolbar = ttk.Frame(source)
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(toolbar, text="Source").pack(side="left")
        ttk.Combobox(
            toolbar,
            textvariable=self.source_var,
            values=tuple(SOURCE_CHOICES),
            state="readonly",
            width=16,
        ).pack(side="left", padx=(6, 12))
        ttk.Button(toolbar, text="一覧ファイルを読込", command=self.load_url_file).pack(
            side="left"
        )
        ttk.Button(toolbar, text="入力をクリア", command=self.clear_input).pack(
            side="left", padx=(6, 0)
        )
        ttk.Button(
            toolbar,
            text="Bridgeフォルダ",
            command=self.open_bridge_folder,
        ).pack(side="left", padx=(6, 0))
        self.plan_button = ttk.Button(
            toolbar,
            text="Plan作成",
            command=self.build_plan,
            style="Action.TButton",
        )
        self.plan_button.pack(side="right")

        input_wrap = ttk.Frame(source)
        input_wrap.grid(row=1, column=0, sticky="ew")
        input_wrap.columnconfigure(0, weight=1)
        self.input_text = tk.Text(
            input_wrap,
            height=6,
            wrap="none",
            font=("Consolas", 10),
        )
        self.input_text.grid(row=0, column=0, sticky="ew")
        input_y = ttk.Scrollbar(
            input_wrap, orient="vertical", command=self.input_text.yview
        )
        input_x = ttk.Scrollbar(
            input_wrap, orient="horizontal", command=self.input_text.xview
        )
        self.input_text.configure(
            yscrollcommand=input_y.set,
            xscrollcommand=input_x.set,
        )
        input_y.grid(row=0, column=1, sticky="ns")
        input_x.grid(row=1, column=0, sticky="ew")

        options = ttk.LabelFrame(outer, text="保存設定", padding=10)
        options.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        options.columnconfigure(1, weight=1)

        ttk.Label(options, text="出力フォルダ").grid(row=0, column=0, sticky="w")
        ttk.Entry(options, textvariable=self.output_var).grid(
            row=0, column=1, sticky="ew", padx=8
        )
        ttk.Button(options, text="選択", command=self.browse_output).grid(
            row=0, column=2
        )
        ttk.Checkbutton(
            options,
            text="動画の直接保存を許可",
            variable=self.allow_videos_var,
        ).grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Label(options, text="1ファイル上限").grid(
            row=1, column=1, sticky="e", pady=(8, 0)
        )
        ttk.Entry(options, textvariable=self.max_mib_var, width=8).grid(
            row=1, column=2, sticky="w", padx=(8, 0), pady=(8, 0)
        )
        ttk.Label(options, text="MiB").grid(
            row=1, column=3, sticky="w", padx=(4, 0), pady=(8, 0)
        )

        summary = ttk.Frame(outer)
        summary.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        summary.columnconfigure(tuple(range(5)), weight=1)
        cards = [
            ("unique", "Unique"),
            ("images", "Images"),
            ("videos", "Videos"),
            ("unknown", "Unknown"),
            ("duplicates", "Duplicates removed"),
        ]
        for col, (key, label) in enumerate(cards):
            card = ttk.LabelFrame(summary, text=label, padding=8)
            card.grid(row=0, column=col, sticky="ew", padx=(0 if col == 0 else 6, 0))
            ttk.Label(
                card,
                textvariable=self.summary_vars[key],
                style="Summary.TLabel",
            ).pack(anchor="center")

        self.notebook = ttk.Notebook(outer)
        self.notebook.grid(row=3, column=0, sticky="nsew", pady=(10, 0))

        plan_frame = ttk.Frame(self.notebook, padding=8)
        plan_frame.columnconfigure(0, weight=1)
        plan_frame.rowconfigure(0, weight=1)
        self.notebook.add(plan_frame, text="Plan")

        self.plan_tree = ttk.Treeview(
            plan_frame,
            columns=("index", "source", "kind", "id", "ext", "url"),
            show="headings",
        )
        columns = [
            ("index", "#", 60, "e"),
            ("source", "Source", 90, "w"),
            ("kind", "Kind", 80, "w"),
            ("id", "Media ID", 170, "w"),
            ("ext", "Ext", 60, "w"),
            ("url", "Normalized URL", 520, "w"),
        ]
        for key, label, width, anchor in columns:
            self.plan_tree.heading(key, text=label)
            self.plan_tree.column(key, width=width, anchor=anchor)
        self.plan_tree.grid(row=0, column=0, sticky="nsew")
        plan_y = ttk.Scrollbar(plan_frame, orient="vertical", command=self.plan_tree.yview)
        plan_x = ttk.Scrollbar(plan_frame, orient="horizontal", command=self.plan_tree.xview)
        self.plan_tree.configure(yscrollcommand=plan_y.set, xscrollcommand=plan_x.set)
        plan_y.grid(row=0, column=1, sticky="ns")
        plan_x.grid(row=1, column=0, sticky="ew")

        manifest_frame = ttk.Frame(self.notebook, padding=8)
        manifest_frame.columnconfigure(0, weight=1)
        manifest_frame.rowconfigure(0, weight=1)
        self.notebook.add(manifest_frame, text="Manifest Preview")
        self.manifest_text = tk.Text(
            manifest_frame,
            wrap="none",
            font=("Consolas", 10),
            state="disabled",
        )
        self.manifest_text.grid(row=0, column=0, sticky="nsew")
        manifest_y = ttk.Scrollbar(
            manifest_frame, orient="vertical", command=self.manifest_text.yview
        )
        manifest_x = ttk.Scrollbar(
            manifest_frame, orient="horizontal", command=self.manifest_text.xview
        )
        self.manifest_text.configure(
            yscrollcommand=manifest_y.set,
            xscrollcommand=manifest_x.set,
        )
        manifest_y.grid(row=0, column=1, sticky="ns")
        manifest_x.grid(row=1, column=0, sticky="ew")

        results_frame = ttk.Frame(self.notebook, padding=8)
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        self.notebook.add(results_frame, text="Download Results")

        self.results_tree = ttk.Treeview(
            results_frame,
            columns=("status", "source", "file", "size", "sha", "detail"),
            show="headings",
        )
        result_columns = [
            ("status", "Status", 120, "w"),
            ("source", "Source", 90, "w"),
            ("file", "Filename", 270, "w"),
            ("size", "Size", 100, "e"),
            ("sha", "SHA-256", 150, "w"),
            ("detail", "Detail", 360, "w"),
        ]
        for key, label, width, anchor in result_columns:
            self.results_tree.heading(key, text=label)
            self.results_tree.column(key, width=width, anchor=anchor)
        self.results_tree.grid(row=0, column=0, sticky="nsew")
        results_y = ttk.Scrollbar(
            results_frame, orient="vertical", command=self.results_tree.yview
        )
        results_x = ttk.Scrollbar(
            results_frame, orient="horizontal", command=self.results_tree.xview
        )
        self.results_tree.configure(
            yscrollcommand=results_y.set,
            xscrollcommand=results_x.set,
        )
        results_y.grid(row=0, column=1, sticky="ns")
        results_x.grid(row=1, column=0, sticky="ew")

        log_frame = ttk.Frame(self.notebook, padding=8)
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.notebook.add(log_frame, text="Log")
        self.log_text = tk.Text(
            log_frame,
            wrap="word",
            font=("Consolas", 10),
            state="disabled",
        )
        self.log_text.grid(row=0, column=0, sticky="nsew")
        log_y = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_y.set)
        log_y.grid(row=0, column=1, sticky="ns")

        actions = ttk.Frame(outer)
        actions.grid(row=4, column=0, sticky="ew", pady=(10, 0))
        ttk.Label(actions, textvariable=self.status_var).pack(side="left")
        self.progress = ttk.Progressbar(actions, mode="indeterminate", length=120)
        self.progress.pack(side="left", padx=(12, 0))
        self.open_button = ttk.Button(
            actions, text="保存先を開く", command=self.open_output
        )
        self.open_button.pack(side="right")
        self.download_button = ttk.Button(
            actions,
            text="Download",
            command=self.download_current_plan,
            state="disabled",
        )
        self.download_button.pack(side="right", padx=(0, 6))
        self.save_button = ttk.Button(
            actions,
            text="Manifest保存",
            command=self.save_manifest,
            state="disabled",
        )
        self.save_button.pack(side="right", padx=(0, 6))

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-o>", lambda _event: self.load_url_file())
        self.bind("<F5>", lambda _event: self.build_plan())
        self.bind("<Control-s>", lambda _event: self.save_manifest())
        self.bind("<Control-l>", lambda _event: self.input_text.focus_set())

    def _replace_text(self, widget: tk.Text, text: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _append_log(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text.rstrip() + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def load_url_file(self) -> None:
        selected = filedialog.askopenfilename(
            title="URL一覧を選択",
            filetypes=[
                ("URL list", "*.txt *.tsv *.csv"),
                ("All files", "*.*"),
            ],
        )
        if not selected:
            return
        text = Path(selected).read_text(encoding="utf-8-sig", errors="replace")
        self.input_text.delete("1.0", "end")
        self.input_text.insert("1.0", text)
        self.status_var.set(f"読み込み: {Path(selected).name}")

    def clear_input(self) -> None:
        if self._busy:
            return
        self.input_text.delete("1.0", "end")
        self.current_plan = []
        self.current_results = []
        self.duplicates_removed = 0
        self._render_plan()
        self._render_results()
        self.status_var.set("入力をクリアしました。")

    def open_bridge_folder(self) -> None:
        bridge_dir = Path(__file__).resolve().parent / "browser_bridges"
        if os.name == "nt":
            os.startfile(bridge_dir)
        else:
            messagebox.showinfo(APP_TITLE, str(bridge_dir))

    def browse_output(self) -> None:
        selected = filedialog.askdirectory(
            title="出力フォルダ",
            initialdir=self.output_var.get() or str(Path.cwd()),
        )
        if selected:
            self.output_var.set(selected)

    def _validate_max_bytes(self) -> int:
        try:
            value = float(self.max_mib_var.get().strip())
        except ValueError as exc:
            raise ValueError("1ファイル上限は数値で入力してください。") from exc
        if value <= 0:
            raise ValueError("1ファイル上限は0より大きくしてください。")
        return int(value * 1024 * 1024)

    def build_plan(self) -> None:
        if self._busy:
            return
        text = self.input_text.get("1.0", "end-1c")
        if not text.strip():
            messagebox.showinfo(APP_TITLE, "URLを含むテキストを入力してください。")
            return
        try:
            plan, duplicates = build_plan_for_ui(text, self.source_var.get())
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return
        self.current_plan = plan
        self.current_results = []
        self.duplicates_removed = duplicates
        self._render_plan()
        self._render_results()
        self.status_var.set(
            f"Plan作成完了: {len(plan):,} unique / {duplicates:,} duplicate(s) removed"
        )
        self._append_log(
            f"[PLAN] unique={len(plan)} duplicates_removed={duplicates} source={self.source_var.get()}"
        )

    def _render_plan(self) -> None:
        for row in self.plan_tree.get_children():
            self.plan_tree.delete(row)

        for index, item in enumerate(self.current_plan, 1):
            self.plan_tree.insert(
                "",
                "end",
                values=(
                    index,
                    item.source,
                    item.kind,
                    item.media_id,
                    item.extension or "—",
                    redact_url_for_manifest(item.normalized_url),
                ),
            )

        summary = summarize_plan(self.current_plan, self.duplicates_removed)
        for key, value in summary.items():
            self.summary_vars[key].set(value)

        lines = [
            "index\tsource\tkind\tmedia_id\textension\tnormalized_url"
        ]
        for index, item in enumerate(self.current_plan, 1):
            lines.append(
                "\t".join(
                    [
                        str(index),
                        item.source,
                        item.kind,
                        item.media_id,
                        item.extension,
                        redact_url_for_manifest(item.normalized_url),
                    ]
                )
            )
        self._replace_text(self.manifest_text, "\n".join(lines))
        state = "normal" if self.current_plan else "disabled"
        self.save_button.configure(state=state)
        self.download_button.configure(state=state)

    def _render_results(self) -> None:
        for row in self.results_tree.get_children():
            self.results_tree.delete(row)

        for result in self.current_results:
            detail = result.error or redact_url_for_manifest(result.normalized_url)
            self.results_tree.insert(
                "",
                "end",
                values=(
                    result.status,
                    result.source,
                    result.filename or "—",
                    format_bytes(result.size_bytes),
                    (result.sha256[:16] + "…") if result.sha256 else "—",
                    detail,
                ),
            )

    def _output_dir(self) -> Path:
        raw = self.output_var.get().strip()
        if not raw:
            raise ValueError("出力フォルダを指定してください。")
        return Path(raw).expanduser().resolve()

    def save_manifest(self) -> None:
        if not self.current_plan or self._busy:
            return
        try:
            output = self._output_dir()
            json_path, tsv_path = write_plan_manifest(self.current_plan, output)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return
        self.status_var.set(f"Manifest保存: {output}")
        self._append_log(f"[MANIFEST] {json_path.name} / {tsv_path.name}")

    def download_current_plan(self) -> None:
        if not self.current_plan or self._busy:
            return
        try:
            output = self._output_dir()
            max_bytes = self._validate_max_bytes()
        except ValueError as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        plan = list(self.current_plan)
        allow_videos = self.allow_videos_var.get()

        def worker() -> None:
            try:
                results = download_plan(
                    plan,
                    output,
                    allow_videos=allow_videos,
                    max_bytes=max_bytes,
                )
                write_download_manifest(results, output)
                self.after(0, lambda: self._download_finished(results, output))
            except Exception as exc:
                trace = traceback.format_exc()
                self.after(
                    0,
                    lambda exc=exc, trace=trace: self._download_failed(exc, trace),
                )

        self._set_busy(True, "ダウンロード中…")
        threading.Thread(target=worker, daemon=True).start()

    def _download_finished(self, results, output: Path) -> None:
        self.current_results = list(results)
        self._render_results()
        if self.current_results:
            self.notebook.select(2)

        saved = sum(row.status == "saved" for row in results)
        errors = sum(row.status == "error" for row in results)
        other = len(results) - saved - errors
        for row in results:
            detail = row.filename or row.error or row.normalized_url
            self._append_log(f"[{row.status.upper()}] {detail}")
        self._set_busy(
            False,
            f"完了: saved={saved} / errors={errors} / other={other} / {output}",
        )

    def _download_failed(self, exc: Exception, trace: str) -> None:
        self._append_log(trace)
        self._set_busy(False, "ダウンロード処理でエラーが発生しました。")
        messagebox.showerror(APP_TITLE, str(exc))

    def _set_busy(self, busy: bool, status: str) -> None:
        self._busy = busy
        self.status_var.set(status)
        state = "disabled" if busy else "normal"
        self.plan_button.configure(state=state)
        if busy:
            self.save_button.configure(state="disabled")
            self.download_button.configure(state="disabled")
            self.progress.start(10)
        else:
            if self.current_plan:
                self.save_button.configure(state="normal")
                self.download_button.configure(state="normal")
            self.progress.stop()

    def open_output(self) -> None:
        try:
            output = self._output_dir()
            output.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return
        if os.name == "nt":
            os.startfile(output)
        else:
            messagebox.showinfo(APP_TITLE, str(output))


def main() -> None:
    app = MediaCollectorApp()
    app.mainloop()


if __name__ == "__main__":
    main()
