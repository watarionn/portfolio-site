from __future__ import annotations

import os
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from download_workbench_core import (
    DownloadRequest,
    DownloadWorkbenchError,
    MediaInfo,
    analyze_url,
    build_download_args,
    detect_tools,
    format_command_preview,
    format_size,
    format_timecode,
    redact_url,
    run_download,
)


APP_TITLE = "Download Workbench"
MODE_LABELS = {
    "Video": "video",
    "Audio": "audio",
    "Format ID": "format",
}


def build_request_from_fields(
    *,
    url: str,
    output_dir: str,
    mode_label: str,
    format_id: str,
    audio_format: str,
    range_start: str,
    range_end: str,
    precise_range: bool,
    subtitle_text: str,
    include_auto_subtitles: bool,
    write_metadata: bool,
    write_thumbnail: bool,
) -> DownloadRequest:
    languages = tuple(
        dict.fromkeys(
            part.strip()
            for part in subtitle_text.split(",")
            if part.strip()
        )
    )
    return DownloadRequest(
        url=url.strip(),
        output_dir=Path(output_dir).expanduser(),
        mode=MODE_LABELS.get(mode_label, "video"),
        format_id=format_id.strip(),
        audio_format=audio_format,
        range_start=range_start.strip(),
        range_end=range_end.strip(),
        precise_range=precise_range,
        subtitle_languages=languages,
        include_auto_subtitles=include_auto_subtitles,
        write_metadata=write_metadata,
        write_thumbnail=write_thumbnail,
    )


class DownloadWorkbenchApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1240x840")
        self.minsize(1040, 700)

        self.url_var = tk.StringVar()
        self.output_var = tk.StringVar(value=str(Path.cwd() / "downloads"))
        self.mode_var = tk.StringVar(value="Video")
        self.format_id_var = tk.StringVar()
        self.audio_format_var = tk.StringVar(value="m4a")
        self.start_var = tk.StringVar()
        self.end_var = tk.StringVar()
        self.precise_var = tk.BooleanVar(value=False)
        self.subtitle_var = tk.StringVar()
        self.auto_subs_var = tk.BooleanVar(value=False)
        self.metadata_var = tk.BooleanVar(value=False)
        self.thumbnail_var = tk.BooleanVar(value=False)
        self.rights_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="URLを入力してAnalyzeしてください。")
        self.command_var = tk.StringVar()

        self.summary_vars = {
            key: tk.StringVar(value="—")
            for key in ("title", "uploader", "duration", "extractor", "formats", "subtitles")
        }

        self.current_info: MediaInfo | None = None
        self._busy = False
        self.ytdlp_status, self.ffmpeg_status = detect_tools()

        self._configure_style()
        self._build_ui()
        self._bind_updates()
        self._refresh_tool_status()
        self._refresh_download_state()
        self._refresh_command_preview()

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        style.configure("Action.TButton", padding=(12, 6))
        style.configure("Summary.TLabel", font=("TkDefaultFont", 11, "bold"))
        style.configure("Treeview", rowheight=24)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(4, weight=1)

        source = ttk.LabelFrame(outer, text="URL", padding=10)
        source.grid(row=0, column=0, sticky="ew")
        source.columnconfigure(1, weight=1)

        ttk.Label(source, text="Media URL").grid(row=0, column=0, sticky="w")
        ttk.Entry(source, textvariable=self.url_var).grid(
            row=0, column=1, sticky="ew", padx=(8, 8)
        )
        self.analyze_button = ttk.Button(
            source, text="Analyze", command=self.analyze, style="Action.TButton"
        )
        self.analyze_button.grid(row=0, column=2)

        ttk.Label(source, text="Output").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(source, textvariable=self.output_var).grid(
            row=1, column=1, sticky="ew", padx=(8, 8), pady=(8, 0)
        )
        ttk.Button(source, text="選択", command=self.browse_output).grid(
            row=1, column=2, sticky="ew", pady=(8, 0)
        )

        tools = ttk.Frame(source)
        tools.grid(row=2, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        self.ytdlp_label = ttk.Label(tools)
        self.ytdlp_label.pack(side="left")
        self.ffmpeg_label = ttk.Label(tools)
        self.ffmpeg_label.pack(side="left", padx=(18, 0))
        ttk.Label(
            tools,
            text="認証回避・Cookie自動取得・DRM回避は行いません。",
        ).pack(side="right")

        summary = ttk.LabelFrame(outer, text="Analysis", padding=10)
        summary.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        for col in range(3):
            summary.columnconfigure(col, weight=1)

        fields = [
            ("Title", "title"),
            ("Uploader", "uploader"),
            ("Duration", "duration"),
            ("Extractor", "extractor"),
            ("Formats", "formats"),
            ("Subtitles", "subtitles"),
        ]
        for index, (label, key) in enumerate(fields):
            row, col = divmod(index, 3)
            frame = ttk.Frame(summary)
            frame.grid(row=row, column=col, sticky="ew", padx=(0 if col == 0 else 10, 0), pady=2)
            ttk.Label(frame, text=label + ":").pack(side="left")
            ttk.Label(
                frame,
                textvariable=self.summary_vars[key],
                style="Summary.TLabel",
            ).pack(side="left", padx=(6, 0))

        options = ttk.LabelFrame(outer, text="Download settings", padding=10)
        options.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        for col in range(8):
            options.columnconfigure(col, weight=1)

        ttk.Label(options, text="Mode").grid(row=0, column=0, sticky="w")
        ttk.Combobox(
            options,
            textvariable=self.mode_var,
            values=tuple(MODE_LABELS),
            state="readonly",
            width=12,
        ).grid(row=1, column=0, sticky="ew")

        ttk.Label(options, text="Format ID").grid(row=0, column=1, sticky="w", padx=(8, 0))
        ttk.Entry(options, textvariable=self.format_id_var, width=14).grid(
            row=1, column=1, sticky="ew", padx=(8, 0)
        )

        ttk.Label(options, text="Audio").grid(row=0, column=2, sticky="w", padx=(8, 0))
        ttk.Combobox(
            options,
            textvariable=self.audio_format_var,
            values=("m4a", "mp3", "wav", "flac", "opus"),
            state="readonly",
            width=10,
        ).grid(row=1, column=2, sticky="ew", padx=(8, 0))

        ttk.Label(options, text="Start").grid(row=0, column=3, sticky="w", padx=(8, 0))
        ttk.Entry(options, textvariable=self.start_var, width=12).grid(
            row=1, column=3, sticky="ew", padx=(8, 0)
        )
        ttk.Label(options, text="End").grid(row=0, column=4, sticky="w", padx=(8, 0))
        ttk.Entry(options, textvariable=self.end_var, width=12).grid(
            row=1, column=4, sticky="ew", padx=(8, 0)
        )
        ttk.Checkbutton(
            options, text="Precise range", variable=self.precise_var
        ).grid(row=1, column=5, sticky="w", padx=(8, 0))

        ttk.Label(options, text="Subtitle langs").grid(
            row=2, column=0, sticky="w", pady=(10, 0)
        )
        ttk.Entry(options, textvariable=self.subtitle_var).grid(
            row=3, column=0, columnspan=2, sticky="ew", pady=(2, 0)
        )
        ttk.Checkbutton(
            options, text="Auto subtitles", variable=self.auto_subs_var
        ).grid(row=3, column=2, sticky="w", padx=(8, 0))
        ttk.Checkbutton(
            options, text="Info JSON", variable=self.metadata_var
        ).grid(row=3, column=3, sticky="w", padx=(8, 0))
        ttk.Checkbutton(
            options, text="Thumbnail", variable=self.thumbnail_var
        ).grid(row=3, column=4, sticky="w", padx=(8, 0))

        ttk.Label(
            options,
            text="Time: seconds / MM:SS / HH:MM:SS",
        ).grid(row=3, column=5, columnspan=3, sticky="e")

        rights = ttk.Frame(outer)
        rights.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        ttk.Checkbutton(
            rights,
            text="このURLのコンテンツを保存する権限・許可があります",
            variable=self.rights_var,
        ).pack(side="left")
        self.download_button = ttk.Button(
            rights,
            text="Download",
            command=self.download,
            style="Action.TButton",
            state="disabled",
        )
        self.download_button.pack(side="right")
        ttk.Button(rights, text="保存先を開く", command=self.open_output).pack(
            side="right", padx=(0, 8)
        )

        self.notebook = ttk.Notebook(outer)
        self.notebook.grid(row=4, column=0, sticky="nsew", pady=(10, 0))

        formats_frame = ttk.Frame(self.notebook, padding=8)
        formats_frame.rowconfigure(0, weight=1)
        formats_frame.columnconfigure(0, weight=1)
        self.notebook.add(formats_frame, text="Formats")
        self.formats_tree = ttk.Treeview(
            formats_frame,
            columns=("id", "ext", "resolution", "fps", "video", "audio", "size", "note"),
            show="headings",
        )
        format_columns = [
            ("id", "ID", 90, "w"),
            ("ext", "Ext", 60, "w"),
            ("resolution", "Resolution", 110, "w"),
            ("fps", "FPS", 60, "e"),
            ("video", "Video codec", 150, "w"),
            ("audio", "Audio codec", 140, "w"),
            ("size", "Size", 95, "e"),
            ("note", "Note", 160, "w"),
        ]
        for key, label, width, anchor in format_columns:
            self.formats_tree.heading(key, text=label)
            self.formats_tree.column(key, width=width, anchor=anchor)
        self.formats_tree.grid(row=0, column=0, sticky="nsew")
        fy = ttk.Scrollbar(formats_frame, orient="vertical", command=self.formats_tree.yview)
        fx = ttk.Scrollbar(formats_frame, orient="horizontal", command=self.formats_tree.xview)
        self.formats_tree.configure(yscrollcommand=fy.set, xscrollcommand=fx.set)
        fy.grid(row=0, column=1, sticky="ns")
        fx.grid(row=1, column=0, sticky="ew")
        self.formats_tree.bind("<Double-1>", self._use_selected_format)

        subtitles_frame = ttk.Frame(self.notebook, padding=8)
        subtitles_frame.rowconfigure(0, weight=1)
        subtitles_frame.columnconfigure(0, weight=1)
        self.notebook.add(subtitles_frame, text="Subtitles")
        self.subtitles_tree = ttk.Treeview(
            subtitles_frame,
            columns=("language", "type", "ext"),
            show="headings",
        )
        self.subtitles_tree.heading("language", text="Language")
        self.subtitles_tree.heading("type", text="Type")
        self.subtitles_tree.heading("ext", text="Ext")
        self.subtitles_tree.column("language", width=180, anchor="w")
        self.subtitles_tree.column("type", width=160, anchor="w")
        self.subtitles_tree.column("ext", width=100, anchor="w")
        self.subtitles_tree.grid(row=0, column=0, sticky="nsew")
        sy = ttk.Scrollbar(subtitles_frame, orient="vertical", command=self.subtitles_tree.yview)
        self.subtitles_tree.configure(yscrollcommand=sy.set)
        sy.grid(row=0, column=1, sticky="ns")
        self.subtitles_tree.bind("<Double-1>", self._use_selected_subtitle)

        preview_frame = ttk.Frame(self.notebook, padding=8)
        preview_frame.rowconfigure(0, weight=1)
        preview_frame.columnconfigure(0, weight=1)
        self.notebook.add(preview_frame, text="Command Preview")
        self.command_text = tk.Text(
            preview_frame,
            wrap="word",
            font=("Consolas", 10),
            state="disabled",
        )
        self.command_text.grid(row=0, column=0, sticky="nsew")

        log_frame = ttk.Frame(self.notebook, padding=8)
        log_frame.rowconfigure(0, weight=1)
        log_frame.columnconfigure(0, weight=1)
        self.notebook.add(log_frame, text="Log")
        self.log_text = tk.Text(
            log_frame,
            wrap="word",
            font=("Consolas", 10),
            state="disabled",
        )
        self.log_text.grid(row=0, column=0, sticky="nsew")
        ly = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=ly.set)
        ly.grid(row=0, column=1, sticky="ns")

        bottom = ttk.Frame(outer)
        bottom.grid(row=5, column=0, sticky="ew", pady=(8, 0))
        ttk.Label(bottom, textvariable=self.status_var).pack(side="left")
        self.progress = ttk.Progressbar(bottom, mode="indeterminate", length=150)
        self.progress.pack(side="right")

    def _bind_updates(self) -> None:
        for var in (
            self.url_var,
            self.output_var,
            self.mode_var,
            self.format_id_var,
            self.audio_format_var,
            self.start_var,
            self.end_var,
            self.subtitle_var,
        ):
            var.trace_add("write", lambda *_: self._refresh_command_preview())
        for var in (
            self.precise_var,
            self.auto_subs_var,
            self.metadata_var,
            self.thumbnail_var,
        ):
            var.trace_add("write", lambda *_: self._refresh_command_preview())
        self.rights_var.trace_add("write", lambda *_: self._refresh_download_state())

    def _refresh_tool_status(self) -> None:
        yt = self.ytdlp_status
        ff = self.ffmpeg_status
        self.ytdlp_label.configure(
            text=f"yt-dlp: {yt.version or 'not found'}"
        )
        ff_version = "not found"
        if ff.version:
            ff_version = ff.version.split(" Copyright", 1)[0].replace("ffmpeg version ", "")
        self.ffmpeg_label.configure(text=f"ffmpeg: {ff_version}")

    def _replace_text(self, widget: tk.Text, text: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _append_log(self, line: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", line.rstrip() + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _current_request(self) -> DownloadRequest:
        return build_request_from_fields(
            url=self.url_var.get(),
            output_dir=self.output_var.get(),
            mode_label=self.mode_var.get(),
            format_id=self.format_id_var.get(),
            audio_format=self.audio_format_var.get(),
            range_start=self.start_var.get(),
            range_end=self.end_var.get(),
            precise_range=self.precise_var.get(),
            subtitle_text=self.subtitle_var.get(),
            include_auto_subtitles=self.auto_subs_var.get(),
            write_metadata=self.metadata_var.get(),
            write_thumbnail=self.thumbnail_var.get(),
        )

    def _refresh_command_preview(self) -> None:
        url = self.url_var.get().strip()
        if not url or not self.ytdlp_status.available:
            self._replace_text(self.command_text, "URLを入力すると実行予定コマンドを確認できます。")
            return
        try:
            args = build_download_args(
                self._current_request(),
                ytdlp_executable=self.ytdlp_status.path or "yt-dlp",
            )
            safe_args = list(args)
            if safe_args:
                safe_args[-1] = redact_url(safe_args[-1])
            self._replace_text(
                self.command_text,
                format_command_preview(safe_args),
            )
        except Exception as exc:
            self._replace_text(self.command_text, f"設定確認: {exc}")

    def _refresh_download_state(self) -> None:
        enabled = (
            not self._busy
            and self.rights_var.get()
            and self.ytdlp_status.available
            and self.ffmpeg_status.available
            and bool(self.url_var.get().strip())
        )
        self.download_button.configure(state="normal" if enabled else "disabled")

    def browse_output(self) -> None:
        selected = filedialog.askdirectory(
            title="保存先フォルダ",
            initialdir=self.output_var.get() or str(Path.cwd()),
        )
        if selected:
            self.output_var.set(selected)

    def open_output(self) -> None:
        path = Path(self.output_var.get()).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(path)
        else:
            messagebox.showinfo(APP_TITLE, str(path))

    def analyze(self) -> None:
        if self._busy:
            return
        url = self.url_var.get().strip()
        if not url:
            messagebox.showinfo(APP_TITLE, "URLを入力してください。")
            return
        if not self.ytdlp_status.available:
            messagebox.showerror(APP_TITLE, "yt-dlpが見つかりません。")
            return

        self._set_busy(True, "解析中…")

        def worker() -> None:
            try:
                info = analyze_url(
                    url,
                    ytdlp_executable=self.ytdlp_status.path or "yt-dlp",
                )
            except Exception as exc:
                self.after(0, lambda exc=exc: self._analyze_failed(exc))
                return
            self.after(0, lambda: self._analyze_finished(info))

        threading.Thread(target=worker, daemon=True).start()

    def _analyze_failed(self, exc: Exception) -> None:
        self.current_info = None
        self._set_busy(False, "解析に失敗しました。")
        self._append_log(f"[ANALYZE ERROR] {exc}")
        messagebox.showerror(APP_TITLE, str(exc))

    def _analyze_finished(self, info: MediaInfo) -> None:
        self.current_info = info
        self.summary_vars["title"].set(info.title)
        self.summary_vars["uploader"].set(info.uploader or "—")
        self.summary_vars["duration"].set(
            format_timecode(info.duration) if info.duration is not None else "—"
        )
        self.summary_vars["extractor"].set(info.extractor or "—")
        self.summary_vars["formats"].set(str(len(info.formats)))
        self.summary_vars["subtitles"].set(str(len(info.subtitles)))
        self._render_formats(info)
        self._render_subtitles(info)
        self._append_log(
            f"[ANALYZE] {info.title} / formats={len(info.formats)} / subtitles={len(info.subtitles)}"
        )
        self._set_busy(False, "解析完了。形式と字幕を確認できます。")

    def _render_formats(self, info: MediaInfo) -> None:
        for row in self.formats_tree.get_children():
            self.formats_tree.delete(row)
        for item in info.formats:
            self.formats_tree.insert(
                "",
                "end",
                values=(
                    item.format_id,
                    item.ext,
                    item.resolution,
                    "" if item.fps is None else f"{item.fps:g}",
                    item.vcodec,
                    item.acodec,
                    format_size(item.filesize),
                    item.note,
                ),
            )

    def _render_subtitles(self, info: MediaInfo) -> None:
        for row in self.subtitles_tree.get_children():
            self.subtitles_tree.delete(row)
        for item in info.subtitles:
            self.subtitles_tree.insert(
                "",
                "end",
                values=(
                    item.language,
                    "Automatic" if item.automatic else "Subtitle",
                    item.ext,
                ),
            )

    def _use_selected_format(self, _event=None) -> None:
        selection = self.formats_tree.selection()
        if not selection:
            return
        values = self.formats_tree.item(selection[0], "values")
        if values:
            self.format_id_var.set(str(values[0]))
            self.mode_var.set("Format ID")
            self.status_var.set(f"Format ID {values[0]} を選択しました。")

    def _use_selected_subtitle(self, _event=None) -> None:
        selection = self.subtitles_tree.selection()
        if not selection:
            return
        values = self.subtitles_tree.item(selection[0], "values")
        if not values:
            return
        language = str(values[0])
        current = [x.strip() for x in self.subtitle_var.get().split(",") if x.strip()]
        if language not in current:
            current.append(language)
        self.subtitle_var.set(",".join(current))

    def download(self) -> None:
        if self._busy:
            return
        if not self.rights_var.get():
            messagebox.showinfo(APP_TITLE, "保存権限・許可の確認が必要です。")
            return
        try:
            request = self._current_request()
            build_download_args(
                request,
                ytdlp_executable=self.ytdlp_status.path or "yt-dlp",
            )
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self.notebook.select(3)
        self._append_log(f"[START] {redact_url(request.url)}")
        self._set_busy(True, "ダウンロード中…")

        def line_callback(line: str) -> None:
            self.after(0, lambda line=line: self._append_log(line))

        def worker() -> None:
            try:
                result = run_download(
                    request,
                    ytdlp_executable=self.ytdlp_status.path or "yt-dlp",
                    line_callback=line_callback,
                )
            except Exception as exc:
                self.after(0, lambda exc=exc: self._download_failed(exc))
                return
            self.after(0, lambda: self._download_finished(result.returncode))

        threading.Thread(target=worker, daemon=True).start()

    def _download_failed(self, exc: Exception) -> None:
        self._append_log(f"[ERROR] {exc}")
        self._set_busy(False, "ダウンロード処理に失敗しました。")
        messagebox.showerror(APP_TITLE, str(exc))

    def _download_finished(self, returncode: int) -> None:
        if returncode == 0:
            self._append_log("[DONE] completed")
            self._set_busy(False, "完了しました。")
        else:
            self._append_log(f"[FAILED] exit={returncode}")
            self._set_busy(False, f"yt-dlpが終了コード{returncode}で終了しました。")

    def _set_busy(self, busy: bool, status: str) -> None:
        self._busy = busy
        self.status_var.set(status)
        self.analyze_button.configure(state="disabled" if busy else "normal")
        if busy:
            self.progress.start(10)
        else:
            self.progress.stop()
        self._refresh_download_state()


def main() -> None:
    app = DownloadWorkbenchApp()
    app.mainloop()


if __name__ == "__main__":
    main()
