# Changelog

## v0.6.0 - Phase 03B - 2026-09-18

- Added sine / triangle / square / saw oscillator palette.
- Added track-specific layered synth presets for Melody, Chords and Bass.
- Added deterministic moving-average low-pass filtering.
- Added finite-tap stereo delay and reverb.
- Added track balance and master soft saturation.
- Added Phase 03B 44.1 kHz stereo PCM16 master WAV rendering.
- Added optional ffmpeg/libvorbis OGG preview export without making ffmpeg a Python dependency.
- Added `portfolio_audio.json` with browser source order and section start seconds.
- Added five Phase 03B tests; full suite is 18/18 PASS.
- Confirmed zero full-scale PCM samples and valid 44.1 kHz stereo Vorbis decode.
- Preserved Phase 03A renderer and all earlier regression paths.

## v0.5.0 - Phase 03A

- Added deterministic MIDI parser and TimedNote rendering path.
- Added NumPy additive-sine synthesizer with track-specific ADSR voices.
- Added deterministic procedural kick/snare/hat/crash synthesis.
- Added stereo equal-power panning and mixer.
- Added peak normalization and PCM16 WAV writer.
- Added `config/phase03a_synth.json` and `run_phase03a.bat`.
- Added Phase 03A manifest with audio metrics and section markers.
- Added four Phase 03A tests; full suite is 13/13 PASS.
- Rendered Phase 02B best candidate to 44.1 kHz stereo WAV.

## 0.4.0 - 2026-09-18

- Completed Phase 02B musicality and evaluation engine.
- Added major/minor scale and diatonic-triad support.
- Added harmonic-minor dominant `V` for minor-key cadences.
- Added section rhythm styles and controlled non-chord tones.
- Added half/authentic cadence grammar and section transition fills.
- Added six-axis deterministic candidate scoring and ranking.
- Added algorithm-selected best MIDI while keeping human selection explicitly separate.
- Added eight-candidate A minor evaluation set and Phase 02B manifest.
- Expanded automated tests from 4 to 9; all pass.

## 0.3.0 - 2026-09-18

- Added Phase 02A structured composition engine.
- Added deterministic one-bar motif generation and section-aware development.
- Added A / B / Chorus form with per-section progression, density, register, and energy.
- Added MIDI conductor-track section markers.
- Added Phase 02 manifest suitable for future portfolio visualization.
- Added Phase 02 automated tests.

## 0.2.0 - 2026-09-16

- Added multi-candidate generation.
- Added composition presets.
- Added static candidate manifest export.
- Added future Portfolio City integration document.

## 0.1.0 - 2026-09-04

- Initial deterministic MIDI composition MVP.
