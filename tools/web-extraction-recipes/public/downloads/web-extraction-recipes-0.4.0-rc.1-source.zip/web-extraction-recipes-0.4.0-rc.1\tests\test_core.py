from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from extraction_core import (
    ExtractionError,
    extract_records,
    load_recipe,
    parse_html,
    recipe_from_dict,
    select,
    write_records,
)


HTML = """<!doctype html>
<html>
<body>
  <div class="card featured" data-kind="item">
    <a class="title" href="/detail/?id=abc123">
      <span class="label">New</span>
      <span class="main"> First   Item </span>
    </a>
    <a class="person" href="/people/?person=42"> Alice </a>
  </div>
  <div class="card" data-kind="item">
    <a class="title" href="https://example.test/detail/?id=xyz789">
      <span class="main">Second Item</span>
    </a>
  </div>
</body>
</html>"""


RECIPE = {
    "name": "Card demo",
    "base_url": "https://example.test/",
    "row_selector": "div.card[data-kind='item']",
    "fields": [
        {
            "name": "title",
            "selector": "a.title span.main",
            "source": "text",
        },
        {
            "name": "detail_url",
            "selector": "a.title",
            "source": "attr",
            "attr": "href",
            "urljoin": True,
        },
        {
            "name": "item_id",
            "selector": "a.title",
            "source": "attr",
            "attr": "href",
            "regex": r"[?&]id=([^&]+)",
            "group": 1,
        },
        {
            "name": "person",
            "selector": "a[href*='/people/']",
            "source": "text",
            "default": "",
        },
    ],
}


class SelectorTests(unittest.TestCase):
    def test_class_and_attribute_selector(self) -> None:
        root = parse_html(HTML)
        rows = select(root, "div.card[data-kind='item']")
        self.assertEqual(len(rows), 2)

    def test_descendant_selector(self) -> None:
        root = parse_html(HTML)
        rows = select(root, "div.card a.title span.main")
        self.assertEqual([node.text() for node in rows], ["First Item", "Second Item"])

    def test_contains_attribute_selector(self) -> None:
        root = parse_html(HTML)
        rows = select(root, "a[href*='/people/']")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].text(), "Alice")


class RecipeTests(unittest.TestCase):
    def test_extract_records(self) -> None:
        recipe = recipe_from_dict(RECIPE)
        rows = extract_records(HTML, recipe)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["title"], "First Item")
        self.assertEqual(rows[0]["item_id"], "abc123")
        self.assertEqual(rows[0]["person"], "Alice")
        self.assertEqual(
            rows[0]["detail_url"],
            "https://example.test/detail/?id=abc123",
        )
        self.assertEqual(rows[1]["person"], "")

    def test_duplicate_field_names_rejected(self) -> None:
        bad = dict(RECIPE)
        bad["fields"] = [
            {"name": "x", "selector": "a"},
            {"name": "x", "selector": "b"},
        ]
        with self.assertRaises(ExtractionError):
            recipe_from_dict(bad)

    def test_load_recipe(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "recipe.json"
            path.write_text(json.dumps(RECIPE), encoding="utf-8")
            recipe = load_recipe(path)
            self.assertEqual(recipe.name, "Card demo")

    def test_write_tsv_csv_json(self) -> None:
        rows = extract_records(HTML, recipe_from_dict(RECIPE))
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            tsv = write_records(rows, base / "out.tsv")
            csv_path = write_records(rows, base / "out.csv")
            json_path = write_records(rows, base / "out.json")
            self.assertIn("First Item", tsv.read_text(encoding="utf-8"))
            self.assertIn("Second Item", csv_path.read_text(encoding="utf-8"))
            loaded = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(loaded[0]["item_id"], "abc123")


if __name__ == "__main__":
    unittest.main()
