from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import replace
from pathlib import Path

from python_music_lab.evaluator import evaluate_song
from python_music_lab.midi_writer import write_song
from python_music_lab.structured_composer import (
    compose_structured_song,
    load_structured_config,
    section_degree,
    section_markers,
)


TRACK_SPECS = [
    ("Melody", 0, 0),
    ("Chords", 4, 1),
    ("Bass", 33, 2),
    ("Drums", 0, 9),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def section_manifest(config) -> list[dict[str, object]]:
    rows = []
    start_bar = 1
    for section in config.sections:
        effective = [section_degree(config, section, bar) for bar in range(section.bars)]
        rows.append(
            {
                "name": section.name,
                "start_bar": start_bar,
                "bars": section.bars,
                "progression": section.progression,
                "effective_progression": effective,
                "melody_density": section.melody_density,
                "register_shift": section.register_shift,
                "energy": section.energy,
                "rhythm_style": section.rhythm_style,
                "non_chord_tone_rate": section.non_chord_tone_rate,
                "cadence": section.cadence,
            }
        )
        start_bar += section.bars
    return rows


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    config_path = project_root / "config" / "phase02b_song.json"
    output_dir = project_root / "output" / "phase02b"
    candidates_dir = output_dir / "candidates"
    manifest_path = output_dir / "manifest.json"
    selection_path = output_dir / "selection.json"
    best_path = output_dir / "best_candidate.mid"

    base_config = load_structured_config(config_path)
    candidates_dir.mkdir(parents=True, exist_ok=True)

    generated = []
    for index in range(base_config.candidate_count):
        seed = base_config.seed + index
        config = replace(base_config, seed=seed)
        song, motif = compose_structured_song(config)
        candidate_id = f"candidate_{index + 1:02d}"
        midi_path = candidates_dir / f"{candidate_id}.mid"
        tracks = [(name, song[name], program, channel) for name, program, channel in TRACK_SPECS]
        write_song(
            output_path=midi_path,
            bpm=config.bpm,
            ticks_per_beat=config.ticks_per_beat,
            tracks=tracks,
            markers=section_markers(config),
        )
        evaluation = evaluate_song(config, song)
        generated.append(
            {
                "id": candidate_id,
                "seed": seed,
                "score": evaluation.total_score,
                "metrics": evaluation.to_dict(),
                "note_counts": {name: len(song[name]) for name, _, _ in TRACK_SPECS},
                "motif": [
                    {"scale_offset": step.scale_offset, "duration_steps": step.duration_steps}
                    for step in motif
                ],
                "midi_file": str(midi_path.relative_to(output_dir)).replace("\\", "/"),
                "sha256": sha256(midi_path),
            }
        )

    ranking = sorted(generated, key=lambda item: (-item["score"], item["seed"]))
    for rank, item in enumerate(ranking, start=1):
        item["rank"] = rank

    selected = ranking[0]
    shutil.copyfile(output_dir / selected["midi_file"], best_path)

    duration_seconds = base_config.total_bars * 4 * 60.0 / base_config.bpm
    manifest = {
        "schema_version": 3,
        "generator": "Python Music Lab Phase 02B",
        "title": base_config.title,
        "base_seed": base_config.seed,
        "candidate_count": base_config.candidate_count,
        "bpm": base_config.bpm,
        "key": f"{base_config.key_root} {base_config.mode}",
        "bars": base_config.total_bars,
        "duration_seconds": round(duration_seconds, 3),
        "sections": section_manifest(base_config),
        "evaluation_weights": {
            "harmony": 0.25,
            "motion": 0.20,
            "range": 0.15,
            "section_contrast": 0.15,
            "cadence": 0.15,
            "rhythm": 0.10,
        },
        "ranking": ranking,
        "algorithm_selected": selected["id"],
        "best_midi_file": best_path.name,
        "best_sha256": sha256(best_path),
        "portfolio_ready": True,
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    selection = {
        "schema_version": 1,
        "algorithm_selected": selected["id"],
        "human_selected": None,
        "human_notes": [],
        "rule": "Algorithmic score narrows candidates; final musical adoption remains a human listening decision.",
    }
    selection_path.write_text(json.dumps(selection, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"Title      : {base_config.title}")
    print(f"Candidates : {base_config.candidate_count}")
    print(f"BPM / Key  : {base_config.bpm} / {base_config.key_root} {base_config.mode}")
    print("Ranking:")
    for item in ranking:
        print(f"  #{item['rank']} {item['id']} seed={item['seed']} score={item['score']:.3f}")
    print(f"Best       : {best_path}")
    print(f"Manifest   : {manifest_path}")
    print(f"Selection  : {selection_path}")


if __name__ == "__main__":
    main()
