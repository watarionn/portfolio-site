# Phase 2 QA

Date: 2026-09-25

## Goal

Add a Windows desktop workspace around the offline recipe engine without introducing network access.

## GUI workflow

1. Choose a local HTML file.
2. Load or edit a Recipe JSON.
3. Validate the recipe.
4. Run Extraction Preview.
5. Review rows and fields in a table.
6. Export the current in-memory result as TSV, CSV, or JSON.

## GUI scope

- HTML file picker
- Recipe JSON file picker
- editable JSON recipe pane
- recipe validation
- recipe save
- background extraction worker
- summary: recipe / rows / fields / input size
- dynamic preview table
- export using the already extracted in-memory records
- log tab
- stale-result invalidation when input HTML or recipe text changes

## Boundary

Phase 2 remains fully offline.

There is no HTTP request, cookie handling, browser automation, login flow, or access-control bypass in the GUI.

Network collection will be added only after the offline extraction layer is stable.