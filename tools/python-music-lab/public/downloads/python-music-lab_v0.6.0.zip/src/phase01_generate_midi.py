from __future__ import annotations

from pathlib import Path

from python_music_lab.composer import compose_song, load_config
from python_music_lab.midi_writer import write_song


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    config_path = project_root / "config" / "song.json"
    output_path = project_root / "output" / "phase01_song.mid"

    config = load_config(config_path)
    song = compose_song(config)

    tracks = [
        ("Melody", song["Melody"], 0, 0),        # Acoustic Grand Piano
        ("Chords", song["Chords"], 4, 1),        # Electric Piano 1
        ("Bass", song["Bass"], 33, 2),            # Electric Bass (finger)
        ("Drums", song["Drums"], 0, 9),           # General MIDI drum channel
    ]

    write_song(
        output_path=output_path,
        bpm=config.bpm,
        ticks_per_beat=config.ticks_per_beat,
        tracks=tracks,
    )

    print(f"Title : {config.title}")
    print(f"Key   : {config.key_root} {config.mode}")
    print(f"BPM   : {config.bpm}")
    print(f"Seed  : {config.seed}")
    print(f"Bars  : {config.bars}")
    print(f"Output: {output_path}")


if __name__ == "__main__":
    main()
