from __future__ import annotations

import json
import subprocess
import sys
import unittest
from dataclasses import replace
from pathlib import Path

from mido import MidiFile

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from python_music_lab.evaluator import evaluate_song  # noqa: E402
from python_music_lab.music_theory import diatonic_triad, scale_midi  # noqa: E402
from python_music_lab.structured_composer import (  # noqa: E402
    compose_structured_song,
    load_structured_config,
    section_degree,
)


class Phase02BTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_structured_config(PROJECT_ROOT / "config" / "phase02b_song.json")

    def test_minor_scale_and_harmonic_dominant(self) -> None:
        self.assertEqual(scale_midi("A", "minor", 4), [69, 71, 72, 74, 76, 77, 79])
        # A minor V = E-G#-B when uppercase V requests harmonic-minor dominant.
        self.assertEqual(diatonic_triad("A", "V", 4, "minor"), [76, 80, 83])

    def test_section_cadence_grammar(self) -> None:
        a, b, chorus = self.config.sections
        self.assertEqual(section_degree(self.config, a, 7), "V")
        self.assertEqual(section_degree(self.config, b, 7), "V")
        self.assertEqual(section_degree(self.config, chorus, 6), "V")
        self.assertEqual(section_degree(self.config, chorus, 7), "i")

    def test_evaluation_is_deterministic_and_bounded(self) -> None:
        song_a, _ = compose_structured_song(self.config)
        song_b, _ = compose_structured_song(self.config)
        score_a = evaluate_song(self.config, song_a)
        score_b = evaluate_song(self.config, song_b)
        self.assertEqual(score_a, score_b)
        self.assertGreaterEqual(score_a.total_score, 0.0)
        self.assertLessEqual(score_a.total_score, 100.0)
        self.assertEqual(score_a.cadence_resolution_ratio, 1.0)

    def test_different_seeds_can_produce_different_scores(self) -> None:
        scores = []
        for offset in range(4):
            config = replace(self.config, seed=self.config.seed + offset)
            song, _ = compose_structured_song(config)
            scores.append(evaluate_song(config, song).total_score)
        self.assertGreater(len(set(scores)), 1)

    def test_phase02b_script_writes_ranked_manifest_and_valid_midi(self) -> None:
        subprocess.run(
            [sys.executable, str(PROJECT_ROOT / "src" / "phase02b_generate_and_rank.py")],
            cwd=PROJECT_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        manifest_path = PROJECT_ROOT / "output" / "phase02b" / "manifest.json"
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        ranking = data["ranking"]
        self.assertEqual(len(ranking), self.config.candidate_count)
        self.assertEqual([row["rank"] for row in ranking], list(range(1, self.config.candidate_count + 1)))
        scores = [row["score"] for row in ranking]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertEqual(data["algorithm_selected"], ranking[0]["id"])
        best_path = PROJECT_ROOT / "output" / "phase02b" / data["best_midi_file"]
        midi = MidiFile(best_path)
        markers = [message.text for message in midi.tracks[0] if message.type == "marker"]
        self.assertEqual(markers, ["A", "B", "Chorus"])


if __name__ == "__main__":
    unittest.main()
