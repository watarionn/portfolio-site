param(
    [switch]$SkipPreflight
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location -LiteralPath $root

if (-not $SkipPreflight) {
    & (Join-Path $PSScriptRoot 'preflight.ps1')
    if ($LASTEXITCODE -ne 0) { throw 'preflight failed' }
}

$version = (Get-Content -LiteralPath 'VERSION' -Raw).Trim()
$packageName = "web-extraction-recipes-$version"
$dist = Join-Path $root 'dist'
$stageBase = Join-Path $env:TEMP ("wer-release-" + [guid]::NewGuid().ToString('N'))
$stageRoot = Join-Path $stageBase $packageName
New-Item -ItemType Directory -Force -Path $dist,$stageRoot | Out-Null

$topFiles = @(
    '.gitignore','README.md','CHANGELOG.md','VERSION',
    'app.py','crawl.py','crawl_core.py','extract.py','extraction_core.py',
    'PHASE1_QA.md','PHASE2_QA.md','PHASE3_QA.md','PHASE4_RC_QA.md',
    'run_web_extraction_recipes.bat'
)
foreach ($file in $topFiles) {
    Copy-Item -LiteralPath (Join-Path $root $file) -Destination (Join-Path $stageRoot $file)
}

foreach ($dir in @('docs','qa','recipes','tests','tools')) {
    $sourceDir = Join-Path $root $dir
    Get-ChildItem -LiteralPath $sourceDir -Recurse -File | Where-Object {
        $_.Extension -ne '.pyc' -and $_.FullName -notmatch '[\\/]__pycache__[\\/]'
    } | ForEach-Object {
        $relative = $_.FullName.Substring($root.Length).TrimStart('\','/')
        $target = Join-Path $stageRoot $relative
        $targetDir = Split-Path -Parent $target
        New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
        Copy-Item -LiteralPath $_.FullName -Destination $target
    }
}

$zip = Join-Path $dist ($packageName + '-source.zip')
$shaFile = $zip + '.sha256'
Remove-Item -LiteralPath $zip,$shaFile -Force -ErrorAction SilentlyContinue
Compress-Archive -LiteralPath $stageRoot -DestinationPath $zip -CompressionLevel Optimal
$hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
$line = "$hash *$([IO.Path]::GetFileName($zip))"
[IO.File]::WriteAllText($shaFile, $line + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))

Write-Host "RELEASE_ZIP=$zip"
Write-Host "SHA256=$hash"
Write-Host "SHA256_FILE=$shaFile"

Remove-Item -LiteralPath $stageBase -Recurse -Force
Write-Host 'RELEASE_BUILD=PASS'
