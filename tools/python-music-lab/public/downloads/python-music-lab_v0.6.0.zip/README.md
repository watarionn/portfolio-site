# Python作曲研究所 / Python Music Lab

Pythonで「作曲」「MIDI」「音響合成」「生成AI」を段階的に研究し、最後にひとつの作曲環境へ統合するプロジェクト。

## Current status

- Phase 01: MIDI生成 + ルール作曲 ✅
- Phase 01.5: 複数候補生成 + 比較用manifest ✅
- Phase 02A: モチーフ + A/B/Chorus曲構成 ✅
- Phase 02B: Major/Minor + 音楽性 + 候補評価 ✅
- Phase 03A: Python Synth / MIDI → WAV MVP ✅
- Phase 03B: 音色・Filter・空間処理 + OGG / Portfolio audio contract ✅
- Phase 04: 生成AI連携 ← Next
- Phase 05: 統合作曲環境 / GUI / Portfolio City

## Setup

Windows 11:

1. `setup.bat`
2. Phase 01: `run_phase01.bat`
3. Phase 01.5: `run_phase015.bat`
4. Phase 02A: `run_phase02.bat`
5. Phase 02B: `run_phase02b.bat`
6. Phase 03A: `run_phase03a.bat`
7. Phase 03B: `run_phase03b.bat`

Phase 03BのWAV生成にはPython依存だけで足ります。OGG/Vorbis previewも生成する場合は`ffmpeg`がPATH上に必要です。ffmpegが無い場合も処理は失敗扱いにせず、WAV成果物とmanifestを残します。

## Phase 03A

Phase 03Aは、Phase 02Bで選ばれたMIDIを外部ソフト音源に頼らずPython自身で音声化する最初のRendering Layerです。

実装済み:

- MIDI note event parser
- MIDI note → Hz変換
- deterministic additive sine oscillator
- track別ADSR envelope
- Melody / Chords / Bassの簡易音色
- procedural drum synth
- stereo panning / mixer
- deterministic peak normalization
- PCM16 stereo WAV export
- WAV SHA-256再現性
- clipping / format QA

## Phase 03B

Phase 03Aの作曲内容を変更せず、Rendering Layerだけを強化します。

実装済み:

- sine / triangle / square / saw oscillator palette
- Melody: detuned saw + sine layer
- Chords: triangle + sine layer
- Bass: square + sine layers
- track別ADSR / pan / gain
- deterministic moving-average low-pass filter
- finite-tap stereo Delay
- finite-tap stereo Reverb
- master soft saturation
- track balance
- 44.1 kHz stereo PCM16 master WAV
- optional OGG/Vorbis preview export via ffmpeg
- Portfolio City向け `portfolio_audio.json`
- section start seconds付き A / B / Chorus metadata
- clipping / codec / reproducibility QA

デフォルト成果物:

```text
output/phase03b/
├─ best_candidate_master.wav
├─ best_candidate_preview.ogg   # ffmpeg利用可能時
├─ manifest.json
└─ portfolio_audio.json
```

基準レンダーは約47.4秒。WAVは約8 MB、OGG previewは約644 KBで、Portfolio CityではOGGを優先しWAVをfallbackにする契約です。

## Architecture principle

CompositionとRenderingを分離します。

```text
Music Theory
    ↓
Composition
    ↓
Note Events / MIDI
    ↓
Rendering
    ├─ MIDI
    ├─ Python Synth → WAV / OGG
    └─ next: AI / stems
```

同じ曲データから音源だけを差し替えられる構造を維持します。

See:

- `docs/ARCHITECTURE.md`
- `docs/PHASE02_COMPOSITION_MODEL.md`
- `docs/PHASE02B_EVALUATION.md`
- `docs/PHASE03A_SYNTH.md`
- `docs/PHASE03B_SOUND_DESIGN.md`
- `docs/PORTFOLIO_INTEGRATION.md`
