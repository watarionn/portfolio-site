@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo .venv was not found. Run setup.bat first.
    exit /b 1
)

.venv\Scripts\python.exe src\phase01_generate_midi.py
if errorlevel 1 exit /b 1

echo.
echo MIDI generation completed.
endlocal
