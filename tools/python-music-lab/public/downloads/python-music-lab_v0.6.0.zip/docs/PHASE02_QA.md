# Phase 02A QA

Date: 2026-09-18

## Generated reference song

- Title: Phase 02 Structured Pop
- Seed: 2026091801
- Key: C major
- BPM: 132
- Form: A 8 bars -> B 8 bars -> Chorus 8 bars
- Total: 24 bars
- Duration: 43.636 seconds
- MIDI tracks: 5
- SHA-256: `3d93be486bdd15bd625721350a891a56fd2b7d227c0b0955daaa73b8e4c082c1`

## Musical structure checks

| Section | Melody notes | Average MIDI pitch | Range |
|---|---:|---:|---|
| A | 43 | 63.51 | 60-69 |
| B | 43 | 66.49 | 60-71 |
| Chorus | 55 | 78.69 | 72-84 |

The chorus is intentionally denser and substantially higher than A, so the arrangement has a measurable section lift rather than only a renamed boundary.

## Automated checks

- Phase 02 tests: 4/4 PASS
- Seed determinism: PASS
- Byte-identical MIDI regeneration: PASS
- MIDI section markers: A / B / Chorus PASS
- Phase 01 regression generation: PASS
- Phase 01.5 regression generation: PASS
- Windows `run_phase02.bat`: CP932 + CRLF PASS
