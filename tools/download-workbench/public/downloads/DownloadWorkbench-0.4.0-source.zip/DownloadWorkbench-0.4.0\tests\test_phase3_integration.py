from __future__ import annotations

import http.server
import json
import re
import shutil
import subprocess
import tempfile
import threading
import unittest
from pathlib import Path

from download_workbench_core import DownloadRequest, analyze_url, run_download


TOOLS_AVAILABLE = all(
    shutil.which(name) for name in ("yt-dlp", "ffmpeg", "ffprobe")
)


class RangeMediaServer:
    def __init__(self, source: Path):
        self.source = source
        source_path = source

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass

            def _serve(self, body: bool) -> None:
                if self.path != "/demo.mp4":
                    self.send_error(404)
                    return

                total = source_path.stat().st_size
                start = 0
                end = total - 1
                status = 200

                range_header = self.headers.get("Range")
                if range_header:
                    match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
                    if not match:
                        self.send_error(416)
                        return
                    if match.group(1):
                        start = int(match.group(1))
                    if match.group(2):
                        end = min(int(match.group(2)), total - 1)
                    if start >= total or start > end:
                        self.send_error(416)
                        return
                    status = 206

                length = end - start + 1
                self.send_response(status)
                self.send_header("Content-Type", "video/mp4")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(length))
                if status == 206:
                    self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
                self.end_headers()

                if not body:
                    return

                try:
                    with source_path.open("rb") as handle:
                        handle.seek(start)
                        remaining = length
                        while remaining:
                            chunk = handle.read(min(65536, remaining))
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            remaining -= len(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    pass

            def do_GET(self):
                self._serve(True)

            def do_HEAD(self):
                self._serve(False)

        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self) -> str:
        self.thread.start()
        return f"http://127.0.0.1:{self.server.server_address[1]}/demo.mp4"

    def __exit__(self, exc_type, exc, tb):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)


def make_fixture(path: Path, duration: int = 6) -> None:
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=480x270:rate=24",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=440:sample_rate=48000",
            "-t",
            str(duration),
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-shortest",
            str(path),
            "-loglevel",
            "error",
        ],
        check=True,
    )


def probe(path: Path) -> tuple[float, set[str]]:
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration:stream=codec_type",
            "-of",
            "json",
            str(path),
        ],
        check=True,
        text=True,
        encoding="utf-8",
        stdout=subprocess.PIPE,
    )
    data = json.loads(completed.stdout)
    duration = float(data["format"]["duration"])
    streams = {str(stream["codec_type"]) for stream in data.get("streams", [])}
    return duration, streams


@unittest.skipUnless(TOOLS_AVAILABLE, "yt-dlp, ffmpeg and ffprobe are required")
class Phase3IntegrationTests(unittest.TestCase):
    def test_real_download_modes_and_range(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "demo.mp4"
            make_fixture(source)

            with RangeMediaServer(source) as url:
                info = analyze_url(url)
                self.assertGreaterEqual(len(info.formats), 1)
                explicit_id = info.formats[0].format_id

                cases = {
                    "video": DownloadRequest(
                        url=url,
                        output_dir=root / "video",
                        mode="video",
                        write_metadata=False,
                    ),
                    "audio": DownloadRequest(
                        url=url,
                        output_dir=root / "audio",
                        mode="audio",
                        audio_format="m4a",
                        write_metadata=False,
                    ),
                    "format": DownloadRequest(
                        url=url,
                        output_dir=root / "format",
                        mode="format",
                        format_id=explicit_id,
                        write_metadata=False,
                    ),
                    "range": DownloadRequest(
                        url=url,
                        output_dir=root / "range",
                        mode="video",
                        range_start="1",
                        range_end="4",
                        precise_range=True,
                        write_metadata=False,
                    ),
                }

                outputs: dict[str, Path] = {}
                for name, request in cases.items():
                    result = run_download(request)
                    self.assertEqual(result.returncode, 0, msg=result.stdout[-2000:])
                    media_files = [
                        path
                        for path in request.output_dir.iterdir()
                        if path.suffix.lower()
                        in {".mp4", ".m4a", ".mp3", ".wav", ".flac", ".opus", ".webm", ".mkv"}
                    ]
                    self.assertEqual(len(media_files), 1)
                    outputs[name] = media_files[0]

                video_duration, video_streams = probe(outputs["video"])
                audio_duration, audio_streams = probe(outputs["audio"])
                format_duration, format_streams = probe(outputs["format"])
                range_duration, range_streams = probe(outputs["range"])

                self.assertGreater(video_duration, 5.5)
                self.assertEqual(video_streams, {"video", "audio"})
                self.assertGreater(audio_duration, 5.5)
                self.assertEqual(audio_streams, {"audio"})
                self.assertGreater(format_duration, 5.5)
                self.assertIn("video", format_streams)
                self.assertGreaterEqual(range_duration, 2.5)
                self.assertLessEqual(range_duration, 3.6)
                self.assertEqual(range_streams, {"video", "audio"})


if __name__ == "__main__":
    unittest.main()
