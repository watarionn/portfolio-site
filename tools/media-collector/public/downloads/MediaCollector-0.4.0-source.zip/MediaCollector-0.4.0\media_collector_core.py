from __future__ import annotations

import csv
import hashlib
import json
import mimetypes
import os
import re
import tempfile
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Iterator


URL_RE = re.compile(r"https?://[^\s\t,]+", re.IGNORECASE)
SAFE_CHARS_RE = re.compile(r"[^A-Za-z0-9._-]+")
KNOWN_IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "webp", "gif", "avif"}
KNOWN_VIDEO_EXTENSIONS = {"mp4", "webm", "mov", "m4v"}
DEFAULT_MAX_BYTES = 100 * 1024 * 1024
SENSITIVE_QUERY_KEYS = {
    "token",
    "access_token",
    "refresh_token",
    "auth",
    "authorization",
    "signature",
    "sig",
    "key",
    "api_key",
    "apikey",
    "x-amz-signature",
    "x-amz-credential",
    "x-goog-signature",
    "x-goog-credential",
    "policy",
    "key-pair-id",
}


class MediaCollectorError(RuntimeError):
    pass


@dataclass(frozen=True)
class MediaItem:
    source: str
    source_url: str
    normalized_url: str
    media_id: str
    extension: str
    kind: str


@dataclass(frozen=True)
class DownloadResult:
    source: str
    normalized_url: str
    filename: str
    status: str
    size_bytes: int = 0
    sha256: str = ""
    error: str = ""


def _clean_extension(value: str | None) -> str:
    ext = (value or "").lower().lstrip(".")
    ext = re.sub(r"[^a-z0-9]", "", ext)
    if ext == "jpeg":
        return "jpg"
    return ext


def extension_from_content_type(content_type: str | None) -> str:
    base = (content_type or "").split(";", 1)[0].strip().lower()
    mapping = {
        "image/jpeg": "jpg",
        "image/png": "png",
        "image/webp": "webp",
        "image/gif": "gif",
        "image/avif": "avif",
        "video/mp4": "mp4",
        "video/webm": "webm",
        "video/quicktime": "mov",
    }
    if base in mapping:
        return mapping[base]
    guessed = mimetypes.guess_extension(base) or ""
    return _clean_extension(guessed)


def canonicalize_url(raw_url: str) -> str:
    raw_url = raw_url.strip()
    parsed = urllib.parse.urlsplit(raw_url)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise MediaCollectorError(f"unsupported URL scheme: {parsed.scheme or '(none)'}")
    if not parsed.hostname:
        raise MediaCollectorError("URL has no hostname")

    netloc = parsed.hostname.lower()
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"

    return urllib.parse.urlunsplit(
        (
            parsed.scheme.lower(),
            netloc,
            parsed.path or "/",
            parsed.query,
            "",
        )
    )


def normalize_x_media_url(raw_url: str) -> tuple[str, str, str]:
    parsed = urllib.parse.urlsplit(canonicalize_url(raw_url))
    if parsed.hostname != "pbs.twimg.com" or not parsed.path.startswith("/media/"):
        raise MediaCollectorError("not an X media image URL")

    query = urllib.parse.parse_qs(parsed.query)
    fmt = _clean_extension((query.get("format") or [""])[0])

    path = parsed.path
    suffix_match = re.search(r"\.([A-Za-z0-9]+)(?::[^/]*)?$", path)
    if not fmt and suffix_match:
        fmt = _clean_extension(suffix_match.group(1))

    path = re.sub(r":(?:orig|large|medium|small)$", "", path, flags=re.IGNORECASE)
    if fmt:
        path = re.sub(rf"\.{re.escape(fmt)}$", "", path, flags=re.IGNORECASE)

    media_id = path.rstrip("/").split("/")[-1] or "unknown"
    fmt = fmt or "jpg"
    normalized_query = urllib.parse.urlencode({"format": fmt, "name": "orig"})
    normalized = urllib.parse.urlunsplit(
        ("https", "pbs.twimg.com", path, normalized_query, "")
    )
    return normalized, media_id, fmt


def infer_generic_identity(url: str) -> tuple[str, str]:
    parsed = urllib.parse.urlsplit(url)
    name = Path(parsed.path).name or "media"
    stem = Path(name).stem or "media"
    ext = _clean_extension(Path(name).suffix)
    query = urllib.parse.parse_qs(parsed.query)
    if not ext:
        ext = _clean_extension((query.get("format") or [""])[0])
    return stem, ext


def media_kind(extension: str) -> str:
    ext = _clean_extension(extension)
    if ext in KNOWN_IMAGE_EXTENSIONS:
        return "image"
    if ext in KNOWN_VIDEO_EXTENSIONS:
        return "video"
    return "unknown"


def make_media_item(raw_url: str, source_hint: str | None = None) -> MediaItem:
    canonical = canonicalize_url(raw_url)
    host = urllib.parse.urlsplit(canonical).hostname or ""

    if source_hint == "x" or host == "pbs.twimg.com":
        normalized, media_id, ext = normalize_x_media_url(canonical)
        source = "x"
    else:
        normalized = canonical
        media_id, ext = infer_generic_identity(normalized)
        source = source_hint or "generic"

    return MediaItem(
        source=source,
        source_url=raw_url.strip(),
        normalized_url=normalized,
        media_id=media_id,
        extension=ext,
        kind=media_kind(ext),
    )


def extract_urls(text: str) -> list[str]:
    urls: list[str] = []
    for match in URL_RE.finditer(text):
        url = match.group(0).rstrip(")]}>.;'\"")
        if url:
            urls.append(url)
    return urls


def build_plan(
    urls: Iterable[str],
    *,
    source_hint: str | None = None,
) -> list[MediaItem]:
    items: list[MediaItem] = []
    seen: set[str] = set()
    for raw in urls:
        if not raw or not raw.strip():
            continue
        item = make_media_item(raw, source_hint=source_hint)
        if item.normalized_url in seen:
            continue
        seen.add(item.normalized_url)
        items.append(item)
    return items


def build_plan_from_text(
    text: str,
    *,
    source_hint: str | None = None,
) -> list[MediaItem]:
    return build_plan(extract_urls(text), source_hint=source_hint)


def _is_sensitive_query_key(key: str) -> bool:
    normalized = key.strip().lower()
    if normalized in SENSITIVE_QUERY_KEYS:
        return True
    return normalized.endswith(
        ("token", "signature", "credential", "api_key", "apikey")
    )


def redact_url_for_manifest(raw_url: str) -> str:
    parsed = urllib.parse.urlsplit(raw_url.strip())
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        return raw_url.strip()

    netloc = parsed.hostname.lower()
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"

    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    redacted_query = [
        (key, "REDACTED" if _is_sensitive_query_key(key) else value)
        for key, value in query
    ]
    return urllib.parse.urlunsplit(
        (
            parsed.scheme.lower(),
            netloc,
            parsed.path or "/",
            urllib.parse.urlencode(redacted_query, doseq=True),
            "",
        )
    )


def _media_item_manifest_dict(item: MediaItem) -> dict[str, object]:
    payload = asdict(item)
    payload["source_url"] = redact_url_for_manifest(item.source_url)
    payload["normalized_url"] = redact_url_for_manifest(item.normalized_url)
    return payload


def _download_result_manifest_dict(row: DownloadResult) -> dict[str, object]:
    payload = asdict(row)
    payload["normalized_url"] = redact_url_for_manifest(row.normalized_url)
    return payload


def safe_component(value: str, fallback: str = "media") -> str:
    cleaned = SAFE_CHARS_RE.sub("_", value.strip()).strip("._-")
    return cleaned[:96] or fallback


def suggested_filename(item: MediaItem, index: int, extension: str | None = None) -> str:
    ext = _clean_extension(extension or item.extension) or "bin"
    serial = f"{index:06d}"
    return f"{safe_component(item.source)}_{serial}_{safe_component(item.media_id)}.{ext}"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def write_plan_manifest(
    items: Iterable[MediaItem],
    output_dir: Path,
    *,
    stem: str = "media_manifest",
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = list(items)

    json_path = output_dir / f"{stem}.json"
    tsv_path = output_dir / f"{stem}.tsv"

    json_path.write_text(
        json.dumps(
            [_media_item_manifest_dict(item) for item in rows],
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    with tsv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(
            ["index", "source", "kind", "media_id", "extension", "normalized_url"]
        )
        for index, item in enumerate(rows, 1):
            writer.writerow(
                [
                    index,
                    item.source,
                    item.kind,
                    item.media_id,
                    item.extension,
                    redact_url_for_manifest(item.normalized_url),
                ]
            )

    return json_path, tsv_path


def _content_type(response) -> str:
    headers = getattr(response, "headers", None)
    if headers is None:
        return ""
    getter = getattr(headers, "get_content_type", None)
    if callable(getter):
        return getter()
    get = getattr(headers, "get", None)
    if callable(get):
        return (get("Content-Type") or "").split(";", 1)[0].strip()
    return ""


def media_signature_matches(data: bytes, content_type: str) -> bool:
    base = (content_type or "").split(";", 1)[0].strip().lower()
    if not data:
        return False
    if base == "image/jpeg":
        return data.startswith(b"\xff\xd8\xff")
    if base == "image/png":
        return data.startswith(b"\x89PNG\r\n\x1a\n")
    if base == "image/gif":
        return data.startswith((b"GIF87a", b"GIF89a"))
    if base == "image/webp":
        return len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP"
    if base == "image/avif":
        return len(data) >= 16 and data[4:8] == b"ftyp" and (
            b"avif" in data[:32] or b"avis" in data[:32]
        )
    if base in {"video/mp4", "video/quicktime"}:
        return len(data) >= 12 and data[4:8] == b"ftyp"
    if base == "video/webm":
        return data.startswith(b"\x1a\x45\xdf\xa3")
    return False


def _content_length(response) -> int | None:
    headers = getattr(response, "headers", None)
    if headers is None:
        return None
    get = getattr(headers, "get", None)
    if not callable(get):
        return None
    raw = get("Content-Length")
    if not raw:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def download_plan(
    items: Iterable[MediaItem],
    output_dir: Path,
    *,
    allow_videos: bool = False,
    max_bytes: int = DEFAULT_MAX_BYTES,
    overwrite: bool = False,
    timeout: float = 30.0,
    opener=urllib.request.urlopen,
) -> list[DownloadResult]:
    if max_bytes <= 0:
        raise ValueError("max_bytes must be positive")

    output_dir.mkdir(parents=True, exist_ok=True)
    results: list[DownloadResult] = []
    content_hashes: set[str] = set()

    for index, item in enumerate(items, 1):
        if item.kind == "video" and not allow_videos:
            results.append(
                DownloadResult(
                    source=item.source,
                    normalized_url=item.normalized_url,
                    filename="",
                    status="skipped",
                    error="video download is disabled",
                )
            )
            continue

        headers = {
            "User-Agent": "MediaCollector/0.1 (+local desktop tool)",
            "Accept": "image/*,video/*;q=0.8,*/*;q=0.2",
        }
        if item.source == "pixiv":
            headers["Referer"] = "https://www.pixiv.net/"

        request = urllib.request.Request(
            item.normalized_url,
            headers=headers,
        )

        temp_path: Path | None = None
        try:
            with opener(request, timeout=timeout) as response:
                content_type = _content_type(response)
                kind = (
                    "image"
                    if content_type.startswith("image/")
                    else "video"
                    if content_type.startswith("video/")
                    else ""
                )
                if not kind:
                    raise MediaCollectorError(
                        f"unsupported content type: {content_type or '(missing)'}"
                    )
                if kind == "video" and not allow_videos:
                    raise MediaCollectorError("video download is disabled")

                declared = _content_length(response)
                if declared is not None and declared > max_bytes:
                    raise MediaCollectorError(
                        f"declared size exceeds limit: {declared} > {max_bytes}"
                    )

                ext = extension_from_content_type(content_type) or item.extension or "bin"
                filename = suggested_filename(item, index, ext)
                final_path = output_dir / filename
                if final_path.exists() and not overwrite:
                    existing_hash = sha256_file(final_path)
                    content_hashes.add(existing_hash)
                    results.append(
                        DownloadResult(
                            source=item.source,
                            normalized_url=item.normalized_url,
                            filename=filename,
                            status="exists",
                            size_bytes=final_path.stat().st_size,
                            sha256=existing_hash,
                        )
                    )
                    continue

                digest = hashlib.sha256()
                size = 0
                fd, tmp_name = tempfile.mkstemp(
                    prefix=".media-collector-",
                    suffix=".tmp",
                    dir=str(output_dir),
                )
                os.close(fd)
                temp_path = Path(tmp_name)

                first_chunk = True
                with temp_path.open("wb") as handle:
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        if first_chunk:
                            first_chunk = False
                            if not media_signature_matches(chunk, content_type):
                                raise MediaCollectorError(
                                    f"content signature does not match {content_type}"
                                )
                        size += len(chunk)
                        if size > max_bytes:
                            raise MediaCollectorError(
                                f"download exceeds limit: {size} > {max_bytes}"
                            )
                        digest.update(chunk)
                        handle.write(chunk)

                if size == 0:
                    raise MediaCollectorError("empty media response")

                sha256 = digest.hexdigest()
                if sha256 in content_hashes:
                    temp_path.unlink(missing_ok=True)
                    temp_path = None
                    results.append(
                        DownloadResult(
                            source=item.source,
                            normalized_url=item.normalized_url,
                            filename=filename,
                            status="duplicate-content",
                            size_bytes=size,
                            sha256=sha256,
                        )
                    )
                    continue

                content_hashes.add(sha256)
                os.replace(temp_path, final_path)
                temp_path = None
                results.append(
                    DownloadResult(
                        source=item.source,
                        normalized_url=item.normalized_url,
                        filename=filename,
                        status="saved",
                        size_bytes=size,
                        sha256=sha256,
                    )
                )
        except Exception as exc:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)
            results.append(
                DownloadResult(
                    source=item.source,
                    normalized_url=item.normalized_url,
                    filename="",
                    status="error",
                    error=str(exc),
                )
            )

    return results


def write_download_manifest(
    results: Iterable[DownloadResult],
    output_dir: Path,
    *,
    stem: str = "download_manifest",
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = list(results)

    json_path = output_dir / f"{stem}.json"
    tsv_path = output_dir / f"{stem}.tsv"
    json_path.write_text(
        json.dumps(
            [_download_result_manifest_dict(row) for row in rows],
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    with tsv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(
            [
                "source",
                "status",
                "filename",
                "size_bytes",
                "sha256",
                "normalized_url",
                "error",
            ]
        )
        for row in rows:
            writer.writerow(
                [
                    row.source,
                    row.status,
                    row.filename,
                    row.size_bytes,
                    row.sha256,
                    redact_url_for_manifest(row.normalized_url),
                    row.error,
                ]
            )

    return json_path, tsv_path
