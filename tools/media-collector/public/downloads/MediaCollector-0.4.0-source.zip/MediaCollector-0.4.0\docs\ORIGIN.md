# Origin and rebuild notes

Date: 2026-09-24

Media Collector is a clean rebuild inspired by several personal legacy utilities.

## Legacy families reviewed

- `GET_X_IMG`
  - X/Twitter media collection through gallery-dl and browser DOM
  - useful ideas retained: media URL normalization, account/list workflows, image/video filtering, logging
- `get_pixiv`
  - Pixiv user/search downloader
  - useful idea retained: source-specific adapter that emits media URLs
- `get_by_Kemono`
  - browser DOM scripts for finding post links and image links
  - useful ideas retained: DOM discovery, URL deduplication, bounded concurrency

## Secret quarantine

The reviewed archive contained hard-coded authentication tokens and other credentials.

Those originals are intentionally NOT copied into this repository.

Media Collector Phase 1 contains:

- no auth token
- no refresh token
- no cookie
- no password
- no private key
- no source download history

Future authenticated adapters must read credentials only from explicit runtime configuration outside the repository and must never persist them into manifests.

## Product direction

All source adapters convert discovered media into a common MediaItem model. The core owns normalization, deduplication, safe filenames, size limits, hashing, download verification and manifests.
