# Phase 3 QA

Date: 2026-09-25

## Goal

Exercise the real yt-dlp + ffmpeg download path and polish the GUI based on actual output behavior.

## Real local download QA

A generated MP4 fixture is served from a localhost HTTP server with byte-range support.

The test uses the real installed tools and verifies:

- Analyze with yt-dlp
- Video mode
- Audio extraction to m4a
- explicit Format ID mode
- range clipping
- precise range / forced keyframes
- output existence
- ffprobe duration
- ffprobe stream types

No external website, cookie, account, authentication token, or browser profile is used.

## Observed fixture issue

The first range test used a simple HTTP server without byte-range support. ffmpeg correctly failed while seeking the source.

The fixture was replaced with a Range-aware server. With byte ranges available, Download Workbench produced a 3.000-second clip successfully.

This was a test-fixture limitation, not a Download Workbench range-command defect.

## UX polish

- Command Preview now uses platform-appropriate command quoting.
- duplicate subtitle language entries are removed while preserving order.
- Info JSON is opt-in by default instead of automatically enabled.
- GUI Download requires both yt-dlp and ffmpeg.
- CLI download also requires ffmpeg; Analyze still only requires yt-dlp.

## Automated QA

- Python compile: PASS
- Phase 1–3 tests: 28 / 28 PASS
- tests also pass with ResourceWarning promoted to error
- real yt-dlp Analyze: PASS
- real Video download: PASS
- real Audio extraction: PASS
- real explicit Format ID download: PASS
- real 3-second precise range clip: PASS
- ffprobe stream/duration verification: PASS

## Visual QA

- real application screenshot: `qa/screenshots/phase3-main.png`
- direct target-window PrintWindow capture
- screenshot size: 1256 x 879
- no taskbar or overlapping application window
- populated format table and subtitle count
- range start/end and Precise range visible
- rights/permission gate visible
- Info JSON visibly opt-in

## Security boundary

- yt-dlp remains forced to --ignore-config.
- no cookie or browser-profile loading.
- no Authorization argument.
- no DRM or access-control bypass.
- embedded URL credentials are rejected.
- sensitive query values are redacted in Command Preview.
