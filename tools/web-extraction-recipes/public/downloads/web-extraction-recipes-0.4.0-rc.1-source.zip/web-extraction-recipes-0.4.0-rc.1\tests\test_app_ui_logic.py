from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from app import (
    ExtractionApp,
    crawl_recipe_from_text,
    format_bytes,
    parse_start_urls,
    recipe_from_text,
)
from crawl_core import CrawlResult, CrawlStats
from extraction_core import ExtractionError, extract_records


RECIPE_TEXT = json.dumps(
    {
        "name": "GUI demo",
        "base_url": "https://example.test/",
        "row_selector": "article.card",
        "fields": [
            {
                "name": "title",
                "selector": "a.title",
                "source": "text",
            },
            {
                "name": "url",
                "selector": "a.title",
                "source": "attr",
                "attr": "href",
                "urljoin": True,
            },
        ],
    }
)

HTML = """
<article class="card"><a class="title" href="/a">Alpha</a></article>
<article class="card"><a class="title" href="/b">Beta</a></article>
"""

CRAWL_RECIPE_TEXT = json.dumps(
    {
        "name": "GUI crawl",
        "link_selector": "article.card a.detail[href]",
        "link_attr": "href",
        "http": {
            "delay_seconds": 0,
            "timeout_seconds": 5,
            "max_retries": 1,
            "max_pages": 10,
            "same_origin": True,
            "respect_robots": True,
        },
        "detail_recipe": {
            "name": "Detail",
            "row_selector": "main.detail",
            "fields": [
                {"name": "title", "selector": "h1", "source": "text"},
            ],
        },
    }
)


class AppLogicTests(unittest.TestCase):
    def test_recipe_from_text(self) -> None:
        recipe = recipe_from_text(RECIPE_TEXT)
        self.assertEqual(recipe.name, "GUI demo")
        self.assertEqual(len(recipe.fields), 2)

    def test_bad_json_rejected(self) -> None:
        with self.assertRaises(ExtractionError):
            recipe_from_text("{bad json")

    def test_format_bytes(self) -> None:
        self.assertEqual(format_bytes(0), "0 B")
        self.assertEqual(format_bytes(1024), "1.0 KiB")

    def test_parse_start_urls(self) -> None:
        urls = parse_start_urls(
            "# comment\nhttps://example.test/a\n\n"
            "https://example.test/a\nhttps://example.test/b\n"
        )
        self.assertEqual(
            urls,
            ["https://example.test/a", "https://example.test/b"],
        )

    def test_crawl_recipe_from_text(self) -> None:
        recipe = crawl_recipe_from_text(CRAWL_RECIPE_TEXT)
        self.assertEqual(recipe.name, "GUI crawl")
        self.assertTrue(recipe.policy.same_origin)
        self.assertTrue(recipe.policy.respect_robots)

    def test_gui_constructs(self) -> None:
        app = ExtractionApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        self.assertEqual(app.title(), "Web Extraction Recipes")
        self.assertEqual(app.current_records, [])

    def test_crawl_permission_gate(self) -> None:
        app = ExtractionApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        self.assertEqual(str(app.crawl_button.cget("state")), "disabled")
        app.crawl_permission_var.set(True)
        app._refresh_crawl_state()
        self.assertEqual(str(app.crawl_button.cget("state")), "normal")

    def test_crawl_finished_updates_preview(self) -> None:
        app = ExtractionApp()
        app.withdraw()
        self.addCleanup(app.destroy)
        recipe = crawl_recipe_from_text(CRAWL_RECIPE_TEXT)
        stats = CrawlStats(
            fetched_pages=3,
            cache_hits=1,
            unique_detail_links=2,
        )
        result = CrawlResult(
            records=(
                {
                    "title": "First",
                    "source_url": "https://example.test/list",
                    "detail_url": "https://example.test/1",
                },
                {
                    "title": "Second",
                    "source_url": "https://example.test/list",
                    "detail_url": "https://example.test/2",
                },
            ),
            stats=stats,
        )
        app._crawl_finished(
            ["https://example.test/list"],
            recipe,
            result,
        )
        self.assertEqual(app.current_mode, "crawl")
        self.assertEqual(app.summary_vars["rows"].get(), "2")
        self.assertEqual(app.summary_vars["fields"].get(), "3")
        self.assertEqual(
            app.summary_vars["input"].get(),
            "1 URLs / 3 fetched",
        )
        self.assertEqual(len(app.preview_tree.get_children()), 2)
        self.assertEqual(str(app.export_button.cget("state")), "normal")

    def test_extract_finished_updates_preview(self) -> None:
        recipe = recipe_from_text(RECIPE_TEXT)
        records = extract_records(HTML, recipe)
        with tempfile.TemporaryDirectory() as temp:
            html_path = Path(temp) / "sample.html"
            html_path.write_text(HTML, encoding="utf-8")
            app = ExtractionApp()
            app.withdraw()
            self.addCleanup(app.destroy)
            app._extract_finished(
                html_path,
                recipe,
                records,
                html_path.stat().st_size,
            )
            self.assertEqual(app.summary_vars["rows"].get(), "2")
            self.assertEqual(app.summary_vars["fields"].get(), "2")
            self.assertEqual(len(app.preview_tree.get_children()), 2)
            self.assertEqual(
                tuple(app.preview_tree.cget("columns")),
                ("title", "url"),
            )
            self.assertEqual(str(app.export_button.cget("state")), "normal")

    def test_changed_input_invalidates_results(self) -> None:
        recipe = recipe_from_text(RECIPE_TEXT)
        records = extract_records(HTML, recipe)
        with tempfile.TemporaryDirectory() as temp:
            html_path = Path(temp) / "sample.html"
            html_path.write_text(HTML, encoding="utf-8")
            app = ExtractionApp()
            app.withdraw()
            self.addCleanup(app.destroy)
            app._extract_finished(
                html_path,
                recipe,
                records,
                html_path.stat().st_size,
            )
            app.html_var.set(str(Path(temp) / "other.html"))
            self.assertEqual(app.current_records, [])
            self.assertEqual(str(app.export_button.cget("state")), "disabled")


if __name__ == "__main__":
    unittest.main()