from __future__ import annotations

import json
import math
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from .synth import (
    ADSR,
    TimedNote,
    _adsr_envelope,
    _drum_voice,
    _panned_stereo,
    _write_wav,
    file_sha256,
    midi_note_to_hz,
    parse_midi_notes,
)


@dataclass(frozen=True)
class OscillatorLayer:
    waveform: str
    amplitude: float
    octave: int = 0
    detune_cents: float = 0.0


@dataclass(frozen=True)
class EnhancedVoicePreset:
    gain: float
    pan: float
    adsr: ADSR
    layers: tuple[OscillatorLayer, ...]
    lowpass_hz: float | None = None
    lowpass_stages: int = 1


@dataclass(frozen=True)
class EnhancedRenderStats:
    sample_rate: int
    channels: int
    frames: int
    duration_seconds: float
    source_peak: float
    output_peak: float
    rms: float
    normalization_gain: float
    note_count: int
    crest_factor_db: float

    def to_dict(self) -> dict[str, int | float]:
        return {
            "sample_rate": self.sample_rate,
            "channels": self.channels,
            "frames": self.frames,
            "duration_seconds": round(self.duration_seconds, 6),
            "source_peak": round(self.source_peak, 8),
            "output_peak": round(self.output_peak, 8),
            "rms": round(self.rms, 8),
            "normalization_gain": round(self.normalization_gain, 8),
            "note_count": self.note_count,
            "crest_factor_db": round(self.crest_factor_db, 6),
        }


@dataclass(frozen=True)
class OggExportResult:
    available: bool
    created: bool
    encoder: str | None
    quality: float | None
    sha256: str | None
    size_bytes: int | None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "created": self.created,
            "encoder": self.encoder,
            "quality": self.quality,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "error": self.error,
        }


def _oscillator(waveform: str, phase_cycles: np.ndarray) -> np.ndarray:
    """Generate a normalized naive oscillator in [-1, 1].

    Phase 03B intentionally keeps oscillator math transparent and dependency-light.
    Anti-aliased/band-limited oscillators are deferred to a later sound-quality phase.
    """
    wrapped = np.mod(phase_cycles, 1.0)
    phase = 2.0 * np.pi * wrapped
    waveform = waveform.lower()

    if waveform == "sine":
        return np.sin(phase)
    if waveform == "square":
        return np.where(wrapped < 0.5, 1.0, -1.0)
    if waveform == "triangle":
        return 1.0 - 4.0 * np.abs(wrapped - 0.5)
    if waveform == "saw":
        return 2.0 * wrapped - 1.0
    raise ValueError(f"Unsupported waveform: {waveform}")


def _enhanced_tonal_voice(
    note: TimedNote,
    preset: EnhancedVoicePreset,
    sample_rate: int,
) -> np.ndarray:
    envelope = _adsr_envelope(note.duration_seconds, preset.adsr, sample_rate)
    t = np.arange(len(envelope), dtype=np.float64) / sample_rate
    base_hz = midi_note_to_hz(note.note)
    mono = np.zeros_like(t)

    amplitude_sum = sum(abs(layer.amplitude) for layer in preset.layers) or 1.0
    for layer in preset.layers:
        frequency = base_hz * (2.0 ** layer.octave) * (2.0 ** (layer.detune_cents / 1200.0))
        mono += layer.amplitude * _oscillator(layer.waveform, frequency * t)

    mono /= amplitude_sum
    mono *= envelope * (note.velocity / 127.0) * preset.gain
    return _panned_stereo(mono, preset.pan)


def _moving_average_lowpass(stereo: np.ndarray, sample_rate: int, cutoff_hz: float) -> np.ndarray:
    """Fast deterministic FIR-ish smoothing filter implemented with cumulative sums.

    This is deliberately simple. It is sufficient for Phase 03B timbral separation while
    keeping NumPy as the only DSP dependency.
    """
    if cutoff_hz <= 0.0 or cutoff_hz >= sample_rate / 2.0:
        return stereo.copy()

    window = max(1, int(round(sample_rate / (2.0 * cutoff_hz))))
    window = min(window, 512)
    if window <= 1:
        return stereo.copy()

    result = np.empty_like(stereo)
    for channel in range(stereo.shape[1]):
        x = stereo[:, channel]
        csum = np.cumsum(x, dtype=np.float64)
        prefix_count = min(window - 1, len(x))
        if prefix_count:
            result[:prefix_count, channel] = csum[:prefix_count] / np.arange(
                1, prefix_count + 1, dtype=np.float64
            )
        if len(x) >= window:
            previous = np.concatenate(([0.0], csum[:-window]))
            result[window - 1 :, channel] = (csum[window - 1 :] - previous) / window
    return result


def _apply_lowpass_stages(
    stereo: np.ndarray,
    sample_rate: int,
    cutoff_hz: float | None,
    stages: int,
) -> np.ndarray:
    if cutoff_hz is None:
        return stereo
    out = stereo
    for _ in range(max(1, int(stages))):
        out = _moving_average_lowpass(out, sample_rate, cutoff_hz)
    return out


def _tap_effect(
    stereo: np.ndarray,
    sample_rate: int,
    taps: list[dict[str, float | bool]],
) -> np.ndarray:
    """Return wet-only finite tap echoes/reverb."""
    wet = np.zeros_like(stereo)
    for tap in taps:
        delay_ms = float(tap.get("delay_ms", 0.0))
        gain = float(tap.get("gain", 0.0))
        crossfeed = bool(tap.get("crossfeed", False))
        delay = int(round(delay_ms * sample_rate / 1000.0))
        if delay <= 0 or delay >= len(stereo) or gain == 0.0:
            continue
        source = stereo[:-delay]
        if crossfeed:
            source = source[:, ::-1]
        wet[delay:] += source * gain
    return wet


def _soft_saturate(stereo: np.ndarray, drive: float) -> np.ndarray:
    if drive <= 0.0:
        return stereo
    scale = math.tanh(drive)
    if scale == 0.0:
        return stereo
    return np.tanh(stereo * drive) / scale


def _parse_adsr(raw: dict[str, Any]) -> ADSR:
    return ADSR(
        float(raw.get("attack", 0.01)),
        float(raw.get("decay", 0.1)),
        float(raw.get("sustain", 0.7)),
        float(raw.get("release", 0.2)),
    )


def _parse_voice(raw: dict[str, Any]) -> EnhancedVoicePreset:
    layers = tuple(
        OscillatorLayer(
            waveform=str(item.get("waveform", "sine")),
            amplitude=float(item.get("amplitude", 1.0)),
            octave=int(item.get("octave", 0)),
            detune_cents=float(item.get("detune_cents", 0.0)),
        )
        for item in raw.get("layers", [{"waveform": "sine", "amplitude": 1.0}])
    )
    if not layers:
        raise ValueError("Each tonal voice requires at least one oscillator layer.")

    cutoff = raw.get("lowpass_hz")
    return EnhancedVoicePreset(
        gain=float(raw.get("gain", 0.2)),
        pan=float(raw.get("pan", 0.0)),
        adsr=_parse_adsr(dict(raw.get("adsr", {}))),
        layers=layers,
        lowpass_hz=None if cutoff is None else float(cutoff),
        lowpass_stages=int(raw.get("lowpass_stages", 1)),
    )


def load_phase03b_config(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    sample_rate = int(data.get("sample_rate", 44100))
    target_peak = float(data.get("target_peak", 0.92))
    tail_seconds = float(data.get("tail_seconds", 2.0))
    if sample_rate < 8000:
        raise ValueError("sample_rate must be at least 8000 Hz.")
    if not 0.0 < target_peak <= 1.0:
        raise ValueError("target_peak must be in the range (0, 1].")
    if tail_seconds < 0.0:
        raise ValueError("tail_seconds must be non-negative.")

    voices = {name: _parse_voice(dict(raw)) for name, raw in dict(data.get("voices", {})).items()}
    for required in ("Melody", "Chords", "Bass"):
        if required not in voices:
            raise ValueError(f"Missing voice preset: {required}")

    return {
        "sample_rate": sample_rate,
        "target_peak": target_peak,
        "tail_seconds": tail_seconds,
        "voices": voices,
        "track_gain": {k: float(v) for k, v in dict(data.get("track_gain", {})).items()},
        "delay": dict(data.get("delay", {})),
        "reverb": dict(data.get("reverb", {})),
        "saturation_drive": float(data.get("saturation_drive", 0.0)),
        "ogg_quality": float(data.get("ogg_quality", 4.0)),
    }


def render_midi_to_enhanced_wav(
    midi_path: Path,
    wav_path: Path,
    *,
    sample_rate: int,
    target_peak: float,
    tail_seconds: float,
    voices: dict[str, EnhancedVoicePreset],
    track_gain: dict[str, float],
    delay: dict[str, Any],
    reverb: dict[str, Any],
    saturation_drive: float,
) -> tuple[EnhancedRenderStats, dict[str, dict[str, float | int]]]:
    notes, _, _ = parse_midi_notes(midi_path)
    if not notes:
        raise ValueError("MIDI contains no note events to render.")

    longest_release = max((voice.adsr.release for voice in voices.values()), default=0.0)
    final_note_end = max(note.start_seconds + note.duration_seconds for note in notes)
    max_effect_delay_ms = 0.0
    for effect in (delay, reverb):
        for tap in effect.get("taps", []):
            max_effect_delay_ms = max(max_effect_delay_ms, float(tap.get("delay_ms", 0.0)))
    duration = final_note_end + max(tail_seconds, longest_release, max_effect_delay_ms / 1000.0 + 0.25)
    frame_count = max(1, int(math.ceil(duration * sample_rate)))

    track_names = sorted({note.track for note in notes})
    tracks = {name: np.zeros((frame_count, 2), dtype=np.float64) for name in track_names}

    for note in notes:
        if note.channel == 9 or note.track == "Drums":
            voice = _drum_voice(note, sample_rate)
        else:
            preset = voices.get(note.track, voices["Melody"])
            voice = _enhanced_tonal_voice(note, preset, sample_rate)

        start = int(round(note.start_seconds * sample_rate))
        end = min(frame_count, start + len(voice))
        if end > start:
            tracks[note.track][start:end] += voice[: end - start]

    for track_name, signal in list(tracks.items()):
        if track_name in voices:
            preset = voices[track_name]
            signal = _apply_lowpass_stages(
                signal,
                sample_rate,
                preset.lowpass_hz,
                preset.lowpass_stages,
            )
        signal *= track_gain.get(track_name, 1.0)

        if bool(delay.get("enabled", False)) and track_name in delay.get("tracks", []):
            signal = signal + _tap_effect(signal, sample_rate, list(delay.get("taps", [])))
        if bool(reverb.get("enabled", False)) and track_name in reverb.get("tracks", []):
            signal = signal + _tap_effect(signal, sample_rate, list(reverb.get("taps", [])))
        tracks[track_name] = signal

    mix = np.zeros((frame_count, 2), dtype=np.float64)
    for signal in tracks.values():
        mix += signal

    mix = _soft_saturate(mix, saturation_drive)
    source_peak = float(np.max(np.abs(mix))) if mix.size else 0.0
    normalization_gain = 1.0 if source_peak <= 0.0 else target_peak / source_peak
    mix *= normalization_gain

    output_peak = float(np.max(np.abs(mix))) if mix.size else 0.0
    rms = float(np.sqrt(np.mean(np.square(mix)))) if mix.size else 0.0
    crest_factor_db = 0.0 if rms <= 0.0 else 20.0 * math.log10(max(output_peak, 1e-12) / rms)
    _write_wav(wav_path, mix, sample_rate)

    track_stats: dict[str, dict[str, float | int]] = {}
    for name, signal in tracks.items():
        peak = float(np.max(np.abs(signal))) if signal.size else 0.0
        track_rms = float(np.sqrt(np.mean(np.square(signal)))) if signal.size else 0.0
        track_stats[name] = {
            "notes": sum(1 for note in notes if note.track == name),
            "peak_pre_master": round(peak, 8),
            "rms_pre_master": round(track_rms, 8),
            "gain": round(track_gain.get(name, 1.0), 6),
        }

    stats = EnhancedRenderStats(
        sample_rate=sample_rate,
        channels=2,
        frames=frame_count,
        duration_seconds=frame_count / sample_rate,
        source_peak=source_peak,
        output_peak=output_peak,
        rms=rms,
        normalization_gain=normalization_gain,
        note_count=len(notes),
        crest_factor_db=crest_factor_db,
    )
    return stats, track_stats


def export_ogg_vorbis(wav_path: Path, ogg_path: Path, quality: float = 4.0) -> OggExportResult:
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg is None:
        return OggExportResult(
            available=False,
            created=False,
            encoder=None,
            quality=None,
            sha256=None,
            size_bytes=None,
            error="ffmpeg was not found on PATH; WAV export is still valid.",
        )

    ogg_path.parent.mkdir(parents=True, exist_ok=True)
    command = [
        ffmpeg,
        "-y",
        "-hide_banner",
        "-loglevel",
        "error",
        "-fflags",
        "+bitexact",
        "-flags:a",
        "+bitexact",
        "-i",
        str(wav_path),
        "-map_metadata",
        "-1",
        "-c:a",
        "libvorbis",
        "-q:a",
        str(quality),
        "-serial_offset",
        "0",
        str(ogg_path),
    ]
    try:
        subprocess.run(command, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        return OggExportResult(
            available=True,
            created=False,
            encoder="ffmpeg/libvorbis",
            quality=quality,
            sha256=None,
            size_bytes=None,
            error=(exc.stderr or str(exc)).strip(),
        )

    return OggExportResult(
        available=True,
        created=True,
        encoder="ffmpeg/libvorbis",
        quality=quality,
        sha256=file_sha256(ogg_path),
        size_bytes=ogg_path.stat().st_size,
    )
