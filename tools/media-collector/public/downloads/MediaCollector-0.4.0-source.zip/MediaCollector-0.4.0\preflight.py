from __future__ import annotations

import sys
import tkinter
from pathlib import Path


MIN_PYTHON = (3, 10)
REQUIRED_FILES = (
    "app.py",
    "collector.py",
    "media_collector_core.py",
    "source_adapters.py",
    "browser_bridges/x_media_bridge.js",
    "browser_bridges/pixiv_media_bridge.js",
    "browser_bridges/generic_dom_bridge.js",
)


def main() -> int:
    failures: list[str] = []
    root_dir = Path(__file__).resolve().parent

    print("Media Collector preflight")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Tkinter: {tkinter.TkVersion}")

    if sys.version_info < MIN_PYTHON:
        failures.append(
            f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer is required"
        )

    for relative in REQUIRED_FILES:
        if not (root_dir / relative).is_file():
            failures.append(f"required file missing: {relative}")

    try:
        root = tkinter.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
        print("Tk GUI: available")
    except tkinter.TclError as exc:
        failures.append(f"Tk GUI unavailable: {exc}")

    if failures:
        print("\nPreflight FAILED")
        for item in failures:
            print(f"- {item}")
        return 1

    print("\nPreflight PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
