from __future__ import annotations

import hashlib
import json
import math
import wave
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from mido import MidiFile, bpm2tempo, tick2second


@dataclass(frozen=True)
class ADSR:
    attack: float
    decay: float
    sustain: float
    release: float


@dataclass(frozen=True)
class VoicePreset:
    gain: float
    pan: float
    adsr: ADSR
    harmonics: tuple[tuple[float, float], ...]


@dataclass(frozen=True)
class TimedNote:
    track: str
    note: int
    velocity: int
    channel: int
    start_seconds: float
    duration_seconds: float


@dataclass(frozen=True)
class RenderStats:
    sample_rate: int
    channels: int
    frames: int
    duration_seconds: float
    source_peak: float
    output_peak: float
    rms: float
    normalization_gain: float
    note_count: int

    def to_dict(self) -> dict[str, int | float]:
        return {
            "sample_rate": self.sample_rate,
            "channels": self.channels,
            "frames": self.frames,
            "duration_seconds": round(self.duration_seconds, 6),
            "source_peak": round(self.source_peak, 8),
            "output_peak": round(self.output_peak, 8),
            "rms": round(self.rms, 8),
            "normalization_gain": round(self.normalization_gain, 8),
            "note_count": self.note_count,
        }


DEFAULT_PRESETS: dict[str, VoicePreset] = {
    "Melody": VoicePreset(
        gain=0.28,
        pan=0.15,
        adsr=ADSR(0.012, 0.09, 0.72, 0.18),
        harmonics=((1.0, 1.0), (2.0, 0.18), (3.0, 0.08)),
    ),
    "Chords": VoicePreset(
        gain=0.16,
        pan=-0.18,
        adsr=ADSR(0.035, 0.18, 0.58, 0.28),
        harmonics=((1.0, 1.0), (2.0, 0.12), (4.0, 0.04)),
    ),
    "Bass": VoicePreset(
        gain=0.24,
        pan=0.0,
        adsr=ADSR(0.008, 0.10, 0.70, 0.14),
        harmonics=((1.0, 1.0), (2.0, 0.22)),
    ),
}


def midi_note_to_hz(note: int) -> float:
    return 440.0 * (2.0 ** ((note - 69) / 12.0))


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _adsr_envelope(note_seconds: float, adsr: ADSR, sample_rate: int) -> np.ndarray:
    note_samples = max(1, int(round(note_seconds * sample_rate)))
    release_samples = max(0, int(round(adsr.release * sample_rate)))
    envelope = np.zeros(note_samples + release_samples, dtype=np.float64)

    attack_samples = min(note_samples, max(0, int(round(adsr.attack * sample_rate))))
    remaining = note_samples - attack_samples
    decay_samples = min(remaining, max(0, int(round(adsr.decay * sample_rate))))
    sustain_samples = note_samples - attack_samples - decay_samples

    cursor = 0
    if attack_samples:
        envelope[cursor : cursor + attack_samples] = np.linspace(
            0.0, 1.0, attack_samples, endpoint=False, dtype=np.float64
        )
        cursor += attack_samples
    if decay_samples:
        envelope[cursor : cursor + decay_samples] = np.linspace(
            1.0, adsr.sustain, decay_samples, endpoint=False, dtype=np.float64
        )
        cursor += decay_samples
    if sustain_samples:
        envelope[cursor : cursor + sustain_samples] = adsr.sustain
        cursor += sustain_samples
    if release_samples:
        start_level = envelope[note_samples - 1] if note_samples else adsr.sustain
        envelope[note_samples:] = np.linspace(
            start_level, 0.0, release_samples, endpoint=True, dtype=np.float64
        )
    return envelope


def _panned_stereo(mono: np.ndarray, pan: float) -> np.ndarray:
    pan = max(-1.0, min(1.0, pan))
    angle = (pan + 1.0) * math.pi / 4.0
    left = mono * math.cos(angle)
    right = mono * math.sin(angle)
    return np.column_stack((left, right))


def _tonal_voice(note: TimedNote, preset: VoicePreset, sample_rate: int) -> np.ndarray:
    envelope = _adsr_envelope(note.duration_seconds, preset.adsr, sample_rate)
    t = np.arange(len(envelope), dtype=np.float64) / sample_rate
    frequency = midi_note_to_hz(note.note)
    mono = np.zeros_like(t)
    harmonic_scale = sum(abs(amplitude) for _, amplitude in preset.harmonics) or 1.0
    for multiplier, amplitude in preset.harmonics:
        mono += amplitude * np.sin(2.0 * np.pi * frequency * multiplier * t)
    mono /= harmonic_scale
    mono *= envelope * (note.velocity / 127.0) * preset.gain
    return _panned_stereo(mono, preset.pan)


def _deterministic_noise(length: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed & 0xFFFFFFFF)
    return rng.uniform(-1.0, 1.0, length).astype(np.float64)


def _drum_voice(note: TimedNote, sample_rate: int) -> np.ndarray:
    # General MIDI percussion mapping used by the composer:
    # 36 kick, 38 snare, 42/46 hats, 49 crash.
    velocity = note.velocity / 127.0
    seed = (note.note * 1000003) ^ int(round(note.start_seconds * 1000000.0))

    if note.note == 36:
        duration = 0.34
        count = max(1, int(round(duration * sample_rate)))
        t = np.arange(count, dtype=np.float64) / sample_rate
        phase = 2.0 * np.pi * (105.0 * t - 42.0 * t * t)
        mono = np.sin(phase) * np.exp(-t * 13.0) * 0.72 * velocity
        pan = 0.0
    elif note.note == 38:
        duration = 0.24
        count = max(1, int(round(duration * sample_rate)))
        t = np.arange(count, dtype=np.float64) / sample_rate
        noise = _deterministic_noise(count, seed)
        body = np.sin(2.0 * np.pi * 185.0 * t)
        mono = (0.72 * noise + 0.28 * body) * np.exp(-t * 17.0) * 0.46 * velocity
        pan = 0.05
    elif note.note in (42, 46):
        duration = 0.09 if note.note == 42 else 0.20
        count = max(1, int(round(duration * sample_rate)))
        t = np.arange(count, dtype=np.float64) / sample_rate
        noise = _deterministic_noise(count, seed)
        mono = noise * np.exp(-t * (46.0 if note.note == 42 else 22.0)) * 0.22 * velocity
        pan = -0.25 if note.note == 42 else 0.25
    elif note.note == 49:
        duration = 0.72
        count = max(1, int(round(duration * sample_rate)))
        t = np.arange(count, dtype=np.float64) / sample_rate
        noise = _deterministic_noise(count, seed)
        shimmer = np.sin(2.0 * np.pi * 4600.0 * t) * 0.15
        mono = (noise + shimmer) * np.exp(-t * 5.2) * 0.26 * velocity
        pan = 0.30
    else:
        duration = 0.12
        count = max(1, int(round(duration * sample_rate)))
        t = np.arange(count, dtype=np.float64) / sample_rate
        mono = _deterministic_noise(count, seed) * np.exp(-t * 30.0) * 0.15 * velocity
        pan = 0.0

    return _panned_stereo(mono, pan)


def _constant_tempo(midi: MidiFile) -> int:
    tempos = [
        message.tempo
        for track in midi.tracks
        for message in track
        if message.type == "set_tempo"
    ]
    unique = sorted(set(tempos))
    if len(unique) > 1:
        raise ValueError("Phase 03A supports one constant MIDI tempo only.")
    return unique[0] if unique else bpm2tempo(120)


def parse_midi_notes(path: Path) -> tuple[list[TimedNote], int, int]:
    midi = MidiFile(path)
    tempo = _constant_tempo(midi)
    notes: list[TimedNote] = []

    for track_index, track in enumerate(midi.tracks):
        absolute_tick = 0
        track_name = f"Track {track_index}"
        active: dict[tuple[int, int], list[tuple[int, int]]] = {}
        for message in track:
            absolute_tick += message.time
            if message.type == "track_name":
                track_name = message.name
            elif message.type == "note_on" and message.velocity > 0:
                key = (message.channel, message.note)
                active.setdefault(key, []).append((absolute_tick, message.velocity))
            elif message.type in ("note_off", "note_on"):
                key = (message.channel, message.note)
                starts = active.get(key)
                if not starts:
                    continue
                start_tick, velocity = starts.pop(0)
                duration_ticks = max(1, absolute_tick - start_tick)
                notes.append(
                    TimedNote(
                        track=track_name,
                        note=message.note,
                        velocity=velocity,
                        channel=message.channel,
                        start_seconds=tick2second(start_tick, midi.ticks_per_beat, tempo),
                        duration_seconds=tick2second(duration_ticks, midi.ticks_per_beat, tempo),
                    )
                )

    notes.sort(key=lambda item: (item.start_seconds, item.track, item.note))
    return notes, midi.ticks_per_beat, tempo


def _write_wav(path: Path, stereo: np.ndarray, sample_rate: int) -> None:
    clipped = np.clip(stereo, -1.0, 1.0)
    pcm = np.round(clipped * 32767.0).astype("<i2")
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(2)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(pcm.tobytes(order="C"))


def render_midi_to_wav(
    midi_path: Path,
    wav_path: Path,
    *,
    sample_rate: int = 44100,
    target_peak: float = 0.92,
    tail_seconds: float = 0.60,
) -> RenderStats:
    notes, _, _ = parse_midi_notes(midi_path)
    if not notes:
        raise ValueError("MIDI contains no note events to render.")

    longest_release = max((preset.adsr.release for preset in DEFAULT_PRESETS.values()), default=0.0)
    final_note_end = max(note.start_seconds + note.duration_seconds for note in notes)
    duration = final_note_end + max(tail_seconds, longest_release)
    frame_count = max(1, int(math.ceil(duration * sample_rate)))
    mix = np.zeros((frame_count, 2), dtype=np.float64)

    for note in notes:
        if note.channel == 9 or note.track == "Drums":
            voice = _drum_voice(note, sample_rate)
        else:
            preset = DEFAULT_PRESETS.get(note.track, DEFAULT_PRESETS["Melody"])
            voice = _tonal_voice(note, preset, sample_rate)

        start = int(round(note.start_seconds * sample_rate))
        end = min(frame_count, start + len(voice))
        if end > start:
            mix[start:end] += voice[: end - start]

    source_peak = float(np.max(np.abs(mix))) if mix.size else 0.0
    if source_peak <= 0.0:
        normalization_gain = 1.0
    else:
        normalization_gain = target_peak / source_peak
    mix *= normalization_gain

    output_peak = float(np.max(np.abs(mix))) if mix.size else 0.0
    rms = float(np.sqrt(np.mean(np.square(mix)))) if mix.size else 0.0
    _write_wav(wav_path, mix, sample_rate)

    return RenderStats(
        sample_rate=sample_rate,
        channels=2,
        frames=frame_count,
        duration_seconds=frame_count / sample_rate,
        source_peak=source_peak,
        output_peak=output_peak,
        rms=rms,
        normalization_gain=normalization_gain,
        note_count=len(notes),
    )


def load_render_config(path: Path) -> dict[str, int | float]:
    data = json.loads(path.read_text(encoding="utf-8"))
    sample_rate = int(data.get("sample_rate", 44100))
    target_peak = float(data.get("target_peak", 0.92))
    tail_seconds = float(data.get("tail_seconds", 0.60))
    if sample_rate < 8000:
        raise ValueError("sample_rate must be at least 8000 Hz.")
    if not 0.0 < target_peak <= 1.0:
        raise ValueError("target_peak must be in the range (0, 1].")
    if tail_seconds < 0.0:
        raise ValueError("tail_seconds must be non-negative.")
    return {
        "sample_rate": sample_rate,
        "target_peak": target_peak,
        "tail_seconds": tail_seconds,
    }


def file_sha256(path: Path) -> str:
    return _sha256(path)
