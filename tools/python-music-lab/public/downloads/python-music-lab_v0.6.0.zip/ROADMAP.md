# Roadmap

## Phase 01: MIDI生成 + ルール作曲 ✅

- コード進行
- ベース
- ドラム
- メロディ
- Seed固定
- MIDI出力

## Phase 01.5: 候補生成・比較基盤 ✅

- 複数候補生成
- プリセット
- manifest.json
- ポートフォリオ向け静的成果物設計

## Phase 02: 作曲エンジン強化 ✅

### Phase 02A: 曲構成 + モチーフ ✅

- モチーフ生成
- 反復・変奏
- Aメロ / Bメロ / サビ構造
- 音域制御
- セクション別密度・エネルギー
- MIDI section marker

### Phase 02B: 音楽性 + 評価 ✅

- Major / Minor対応
- Minorでの和声的ドミナント `V`
- 非和声音
- `sparse` / `flowing` / `driving` リズム文法
- half / authentic cadence
- セクション遷移のbass approach / drum fill
- 複数候補スコアリング
- algorithm selection / human selection 分離

## Phase 03: Python音響合成 ✅

### Phase 03A: MIDI → WAV MVP ✅

- NumPy oscillator
- additive sine harmonics
- ADSR envelope
- MIDI parser
- procedural drums
- stereo panning / mixer
- deterministic peak normalization
- PCM16 WAV export
- WAV SHA-256 / clipping QA

### Phase 03B: 音色と空間 ✅

- sine / triangle / square / saw oscillator
- track別synth preset
- low-pass Filter
- Delay / Reverb
- track balance
- soft saturation
- WAV master export
- optional OGG/Vorbis browser preview
- Portfolio City用audio source contract
- A / B / Chorus秒位置metadata
- WAV byte reproducibility / OGG decode QA

今後、より高度なband-limited oscillator、EQ、高品質reverb、loudness targetは必要になった時点でRendering Layerを拡張する。Phase 03Bでは依存を増やしすぎず、静的ポートフォリオ展示に必要な音質・形式までを到達点とする。

## Phase 04: 生成AI統合 ← Next

### Phase 04A: モデル調査・接続設計

- 2026年時点のローカル音楽生成モデルを再調査
- RTX 5060 8GBでの実運用候補を検証
- Google Colab向け重量級候補を分離
- license / model weight / runtime / VRAM / export形式を記録
- Python作曲研究所のMIDI・コード・BPM・参考WAVをどこまで条件入力できるか比較

### Phase 04B: Controlled AI Rendering

- Python側のCompositionを保持
- AIは演奏・音色・アレンジ候補として接続
- 元MIDI / Python Synth版 / AI版を同じSeed・曲IDで比較可能にする
- Stem単位の生成・差し替えを検討
- 生成条件とモデル情報をmanifestへ保存

## Phase 05: 統合作曲環境

- プロジェクト設定ファイル
- 曲構成エディタ
- 候補管理
- Seed管理
- MIDI / WAV / AI音源の一括生成
- 実験ログ・採用履歴
- GUI化
- Portfolio City展示連携
