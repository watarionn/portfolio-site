@echo off
setlocal
cd /d "%~dp0"

py -3 preflight.py
if errorlevel 1 (
  echo.
  echo Project Snapshot Generator cannot start until the environment check passes.
  pause
  exit /b 1
)

py -3 app.py
if errorlevel 1 pause
