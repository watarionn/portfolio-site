# Phase 2 QA

Date: 2026-09-24

## Goal

Add a Windows GUI on top of the locked Phase 1 scanner without duplicating analysis logic.

## GUI scope

- project-folder picker
- open selected project folder
- background-thread analysis
- live status and indeterminate progress
- summary cards for files, folders, size, extensions, skipped paths and issues
- Markdown preview
- extension breakdown table
- large-file table
- audit view for Git ignore candidates, skipped paths and scan issues
- file-lines toggle without rescanning
- configurable large-file threshold
- Save As workflow for Markdown
- explicit overwrite confirmation
- open last output folder

## Core integration

The GUI scans once, keeps the Snapshot object in memory, and renders/saves from that same object.

A new write_snapshot_report helper allows an already scanned Snapshot to be saved without running a second filesystem traversal.

## Automated QA

- Python compile: PASS
- Phase 1 + Phase 2 unit/UI tests: 15 / 15 PASS
- GUI construction and snapshot rendering: PASS
- project-change result invalidation: PASS
- file-lines toggle: PASS
- large-file threshold validation: PASS

## Runtime smoke

- GUI launch: PASS
- window title: Project Snapshot Generator
- minimum supported window size: 980 x 650
- default window size: 1180 x 790
- Video Workbench can remain open at the same time: PASS

## Notes

Filesystem scanning runs on a background thread so large project scans do not block Tkinter's main event loop.

No third-party Python packages are required.
