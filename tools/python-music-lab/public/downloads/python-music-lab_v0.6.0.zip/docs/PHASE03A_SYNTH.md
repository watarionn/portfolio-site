# Phase 03A - Python Synth / MIDI to WAV

## Goal

Phase 02までの作曲結果を、OSやDAWのGeneral MIDI音源へ依存せず、Python Music Lab自身のRendering LayerでWAVへ変換する。

## Input

`output/phase02b/best_candidate.mid`

Phase 03Aはconstant tempo MIDIを対象とし、track nameとchannel 9 percussionを利用してvoiceを割り当てる。

## Signal path

```text
MIDI
  ↓ parse
TimedNote
  ↓
Voice
  ├─ Melody: additive sine harmonics + ADSR
  ├─ Chords: additive sine harmonics + ADSR
  ├─ Bass: additive sine harmonics + ADSR
  └─ Drums: deterministic procedural synthesis
  ↓
stereo panning
  ↓
mixer
  ↓
peak normalization
  ↓
PCM16 WAV
```

## Determinism

- Tonal voicesは数式のみで生成する。
- Noiseを使うdrum voiceはnote numberとstart timeからseedを決定する。
- DitherはPhase 03Aでは使用しない。
- 同一MIDI・同一render configから同一WAV bytesを再生成できることをQAする。

## Default render

- sample rate: 44,100 Hz
- channels: 2
- sample format: signed PCM16
- target peak: 0.92 full scale
- tail: 0.60 s

## Baseline result

Phase 02B best candidate:

- BPM: 128
- note events: 614
- render duration: 45.600 s
- source mix peak: 0.78425612
- normalized peak: 0.92000000
- RMS: 0.13336065
- WAV SHA-256: `35e1aa23eb1e4e32c3387e6ec102614b1616f13fcb5d54d4a364a9113d32c471`

## Deliberate limitations

Phase 03Aでは以下をまだ行わない。

- filter
- compressor / limiter
- delay
- reverb
- advanced synthesis oscillators
- OGG encoding
- mastering / LUFS target

これらはPhase 03Bへ送る。
