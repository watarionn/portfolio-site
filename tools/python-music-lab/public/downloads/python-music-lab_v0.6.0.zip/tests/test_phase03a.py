from __future__ import annotations

import hashlib
import sys
import tempfile
import unittest
import wave
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from python_music_lab.synth import (  # noqa: E402
    ADSR,
    _adsr_envelope,
    file_sha256,
    midi_note_to_hz,
    parse_midi_notes,
    render_midi_to_wav,
)


class Phase03ATests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = PROJECT_ROOT / "output" / "phase02b" / "best_candidate.mid"

    def test_a4_is_440_hz(self) -> None:
        self.assertAlmostEqual(midi_note_to_hz(69), 440.0, places=9)

    def test_adsr_is_bounded_and_releases_to_zero(self) -> None:
        env = _adsr_envelope(0.20, ADSR(0.01, 0.03, 0.6, 0.05), 8000)
        self.assertGreater(len(env), 0)
        self.assertGreaterEqual(float(np.min(env)), 0.0)
        self.assertLessEqual(float(np.max(env)), 1.0)
        self.assertAlmostEqual(float(env[-1]), 0.0, places=12)

    def test_midi_parser_reads_named_tracks(self) -> None:
        notes, ticks_per_beat, _ = parse_midi_notes(self.source)
        self.assertEqual(ticks_per_beat, 480)
        names = {note.track for note in notes}
        self.assertTrue({"Melody", "Chords", "Bass", "Drums"}.issubset(names))
        self.assertGreater(len(notes), 100)

    def test_render_is_deterministic_stereo_pcm16_and_below_full_scale(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            first = Path(temp_dir) / "first.wav"
            second = Path(temp_dir) / "second.wav"
            stats_a = render_midi_to_wav(self.source, first, sample_rate=22050, target_peak=0.90)
            stats_b = render_midi_to_wav(self.source, second, sample_rate=22050, target_peak=0.90)
            self.assertEqual(file_sha256(first), file_sha256(second))
            self.assertEqual(stats_a, stats_b)
            self.assertLessEqual(stats_a.output_peak, 0.9000001)
            with wave.open(str(first), "rb") as handle:
                self.assertEqual(handle.getnchannels(), 2)
                self.assertEqual(handle.getsampwidth(), 2)
                self.assertEqual(handle.getframerate(), 22050)
                self.assertGreater(handle.getnframes(), 0)


if __name__ == "__main__":
    unittest.main()
