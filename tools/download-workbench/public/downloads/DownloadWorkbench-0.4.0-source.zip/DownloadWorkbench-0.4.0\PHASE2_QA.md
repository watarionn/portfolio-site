# Phase 2 QA

Date: 2026-09-25

## Goal

Add a Windows desktop GUI on top of the clean Phase 1 core without reintroducing cookie, browser-profile, provider, or authentication state.

## Workflow

1. Paste a URL.
2. Analyze without downloading.
3. Review title, uploader, duration, extractor, formats, and subtitles.
4. Choose Video, Audio, or an explicit Format ID.
5. Optionally select a time range, subtitles, metadata, or thumbnail.
6. Confirm that the user has permission to save the content.
7. Start Download.

## GUI scope

- URL field
- output folder
- yt-dlp / ffmpeg status
- background URL analysis
- media summary
- format table
- subtitle table
- format double-click selection
- subtitle double-click selection
- Video / Audio / Format ID modes
- range start / end
- precise range option
- subtitle language entry
- automatic subtitles
- info JSON
- thumbnail
- sanitized command preview
- background download log
- rights/permission checkbox gate

## Automated QA

- Python compile: PASS
- Phase 1 + Phase 2 tests: 24 / 24 PASS
- GUI construction: PASS
- permission gate: PASS
- format selection: PASS
- subtitle selection: PASS
- command preview redaction: PASS

## Real yt-dlp analyze smoke

A two-second MP4 fixture was generated locally with ffmpeg and served from an in-process Python ThreadingHTTPServer.

Result:

- HTTP serving: PASS
- yt-dlp real analyze path: PASS
- extractor: Generic
- formats returned: 1
- no external site or cookie used

## Visual QA

- real application screenshot: `qa/screenshots/phase2-main.png`
- capture method: direct target-window PrintWindow
- screenshot size: 1256 x 879
- no taskbar or overlapping application window
- populated formats, subtitles, range settings, tool versions, and rights gate are visible

## Safety boundary

- Download button is gated behind an explicit permission confirmation.
- Command Preview redacts token/signature-like query values.
- yt-dlp still runs with --ignore-config.
- no Cookie / Authorization / browser profile controls are present in the UI.
- no DRM/access-control bypass controls are present.
