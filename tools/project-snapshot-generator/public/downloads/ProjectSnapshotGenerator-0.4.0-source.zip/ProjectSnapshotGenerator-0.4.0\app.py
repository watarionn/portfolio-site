from __future__ import annotations

import os
import threading
import traceback
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from project_snapshot_core import (
    Snapshot,
    SnapshotError,
    default_output_path,
    format_size,
    render_markdown,
    scan_project,
    write_snapshot_report,
)


APP_TITLE = "Project Snapshot Generator"
COMPACT_TREE_FILE_THRESHOLD = 500


def should_use_compact_tree(snapshot: Snapshot) -> bool:
    return snapshot.total_files >= COMPACT_TREE_FILE_THRESHOLD


def project_scale(snapshot: Snapshot) -> str:
    if snapshot.total_files < 100:
        return "Small"
    if snapshot.total_files < 500:
        return "Medium"
    if snapshot.total_files < 2000:
        return "Large"
    return "Very Large"


def snapshot_summary(snapshot: Snapshot) -> dict[str, str]:
    return {
        "files": f"{snapshot.total_files:,}",
        "directories": f"{snapshot.total_dirs:,}",
        "size": format_size(snapshot.total_bytes),
        "skipped": f"{len(snapshot.skipped_paths):,}",
        "issues": f"{len(snapshot.issues):,}",
        "extensions": f"{len(snapshot.extensions):,}",
    }


def threshold_bytes(megabytes: str) -> int:
    try:
        value = float(megabytes)
    except ValueError as exc:
        raise ValueError("Large-file threshold must be a number.") from exc
    if value <= 0:
        raise ValueError("Large-file threshold must be greater than 0 MB.")
    return max(1, int(value * 1024 * 1024))


class ProjectSnapshotApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1180x790")
        self.minsize(980, 650)

        self.project_var = tk.StringVar()
        self.include_files_var = tk.BooleanVar(value=True)
        self.threshold_var = tk.StringVar(value="10")
        self.status_var = tk.StringVar(value="フォルダを選択して解析してください。")
        self.profile_var = tk.StringVar(value="Project scale: —")
        self.preview_mode_var = tk.StringVar(value="Preview: —")

        self.summary_vars = {
            "files": tk.StringVar(value="—"),
            "directories": tk.StringVar(value="—"),
            "size": tk.StringVar(value="—"),
            "extensions": tk.StringVar(value="—"),
            "skipped": tk.StringVar(value="—"),
            "issues": tk.StringVar(value="—"),
        }

        self.current_snapshot: Snapshot | None = None
        self.last_output: Path | None = None
        self._busy = False
        self._threshold_at_scan: str | None = None

        self._configure_style()
        self._build_ui()
        self._bind_updates()
        self._bind_shortcuts()

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        style.configure("Summary.TLabel", font=("TkDefaultFont", 13, "bold"))
        style.configure("Action.TButton", padding=(12, 6))
        style.configure("Treeview", rowheight=24)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=14)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(3, weight=1)

        source = ttk.LabelFrame(outer, text="プロジェクト", padding=12)
        source.grid(row=0, column=0, sticky="ew")
        source.columnconfigure(0, weight=1)

        self.project_entry = ttk.Entry(source, textvariable=self.project_var)
        self.project_entry.grid(row=0, column=0, sticky="ew", padx=(0, 8))

        ttk.Button(source, text="選択", command=self.browse_project).grid(
            row=0, column=1, padx=(0, 8)
        )
        ttk.Button(source, text="フォルダを開く", command=self.open_project).grid(
            row=0, column=2, padx=(0, 8)
        )
        self.analyze_button = ttk.Button(
            source,
            text="解析",
            command=self.analyze,
            style="Action.TButton",
        )
        self.analyze_button.grid(row=0, column=3)

        options = ttk.Frame(source)
        options.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(10, 0))
        ttk.Checkbutton(
            options,
            text="ツリーにファイルも表示",
            variable=self.include_files_var,
            command=self.refresh_preview,
        ).pack(side="left")

        ttk.Label(options, text="巨大ファイル判定").pack(side="left", padx=(24, 6))
        self.threshold_spin = ttk.Spinbox(
            options,
            from_=0.1,
            to=102400,
            increment=1,
            width=8,
            textvariable=self.threshold_var,
        )
        self.threshold_spin.pack(side="left")
        ttk.Label(options, text="MB以上").pack(side="left", padx=(5, 0))
        ttk.Label(options, textvariable=self.profile_var).pack(side="right")

        summary = ttk.Frame(outer)
        summary.grid(row=1, column=0, sticky="ew", pady=(12, 0))
        for column in range(6):
            summary.columnconfigure(column, weight=1)

        labels = [
            ("Files", "files"),
            ("Folders", "directories"),
            ("Size", "size"),
            ("Extensions", "extensions"),
            ("Skipped", "skipped"),
            ("Issues", "issues"),
        ]
        for column, (label, key) in enumerate(labels):
            card = ttk.LabelFrame(summary, text=label, padding=(10, 8))
            card.grid(
                row=0,
                column=column,
                sticky="nsew",
                padx=(0 if column == 0 else 4, 0 if column == 5 else 4),
            )
            ttk.Label(
                card,
                textvariable=self.summary_vars[key],
                style="Summary.TLabel",
            ).pack(anchor="center")

        toolbar = ttk.Frame(outer)
        toolbar.grid(row=2, column=0, sticky="ew", pady=(12, 8))
        self.progress = ttk.Progressbar(toolbar, mode="indeterminate", length=170)
        self.progress.pack(side="left")
        ttk.Label(toolbar, textvariable=self.status_var).pack(
            side="left", padx=(10, 0)
        )
        self.save_button = ttk.Button(
            toolbar, text="Markdown保存", command=self.save_report, state="disabled"
        )
        self.save_button.pack(side="right")
        self.copy_button = ttk.Button(
            toolbar, text="Previewをコピー", command=self.copy_preview, state="disabled"
        )
        self.copy_button.pack(side="right", padx=(0, 8))
        self.open_output_button = ttk.Button(
            toolbar, text="保存先を開く", command=self.open_output, state="disabled"
        )
        self.open_output_button.pack(side="right", padx=(0, 8))

        notebook = ttk.Notebook(outer)
        notebook.grid(row=3, column=0, sticky="nsew")

        preview_frame = ttk.Frame(notebook, padding=8)
        notebook.add(preview_frame, text="Markdown Preview")
        preview_frame.rowconfigure(0, weight=1)
        preview_frame.columnconfigure(0, weight=1)
        self.preview = tk.Text(
            preview_frame,
            wrap="none",
            font=("Consolas", 10),
            undo=False,
            state="disabled",
        )
        preview_y = ttk.Scrollbar(
            preview_frame, orient="vertical", command=self.preview.yview
        )
        preview_x = ttk.Scrollbar(
            preview_frame, orient="horizontal", command=self.preview.xview
        )
        self.preview.configure(
            yscrollcommand=preview_y.set,
            xscrollcommand=preview_x.set,
        )
        self.preview.grid(row=0, column=0, sticky="nsew")
        preview_y.grid(row=0, column=1, sticky="ns")
        preview_x.grid(row=1, column=0, sticky="ew")

        extensions_frame = ttk.Frame(notebook, padding=8)
        notebook.add(extensions_frame, text="Extensions")
        extensions_frame.rowconfigure(0, weight=1)
        extensions_frame.columnconfigure(0, weight=1)
        self.extensions_tree = ttk.Treeview(
            extensions_frame,
            columns=("extension", "count", "share"),
            show="headings",
        )
        self.extensions_tree.heading("extension", text="Extension")
        self.extensions_tree.heading("count", text="Files")
        self.extensions_tree.heading("share", text="Share")
        self.extensions_tree.column("extension", width=260, anchor="w")
        self.extensions_tree.column("count", width=120, anchor="e")
        self.extensions_tree.column("share", width=120, anchor="e")
        self.extensions_tree.grid(row=0, column=0, sticky="nsew")
        extensions_y = ttk.Scrollbar(
            extensions_frame,
            orient="vertical",
            command=self.extensions_tree.yview,
        )
        self.extensions_tree.configure(yscrollcommand=extensions_y.set)
        extensions_y.grid(row=0, column=1, sticky="ns")

        large_frame = ttk.Frame(notebook, padding=8)
        notebook.add(large_frame, text="Large Files")
        large_frame.rowconfigure(0, weight=1)
        large_frame.columnconfigure(0, weight=1)
        self.large_tree = ttk.Treeview(
            large_frame,
            columns=("path", "size"),
            show="headings",
        )
        self.large_tree.heading("path", text="Path")
        self.large_tree.heading("size", text="Size")
        self.large_tree.column("path", width=760, anchor="w")
        self.large_tree.column("size", width=140, anchor="e")
        self.large_tree.grid(row=0, column=0, sticky="nsew")
        large_y = ttk.Scrollbar(
            large_frame,
            orient="vertical",
            command=self.large_tree.yview,
        )
        self.large_tree.configure(yscrollcommand=large_y.set)
        large_y.grid(row=0, column=1, sticky="ns")

        audit_frame = ttk.Frame(notebook, padding=8)
        notebook.add(audit_frame, text="Audit")
        audit_frame.rowconfigure(0, weight=1)
        audit_frame.columnconfigure(0, weight=1)
        self.audit_text = tk.Text(
            audit_frame,
            wrap="word",
            font=("Consolas", 10),
            state="disabled",
        )
        self.audit_text.grid(row=0, column=0, sticky="nsew")

    def _bind_updates(self) -> None:
        self.project_var.trace_add("write", lambda *_: self._project_changed())
        self.threshold_var.trace_add("write", lambda *_: self._threshold_changed())

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-o>", lambda _event: self.browse_project())
        self.bind("<F5>", lambda _event: self.analyze())
        self.bind("<Control-s>", lambda _event: self.save_report())
        self.bind("<Control-Shift-C>", lambda _event: self.copy_preview())

    def _threshold_changed(self) -> None:
        if self.current_snapshot is None or self._threshold_at_scan is None:
            return
        if self.threshold_var.get().strip() != self._threshold_at_scan:
            self.status_var.set("巨大ファイル判定が変更されました。再解析すると一覧へ反映されます。")

    def _project_changed(self) -> None:
        if self.current_snapshot is None:
            return
        try:
            value = Path(self.project_var.get()).expanduser().resolve()
        except (OSError, RuntimeError):
            value = None
        if value != self.current_snapshot.root:
            self._clear_results("フォルダが変更されました。再解析してください。")

    def _replace_text(self, widget: tk.Text, text: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.configure(state="disabled")

    def _clear_results(self, status: str) -> None:
        self.current_snapshot = None
        self._threshold_at_scan = None
        self.profile_var.set("Project scale: —")
        self.preview_mode_var.set("Preview: —")
        for variable in self.summary_vars.values():
            variable.set("—")
        self._replace_text(self.preview, "")
        self._replace_text(self.audit_text, "")
        for tree in (self.extensions_tree, self.large_tree):
            for item in tree.get_children():
                tree.delete(item)
        self.save_button.configure(state="disabled")
        self.copy_button.configure(state="disabled")
        self.status_var.set(status)

    def browse_project(self) -> None:
        selected = filedialog.askdirectory(
            title="解析するプロジェクトフォルダを選択"
        )
        if selected:
            self.project_var.set(selected)
            self.analyze()

    def open_project(self) -> None:
        path = Path(self.project_var.get()).expanduser()
        if not path.is_dir():
            messagebox.showerror(APP_TITLE, "有効なプロジェクトフォルダを選択してください。")
            return
        os.startfile(path)

    def analyze(self) -> None:
        if self._busy:
            return
        project = self.project_var.get().strip()
        if not project:
            messagebox.showerror(APP_TITLE, "プロジェクトフォルダを選択してください。")
            return
        try:
            threshold = threshold_bytes(self.threshold_var.get().strip())
        except ValueError as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self._set_busy(True, "解析中…")
        threading.Thread(
            target=self._scan_worker,
            args=(project, threshold),
            daemon=True,
        ).start()

    def _scan_worker(self, project: str, threshold: int) -> None:
        try:
            snapshot = scan_project(
                project,
                include_files_in_tree=True,
                large_file_threshold=threshold,
            )
        except Exception as exc:
            trace = traceback.format_exc()
            self.after(
                0,
                lambda exc=exc, trace=trace: self._scan_failed(exc, trace),
            )
            return
        self.after(0, lambda: self._scan_finished(snapshot))

    def _scan_failed(self, exc: Exception, trace: str) -> None:
        self._set_busy(False, "解析に失敗しました。")
        self._replace_text(self.audit_text, trace)
        if isinstance(exc, SnapshotError):
            message = str(exc)
        else:
            message = f"{type(exc).__name__}: {exc}"
        messagebox.showerror(APP_TITLE, message)

    def _scan_finished(self, snapshot: Snapshot) -> None:
        self.current_snapshot = snapshot
        self._threshold_at_scan = self.threshold_var.get().strip()
        self.include_files_var.set(not should_use_compact_tree(snapshot))
        summary = snapshot_summary(snapshot)
        for key, value in summary.items():
            self.summary_vars[key].set(value)
        self.profile_var.set(f"Project scale: {project_scale(snapshot)}")
        self._populate_extensions(snapshot)
        self._populate_large_files(snapshot)
        self._populate_audit(snapshot)
        self.refresh_preview()
        self.save_button.configure(state="normal")
        self.copy_button.configure(state="normal")
        compact_note = " / compact preview" if not self.include_files_var.get() else ""
        self._set_busy(
            False,
            f"解析完了: {snapshot.total_files:,} files / {snapshot.total_dirs:,} folders{compact_note}",
        )

    def _populate_extensions(self, snapshot: Snapshot) -> None:
        for item in self.extensions_tree.get_children():
            self.extensions_tree.delete(item)
        for extension, count in sorted(
            snapshot.extensions.items(), key=lambda item: (-item[1], item[0])
        ):
            share = (count / snapshot.total_files * 100) if snapshot.total_files else 0
            self.extensions_tree.insert(
                "",
                "end",
                values=(extension, f"{count:,}", f"{share:.1f}%"),
            )

    def _populate_large_files(self, snapshot: Snapshot) -> None:
        for item in self.large_tree.get_children():
            self.large_tree.delete(item)
        for file in snapshot.largest_files:
            self.large_tree.insert(
                "",
                "end",
                values=(file.relative_path, format_size(file.size_bytes)),
            )

    def _populate_audit(self, snapshot: Snapshot) -> None:
        lines = ["Git ignore candidates"]
        if snapshot.gitignore_candidates:
            lines.extend(f"  + {item}/" for item in snapshot.gitignore_candidates)
        else:
            lines.append("  None")

        lines += ["", "Skipped paths"]
        if snapshot.skipped_paths:
            lines.extend(f"  - {item}" for item in snapshot.skipped_paths)
        else:
            lines.append("  None")

        lines += ["", "Scan issues"]
        if snapshot.issues:
            lines.extend(
                f"  ! {issue.relative_path}: {issue.message}"
                for issue in snapshot.issues
            )
        else:
            lines.append("  None")

        self._replace_text(self.audit_text, "\n".join(lines))

    def refresh_preview(self) -> None:
        if self.current_snapshot is None:
            return
        include_files = self.include_files_var.get()
        text = render_markdown(
            self.current_snapshot,
            include_files_in_tree=include_files,
        )
        self._replace_text(self.preview, text)
        mode = "Full tree" if include_files else "Compact tree"
        self.preview_mode_var.set(
            f"Preview: {mode} / {len(text):,} characters"
        )

    def copy_preview(self) -> None:
        if self.current_snapshot is None:
            return
        text = self.preview.get("1.0", "end-1c")
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update_idletasks()
        self.status_var.set(f"Previewをコピーしました: {len(text):,} characters")

    def save_report(self) -> None:
        snapshot = self.current_snapshot
        if snapshot is None:
            return
        suggested = default_output_path(snapshot.root)
        selected = filedialog.asksaveasfilename(
            title="Markdownスナップショットを保存",
            defaultextension=".md",
            initialdir=str(suggested.parent),
            initialfile=suggested.name,
            filetypes=[("Markdown", "*.md"), ("All files", "*.*")],
        )
        if not selected:
            return

        target = Path(selected)
        overwrite = False
        if target.exists():
            overwrite = messagebox.askyesno(
                APP_TITLE,
                f"既存ファイルを上書きしますか？\n\n{target}",
            )
            if not overwrite:
                return

        try:
            output = write_snapshot_report(
                snapshot,
                target,
                include_files_in_tree=self.include_files_var.get(),
                overwrite=overwrite,
            )
        except OSError as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        self.last_output = output
        self.open_output_button.configure(state="normal")
        self.status_var.set(f"保存しました: {output}")
        messagebox.showinfo(APP_TITLE, f"Markdownを保存しました。\n\n{output}")

    def open_output(self) -> None:
        if self.last_output is None or not self.last_output.exists():
            messagebox.showerror(APP_TITLE, "保存済みの出力ファイルがありません。")
            return
        os.startfile(self.last_output.parent)

    def _set_busy(self, busy: bool, status: str) -> None:
        self._busy = busy
        self.status_var.set(status)
        state = "disabled" if busy else "normal"
        self.analyze_button.configure(state=state)
        self.project_entry.configure(state=state)
        self.threshold_spin.configure(state=state)
        if busy:
            self.save_button.configure(state="disabled")
            self.copy_button.configure(state="disabled")
            self.progress.start(10)
        else:
            if self.current_snapshot is not None:
                self.save_button.configure(state="normal")
                self.copy_button.configure(state="normal")
            self.progress.stop()


def main() -> None:
    app = ProjectSnapshotApp()
    app.mainloop()


if __name__ == "__main__":
    main()
