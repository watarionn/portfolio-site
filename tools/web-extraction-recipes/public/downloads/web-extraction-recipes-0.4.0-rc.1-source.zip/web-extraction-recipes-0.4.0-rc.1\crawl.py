from __future__ import annotations

import argparse
from pathlib import Path

from crawl_core import crawl, load_crawl_recipe
from extraction_core import write_records


def read_start_urls(path: Path) -> list[str]:
    rows = []
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        value = raw.strip()
        if value and not value.startswith("#"):
            rows.append(value)
    return rows


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a list-to-detail crawl recipe."
    )
    parser.add_argument("urls", type=Path, help="UTF-8 text file with start URLs")
    parser.add_argument("recipe", type=Path, help="Crawl recipe JSON")
    parser.add_argument("-o", "--output", type=Path, required=True)
    parser.add_argument("--format", choices=("tsv", "csv", "json"), default=None)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    start_urls = read_start_urls(args.urls)
    recipe = load_crawl_recipe(args.recipe)
    result = crawl(start_urls, recipe, progress=print)
    write_records(list(result.records), args.output, format_name=args.format)

    stats = result.stats
    print(f"Recipe        : {recipe.name}")
    print(f"Rows          : {len(result.records)}")
    print(f"Fetched pages : {stats.fetched_pages}")
    print(f"Cache hits    : {stats.cache_hits}")
    print(f"Detail links  : {stats.unique_detail_links}")
    print(f"Output        : {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())