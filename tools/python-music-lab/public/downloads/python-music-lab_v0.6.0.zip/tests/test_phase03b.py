from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
import wave
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from python_music_lab.synth import file_sha256  # noqa: E402
from python_music_lab.synth_fx import (  # noqa: E402
    _moving_average_lowpass,
    _oscillator,
    export_ogg_vorbis,
    load_phase03b_config,
    render_midi_to_enhanced_wav,
)


class Phase03BTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = PROJECT_ROOT / "output" / "phase02b" / "best_candidate.mid"
        cls.config_path = PROJECT_ROOT / "config" / "phase03b_synth.json"
        cls.config = load_phase03b_config(cls.config_path)

    def test_waveform_palette_is_bounded(self) -> None:
        phase = np.linspace(0.0, 2.0, 4096, endpoint=False)
        for waveform in ("sine", "triangle", "square", "saw"):
            values = _oscillator(waveform, phase)
            self.assertEqual(values.shape, phase.shape)
            self.assertLessEqual(float(np.max(values)), 1.0000001)
            self.assertGreaterEqual(float(np.min(values)), -1.0000001)

    def test_lowpass_reduces_alternating_high_frequency_energy(self) -> None:
        mono = np.tile(np.array([1.0, -1.0]), 5000)
        stereo = np.column_stack((mono, mono))
        filtered = _moving_average_lowpass(stereo, 44100, 1200.0)
        self.assertLess(float(np.sqrt(np.mean(filtered**2))), 0.2)

    def test_enhanced_render_is_deterministic_and_valid_pcm16(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            first = Path(temp_dir) / "first.wav"
            second = Path(temp_dir) / "second.wav"
            kwargs = {
                "sample_rate": 22050,
                "target_peak": 0.90,
                "tail_seconds": 1.0,
                "voices": self.config["voices"],
                "track_gain": self.config["track_gain"],
                "delay": self.config["delay"],
                "reverb": self.config["reverb"],
                "saturation_drive": self.config["saturation_drive"],
            }
            stats_a, track_a = render_midi_to_enhanced_wav(self.source, first, **kwargs)
            stats_b, track_b = render_midi_to_enhanced_wav(self.source, second, **kwargs)
            self.assertEqual(file_sha256(first), file_sha256(second))
            self.assertEqual(stats_a, stats_b)
            self.assertEqual(track_a, track_b)
            self.assertLessEqual(stats_a.output_peak, 0.9000001)
            self.assertGreater(stats_a.rms, 0.0)
            with wave.open(str(first), "rb") as handle:
                self.assertEqual(handle.getnchannels(), 2)
                self.assertEqual(handle.getsampwidth(), 2)
                self.assertEqual(handle.getframerate(), 22050)
                self.assertGreater(handle.getnframes(), 0)

    def test_config_has_distinct_voice_waveforms(self) -> None:
        waveforms = {
            name: {layer.waveform for layer in preset.layers}
            for name, preset in self.config["voices"].items()
        }
        self.assertIn("saw", waveforms["Melody"])
        self.assertIn("triangle", waveforms["Chords"])
        self.assertIn("square", waveforms["Bass"])

    def test_ogg_export_when_ffmpeg_is_available(self) -> None:
        if shutil.which("ffmpeg") is None:
            self.skipTest("ffmpeg not installed")
        with tempfile.TemporaryDirectory() as temp_dir:
            wav_path = Path(temp_dir) / "source.wav"
            ogg_path = Path(temp_dir) / "preview.ogg"
            kwargs = {
                "sample_rate": 16000,
                "target_peak": 0.85,
                "tail_seconds": 0.5,
                "voices": self.config["voices"],
                "track_gain": self.config["track_gain"],
                "delay": self.config["delay"],
                "reverb": self.config["reverb"],
                "saturation_drive": self.config["saturation_drive"],
            }
            render_midi_to_enhanced_wav(self.source, wav_path, **kwargs)
            result = export_ogg_vorbis(wav_path, ogg_path, 3.0)
            self.assertTrue(result.available)
            self.assertTrue(result.created, msg=result.error)
            self.assertTrue(ogg_path.exists())
            self.assertGreater(ogg_path.stat().st_size, 1000)


if __name__ == "__main__":
    unittest.main()
