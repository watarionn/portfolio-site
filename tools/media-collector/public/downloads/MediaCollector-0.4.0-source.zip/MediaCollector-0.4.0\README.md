# Media Collector

複数の旧メディア収集スクリプトを、秘密情報を持ち込まずに作り直すためのローカルツールです。

現在はPhase 3まで進んでいます。ユーザーが用意したURL一覧を共通形式へ正規化し、重複を除外し、manifestを生成します。必要な場合だけ直接メディアURLをダウンロードできます。X / Pixiv / 汎用DOM向けのBrowser Bridgeも同梱しています。

## Phase 1

- Xの `pbs.twimg.com/media` URLを原寸 `name=orig` へ正規化
- 汎用HTTP/HTTPS URLの受け入れ
- テキスト / TSV / CSVからURL抽出
- URL単位の重複排除
- 画像 / 動画 / unknown の種別推定
- 安全なファイル名
- plan manifest JSON / TSV
- Content-Type検証付き直接ダウンロード
- 1ファイル上限サイズ
- SHA-256計算
- 同一内容の重複保存防止
- download manifest JSON / TSV
- 動画ダウンロードは既定OFF
- Cookie / token / passwordを保存・読込しない

## Windows GUI

    run_media_collector.bat

または:

    py -3 app.py

URL一覧を貼り付けてPlan作成すると、ネットワークへアクセスせずに正規化・重複排除・種別判定を確認できます。Downloadを押したときだけ実ファイルの取得を開始します。

## CLI

    py -3 collector.py urls.txt -o collected

上記はplanだけ作成し、ネットワークからファイルを取得しません。

直接メディアURLを保存する場合:

    py -3 collector.py urls.txt -o collected --download

動画も許可する場合:

    py -3 collector.py urls.txt -o collected --download --allow-videos

## Environment check

    py -3 preflight.py

`run_media_collector.bat` から起動した場合も同じpreflightを先に実行します。

必要環境:

- Windows
- Python 3.10以上
- Tkinter

追加のPythonパッケージは不要です。

## Distribution

ソースリリースを再生成する場合:

    powershell -ExecutionPolicy Bypass -File .\build_release.ps1 -Version 0.4.0

生成物:

    dist\MediaCollector-0.4.0-source.zip

`dist` はGit管理対象外です。

## Safety boundary

このリポジトリには、旧ツールに含まれていた認証トークン、Cookie、秘密鍵、ダウンロード履歴を移植しません。

Media Collectorは、利用者自身がアクセス権を持つコンテンツ、または保存が許可されたコンテンツを整理するためのツールとして設計します。認証回避、アクセス制御の回避、ペイウォール回避は実装しません。

## Source adapters / Browser Bridges

実装済み:

- X Browser Bridge: 表示中の pbs.twimg.com/media URLを抽出し、name=origへ正規化
- Pixiv Browser Bridge: 表示中の i.pximg.net 画像URLだけを抽出
- Generic DOM Bridge: img / video / source / direct media linkを抽出
- Desktop adapter: X / Pixiv / Genericを共通MediaItemへ変換

Browser BridgeはCookie・token・localStorage・sessionStorageを読みません。ブラウザが認証を担当し、Media CollectorにはURL文字列だけを渡します。

Pixivの直接画像取得時は、認証情報ではなく公開サイトのRefererヘッダーだけを付与します。

各adapterは共通のMediaItemへ変換し、保存・重複排除・manifest処理は共通コア側へ集約しています。

## Current release

Release Candidate: **0.4.0**

Phase 4では実HTTP経路の統合QA、ファイルシグネチャ検証、Download Results UI、preflight、再現可能な配布ZIPまでを正式なリリース境界として扱います。
