# Origin

The legacy source is DirTreeMaker.bat from the older tool collection.

Legacy source SHA-256: DEDA1D56EC2D6405C3E945E07C48F2E99D93C9BF44745499958EEB599D5FF11E

The BAT file embeds a PowerShell implementation that traverses a target folder, optionally lists files, calculates recursive file count and size, and writes a Markdown-style tree.

## Why rebuild it

The legacy implementation recalculates recursive folder statistics for every directory. Large projects can therefore be scanned repeatedly and become unnecessarily expensive.

It also scans hidden/cache/dependency directories by default, silently suppresses many filesystem errors, and overwrites an existing output file without an explicit overwrite decision.

Project Snapshot Generator keeps the useful folder-structure idea but replaces the traversal and reporting model.
