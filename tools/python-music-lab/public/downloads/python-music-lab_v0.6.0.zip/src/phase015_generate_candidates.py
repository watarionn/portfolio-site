from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import asdict, replace
from pathlib import Path

from python_music_lab.composer import SongConfig, compose_song
from python_music_lab.midi_writer import write_song


TRACK_SPECS = [
    ("Melody", 0, 0),
    ("Chords", 4, 1),
    ("Bass", 33, 2),
    ("Drums", 0, 9),
]


def load_presets(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def build_config(preset_name: str, preset: dict, seed: int) -> SongConfig:
    return SongConfig(
        title=f"{preset['label']} Candidate",
        bpm=int(preset["bpm"]),
        key_root=str(preset["key_root"]),
        mode=str(preset["mode"]),
        seed=seed,
        bars=int(preset["bars"]),
        progression=list(preset["progression"]),
        ticks_per_beat=480,
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def duration_seconds(config: SongConfig) -> float:
    beats = config.bars * 4
    return beats * 60.0 / config.bpm


def generate_candidate(output_dir: Path, preset_name: str, index: int, config: SongConfig) -> dict:
    song = compose_song(config)
    filename = f"candidate_{index:02d}.mid"
    output_path = output_dir / filename

    tracks = [
        (name, song[name], program, channel)
        for name, program, channel in TRACK_SPECS
    ]
    write_song(
        output_path=output_path,
        bpm=config.bpm,
        ticks_per_beat=config.ticks_per_beat,
        tracks=tracks,
    )

    return {
        "id": f"{preset_name}-{index:02d}",
        "preset": preset_name,
        "candidate_index": index,
        "title": config.title,
        "seed": config.seed,
        "bpm": config.bpm,
        "key": f"{config.key_root} {config.mode}",
        "bars": config.bars,
        "progression": config.progression,
        "duration_seconds": round(duration_seconds(config), 3),
        "note_counts": {name: len(song[name]) for name, _, _ in TRACK_SPECS},
        "midi_file": filename,
        "sha256": sha256(output_path),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate multiple MIDI composition candidates.")
    parser.add_argument("--preset", default="bright_pop", help="Preset key from candidate_presets.json")
    parser.add_argument("--count", type=int, default=None, help="Number of candidates to generate")
    args = parser.parse_args()

    project_root = Path(__file__).resolve().parents[1]
    presets_path = project_root / "config" / "candidate_presets.json"
    preset_data = load_presets(presets_path)

    presets = preset_data["presets"]
    if args.preset not in presets:
        names = ", ".join(sorted(presets))
        raise ValueError(f"Unknown preset: {args.preset}. Available: {names}")

    preset = presets[args.preset]
    count = args.count if args.count is not None else int(preset_data["candidate_count"])
    if count <= 0:
        raise ValueError("count must be greater than 0")

    output_dir = project_root / "output" / "candidates" / args.preset
    output_dir.mkdir(parents=True, exist_ok=True)

    candidates = []
    seed_base = int(preset["seed_base"])
    for index in range(1, count + 1):
        seed = seed_base + index - 1
        config = build_config(args.preset, preset, seed)
        candidates.append(generate_candidate(output_dir, args.preset, index, config))

    manifest = {
        "schema_version": 1,
        "generator": "Python Music Lab Phase 01.5",
        "preset": args.preset,
        "preset_label": preset["label"],
        "candidate_count": count,
        "candidates": candidates,
    }
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    print(f"Preset    : {args.preset} ({preset['label']})")
    print(f"Candidates: {count}")
    print(f"Output    : {output_dir}")
    print(f"Manifest  : {manifest_path}")
    for candidate in candidates:
        print(
            f"  {candidate['id']} seed={candidate['seed']} "
            f"sha256={candidate['sha256'][:12]}..."
        )


if __name__ == "__main__":
    main()
