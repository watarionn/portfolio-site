# Phase 2 QA

Date: 2026-09-24

## Static / unit

- `py -3 -m py_compile video_workbench_core.py app.py`: PASS
- `py -3 -m unittest discover -s tests -v`: PASS
- Unit tests: 9 / 9 PASS
- Tkinter construction smoke: PASS
- Initial window size: 1120 x 760

## Real FFmpeg smoke

Synthetic input:

- duration: 4.000 sec
- resolution: 320 x 180
- video: H.264
- audio: AAC
- path contains Japanese characters and spaces
Results:

- precise trim 1.0 -> 3.0 sec: 2.000 sec
- fast copy trim 1.0 -> 3.0 sec: 2.167 sec
- PNG 2 fps: 8 frames
- JPG 1 fps: 4 frames
- Unicode / spaces path: PASS

The fast-copy duration difference is expected behavior caused by keyframe boundaries.
The UI labels this mode as approximate and keeps precise re-encode as a separate choice.

## Current boundary

Phase 2 intentionally does not add unrelated video editing features.
The scope remains the two original tools:

1. trim a video range
2. export video frames
