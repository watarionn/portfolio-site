from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app import (
    ProjectSnapshotApp,
    project_scale,
    should_use_compact_tree,
    snapshot_summary,
    threshold_bytes,
)
from project_snapshot_core import scan_project


class AppLogicTests(unittest.TestCase):
    def test_threshold_bytes(self) -> None:
        self.assertEqual(threshold_bytes("10"), 10 * 1024 * 1024)
        self.assertEqual(threshold_bytes("0.5"), 512 * 1024)

    def test_invalid_threshold_rejected(self) -> None:
        with self.assertRaises(ValueError):
            threshold_bytes("0")
        with self.assertRaises(ValueError):
            threshold_bytes("abc")

    def test_snapshot_summary(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            root.mkdir()
            (root / "a.py").write_text("print('x')", encoding="utf-8")
            snapshot = scan_project(root)
            summary = snapshot_summary(snapshot)
            self.assertEqual(summary["files"], "1")
            self.assertEqual(summary["directories"], "0")
            self.assertEqual(summary["extensions"], "1")

    def test_gui_can_render_snapshot_and_toggle_file_lines(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            (root / "src").mkdir(parents=True)
            (root / "src" / "main.py").write_text("print('x')", encoding="utf-8")
            snapshot = scan_project(root)

            app = ProjectSnapshotApp()
            app.withdraw()
            self.addCleanup(app.destroy)

            app.project_var.set(str(root))
            app._scan_finished(snapshot)
            with_files = app.preview.get("1.0", "end")
            self.assertIn("main.py", with_files)
            self.assertEqual(app.summary_vars["files"].get(), "1")

            app.include_files_var.set(False)
            app.refresh_preview()
            folders_only = app.preview.get("1.0", "end")
            tree = folders_only.split("## Extension breakdown", 1)[0]
            self.assertNotIn("main.py", tree)

    def test_changing_project_clears_current_results(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            other = Path(temp) / "other"
            root.mkdir()
            other.mkdir()
            (root / "a.txt").write_text("x", encoding="utf-8")
            snapshot = scan_project(root)

            app = ProjectSnapshotApp()
            app.withdraw()
            self.addCleanup(app.destroy)

            app.project_var.set(str(root))
            app._scan_finished(snapshot)
            self.assertIsNotNone(app.current_snapshot)

            app.project_var.set(str(other))
            self.assertIsNone(app.current_snapshot)
            self.assertEqual(app.summary_vars["files"].get(), "—")

    def test_project_scale_and_compact_threshold(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            root.mkdir()
            for index in range(500):
                (root / f"f{index:03}.txt").write_text("x", encoding="utf-8")
            snapshot = scan_project(root)
            self.assertEqual(project_scale(snapshot), "Large")
            self.assertTrue(should_use_compact_tree(snapshot))

    def test_large_project_auto_switches_to_compact_preview(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            root.mkdir()
            for index in range(500):
                (root / f"f{index:03}.txt").write_text("x", encoding="utf-8")
            snapshot = scan_project(root)

            app = ProjectSnapshotApp()
            app.withdraw()
            self.addCleanup(app.destroy)
            app.project_var.set(str(root))
            app._scan_finished(snapshot)

            self.assertFalse(app.include_files_var.get())
            self.assertIn("Compact tree", app.preview_mode_var.get())
            tree = app.preview.get("1.0", "end").split("## Extension breakdown", 1)[0]
            self.assertNotIn("f000.txt", tree)

    def test_small_project_restores_full_preview_after_large_project(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            large_root = Path(temp) / "large"
            small_root = Path(temp) / "small"
            large_root.mkdir()
            small_root.mkdir()
            for index in range(500):
                (large_root / f"f{index:03}.txt").write_text("x", encoding="utf-8")
            (small_root / "one.txt").write_text("x", encoding="utf-8")

            app = ProjectSnapshotApp()
            app.withdraw()
            self.addCleanup(app.destroy)

            app.project_var.set(str(large_root))
            app._scan_finished(scan_project(large_root))
            self.assertFalse(app.include_files_var.get())

            app.project_var.set(str(small_root))
            app._scan_finished(scan_project(small_root))
            self.assertTrue(app.include_files_var.get())
            self.assertIn("Full tree", app.preview_mode_var.get())

    def test_threshold_change_marks_results_for_reanalysis(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            root.mkdir()
            (root / "a.bin").write_bytes(b"x" * 10)
            snapshot = scan_project(root)

            app = ProjectSnapshotApp()
            app.withdraw()
            self.addCleanup(app.destroy)
            app.project_var.set(str(root))
            app._scan_finished(snapshot)
            app.threshold_var.set("20")

            self.assertIn("再解析", app.status_var.get())

    def test_extension_table_contains_share(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "project"
            root.mkdir()
            (root / "a.py").write_text("x", encoding="utf-8")
            (root / "b.py").write_text("x", encoding="utf-8")
            (root / "c.md").write_text("x", encoding="utf-8")
            snapshot = scan_project(root)

            app = ProjectSnapshotApp()
            app.withdraw()
            self.addCleanup(app.destroy)
            app.project_var.set(str(root))
            app._scan_finished(snapshot)

            rows = [app.extensions_tree.item(i, "values") for i in app.extensions_tree.get_children()]
            self.assertIn((".py", "2", "66.7%"), rows)


if __name__ == "__main__":
    unittest.main()
