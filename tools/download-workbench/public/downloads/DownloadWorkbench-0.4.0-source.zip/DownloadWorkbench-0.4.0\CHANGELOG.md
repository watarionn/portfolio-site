# Changelog

## 0.4.0 - 2026-09-25

Initial release candidate of Download Workbench.

### Added

- Windows Tkinter desktop GUI and CLI
- URL analysis through yt-dlp without downloading
- title, uploader, duration and extractor display
- format table and subtitle table
- Video / Audio / explicit Format ID modes
- time-range download using yt-dlp download sections
- precise range option with forced keyframes
- subtitle language selection
- optional automatic subtitles
- optional info JSON and thumbnail output
- output folder selection
- yt-dlp and ffmpeg status display
- sanitized command preview
- explicit rights/permission gate before Download
- query token/signature redaction in previews
- embedded URL credential rejection
- no-overwrite behavior
- real yt-dlp + ffmpeg localhost integration tests
- direct-window QA screenshots

### Security boundary

- yt-dlp always runs with --ignore-config
- no cookie auto-import
- no browser profile import
- no Authorization argument generation
- no DRM bypass
- no access-control or paywall bypass
- legacy ytdlp_desktop cookie/profile/provider/archive/log state is not copied
