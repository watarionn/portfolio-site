# Origin / clean rebuild notes

Date: 2026-09-25

## Legacy source

Primary reviewed source:

- `C:\Tools\ytdlp_desktop`

The legacy tool already contained a substantial Python/Go desktop downloader with:

- yt-dlp fallback profiles
- audio/video modes
- playlist scanning
- archive handling
- diagnostics
- optional video transcoding
- cookie refresh workflows
- browser profile
- Docker-based provider support

## Clean-rebuild decision

Download Workbench does not copy the legacy runtime state.

Excluded from the new repository:

- `data/cookies/`
- `data/browser_profile/`
- `data/downloads/`
- `data/logs/`
- `data/archive*.txt`
- provider/container state
- generated diagnostics containing historical URLs

The new product starts with an authorization-neutral core:

- analyze public/authorized URLs
- select formats
- download video/audio
- optionally clip a time range
- optionally save subtitles/metadata/thumbnail
- never bypass DRM or access controls

## Legacy ideas retained

- shell=False subprocess execution
- explicit no-overwrite behavior
- output-folder control
- ffmpeg awareness
- error-oriented diagnostics
- URL-list workflow

Legacy cookie/provider fallback behavior is intentionally not retained.
