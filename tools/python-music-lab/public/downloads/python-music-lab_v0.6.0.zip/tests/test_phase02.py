from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

from mido import MidiFile

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from python_music_lab.midi_writer import write_song  # noqa: E402
from python_music_lab.structured_composer import (  # noqa: E402
    compose_structured_song,
    load_structured_config,
    section_markers,
)


TRACK_SPECS = [
    ("Melody", 0, 0),
    ("Chords", 4, 1),
    ("Bass", 33, 2),
    ("Drums", 0, 9),
]


class Phase02Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_structured_config(PROJECT_ROOT / "config" / "phase02_song.json")

    def test_total_bars_and_markers(self) -> None:
        self.assertEqual(self.config.total_bars, 24)
        self.assertEqual(
            section_markers(self.config),
            [(0, "A"), (8 * self.config.bar_ticks, "B"), (16 * self.config.bar_ticks, "Chorus")],
        )

    def test_seed_is_deterministic(self) -> None:
        song_a, motif_a = compose_structured_song(self.config)
        song_b, motif_b = compose_structured_song(self.config)
        self.assertEqual(motif_a, motif_b)
        self.assertEqual(song_a, song_b)

    def test_chorus_register_is_higher_than_a(self) -> None:
        song, _ = compose_structured_song(self.config)
        melody = song["Melody"]
        a_end = 8 * self.config.bar_ticks
        chorus_start = 16 * self.config.bar_ticks
        a_notes = [event.note for event in melody if event.start < a_end]
        chorus_notes = [event.note for event in melody if event.start >= chorus_start]
        self.assertTrue(a_notes)
        self.assertTrue(chorus_notes)
        self.assertGreater(sum(chorus_notes) / len(chorus_notes), sum(a_notes) / len(a_notes))

    def test_midi_contains_section_markers(self) -> None:
        song, _ = compose_structured_song(self.config)
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "test.mid"
            write_song(
                output_path=path,
                bpm=self.config.bpm,
                ticks_per_beat=self.config.ticks_per_beat,
                tracks=[(name, song[name], program, channel) for name, program, channel in TRACK_SPECS],
                markers=section_markers(self.config),
            )
            midi = MidiFile(path)
            labels = [message.text for message in midi.tracks[0] if message.type == "marker"]
            self.assertEqual(labels, ["A", "B", "Chorus"])


if __name__ == "__main__":
    unittest.main()
