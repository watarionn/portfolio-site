from __future__ import annotations

import shutil
import subprocess
import sys
import tkinter
from pathlib import Path


MIN_PYTHON = (3, 10)
REQUIRED_FILES = (
    "app.py",
    "download.py",
    "download_workbench_core.py",
    "run_download_workbench.bat",
)


def first_line(command: list[str]) -> str | None:
    try:
        completed = subprocess.run(
            command,
            shell=False,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    lines = (completed.stdout or "").splitlines()
    return lines[0].strip() if lines else None


def main() -> int:
    failures: list[str] = []
    root_dir = Path(__file__).resolve().parent

    print("Download Workbench preflight")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Tkinter: {tkinter.TkVersion}")

    if sys.version_info < MIN_PYTHON:
        failures.append(
            f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer is required"
        )

    for relative in REQUIRED_FILES:
        if not (root_dir / relative).is_file():
            failures.append(f"required file missing: {relative}")

    try:
        root = tkinter.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
        print("Tk GUI: available")
    except tkinter.TclError as exc:
        failures.append(f"Tk GUI unavailable: {exc}")

    ytdlp = shutil.which("yt-dlp")
    ffmpeg = shutil.which("ffmpeg")

    if ytdlp:
        print(f"yt-dlp: {first_line([ytdlp, '--version']) or ytdlp}")
    else:
        failures.append("yt-dlp was not found on PATH")

    if ffmpeg:
        version = first_line([ffmpeg, "-version"])
        print(f"ffmpeg: {version or ffmpeg}")
    else:
        failures.append("ffmpeg was not found on PATH")

    if failures:
        print("\nPreflight FAILED")
        for item in failures:
            print(f"- {item}")
        return 1

    print("\nPreflight PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
