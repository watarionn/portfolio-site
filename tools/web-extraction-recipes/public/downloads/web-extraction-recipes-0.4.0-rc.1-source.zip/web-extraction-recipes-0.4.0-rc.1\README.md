# Web Extraction Recipes

HTMLから必要な情報を取り出す規則をJSON Recipeとして保存し、別のHTMLや公開ページにも再利用できるWindows向け抽出ツールです。

旧スクリプトの「サイトごとにコードを書き換える」方式から、抽出規則と取得ポリシーを分離した再利用可能なWorkbenchへ作り直しています。

## Current status

Phase 4 Release Candidateを検証中です。

- Phase 1: オフライン抽出コア
- Phase 2: Windows GUI
- Phase 3: HTTP Collection + List → Detail Crawl
- Phase 4: Release Candidate / 配布検証

## Offline extraction

ローカルHTMLにJSON Recipeを適用し、TSV / CSV / JSONへ出力できます。

対応する主なセレクタ:

- tag
- .class
- #id
- [attr]
- [attr=value]
- [attr*=value]
- [attr~=token]
- 子孫セレクタ

Fieldでは次を指定できます。

- text抽出
- attribute抽出
- 相対URLの絶対URL化
- regex capture group
- 欠損時default

CLI:

    py -3 extract.py input.html recipes/generic_cards.json -o output.tsv

## Windows GUI

    run_web_extraction_recipes.bat

または:

    py -3 app.py

GUIではローカルHTMLとRecipe JSONを選び、レシピ編集・検証、抽出Preview、TSV / CSV / JSON保存まで行えます。

入力HTMLやレシピを変更すると古いPreviewは自動で無効化されます。

## Phase 3: HTTP Crawl

一覧ページからdetail URLを見つけ、各detail HTMLへ既存のExtraction Recipeを適用する二段巡回に対応しています。

CLI:

    py -3 crawl.py urls.txt recipes/generic_crawl.json -o result.tsv

Crawl Recipeでは次を設定できます。

- list page内のdetail link selector
- detail page用のExtraction Recipe
- delay_seconds
- timeout_seconds
- max_retries
- max_pages
- same_origin
- respect_robots
- allow_private_hosts
- User-Agent

既定値:

- robots.txtを尊重
- same-originのみ
- 1秒間隔
- retry 2回
- 最大100ページ
- localhost / private / link-localネットワークはブロック
- HTML / XHTMLのみ
- 1レスポンス最大4 MiB

localhostやLAN上の開発用ページを明示的に取得したい場合だけ、Crawl Recipeで:

    "allow_private_hosts": true

を指定します。

GUIのHTTP CrawlタブでもStart URLsとCrawl Recipeを編集できます。HTTP Crawlボタンは「HTTP取得の権限・許可があります」にチェックした場合だけ有効です。

## HTTP safety boundary

ネットワーク取得では以下を行いません。

- Cookieの付与
- Authorizationヘッダーの付与
- ブラウザプロファイルの読み込み
- ログイン処理
- CAPTCHA回避
- paywall回避
- access-control回避

URLに埋め込まれたusername/passwordも拒否します。

robots.txt取得が404 / 410の場合は「robotsなし」として扱います。それ以外のrobots取得失敗は安全側に倒してcrawlを許可しません。

## Origin

明示検索した旧資産:

- extract_dmm_tsv.R
- crawl_shabulism_cid.R

新作ではサイト固有のselectorやURLはruntimeへ持ち込まず、再利用できる抽出パターンだけを汎用化しています。

詳細は `docs/ORIGIN.md` を参照してください。

## Release Candidate verification

Version is stored in `VERSION`.

Run the full preflight:

    powershell -ExecutionPolicy Bypass -File tools/preflight.ps1

Build the source ZIP and SHA-256 file:

    powershell -ExecutionPolicy Bypass -File tools/build_release.ps1

Release artifacts are written under `dist/`. The source ZIP is verified again after extraction before publication.
