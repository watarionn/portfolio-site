from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from mido import Message, MetaMessage, MidiFile, MidiTrack, bpm2tempo


@dataclass(frozen=True)
class NoteEvent:
    start: int
    duration: int
    note: int
    velocity: int
    channel: int = 0


def _note_messages(events: Iterable[NoteEvent]) -> list[tuple[int, int, Message]]:
    messages: list[tuple[int, int, Message]] = []
    for event in events:
        messages.append(
            (
                event.start,
                1,
                Message(
                    "note_on",
                    note=event.note,
                    velocity=event.velocity,
                    channel=event.channel,
                    time=0,
                ),
            )
        )
        messages.append(
            (
                event.start + event.duration,
                0,
                Message(
                    "note_off",
                    note=event.note,
                    velocity=0,
                    channel=event.channel,
                    time=0,
                ),
            )
        )

    # At the same tick, note_off comes before note_on.
    messages.sort(key=lambda x: (x[0], x[1]))
    return messages


def _append_absolute_messages(track: MidiTrack, messages: list[tuple[int, int, Message]]) -> None:
    previous_tick = 0
    for absolute_tick, _, message in messages:
        message.time = absolute_tick - previous_tick
        track.append(message)
        previous_tick = absolute_tick


def add_instrument_track(
    midi: MidiFile,
    name: str,
    events: list[NoteEvent],
    program: int,
    channel: int,
) -> None:
    track = MidiTrack()
    midi.tracks.append(track)
    track.append(MetaMessage("track_name", name=name, time=0))

    if channel != 9:
        track.append(Message("program_change", program=program, channel=channel, time=0))

    _append_absolute_messages(track, _note_messages(events))
    track.append(MetaMessage("end_of_track", time=0))


def write_song(
    output_path: Path,
    bpm: int,
    ticks_per_beat: int,
    tracks: list[tuple[str, list[NoteEvent], int, int]],
    markers: list[tuple[int, str]] | None = None,
) -> None:
    midi = MidiFile(type=1, ticks_per_beat=ticks_per_beat)

    conductor = MidiTrack()
    midi.tracks.append(conductor)
    conductor.append(MetaMessage("track_name", name="Conductor", time=0))
    conductor.append(MetaMessage("time_signature", numerator=4, denominator=4, time=0))
    conductor.append(MetaMessage("set_tempo", tempo=bpm2tempo(bpm), time=0))

    previous_tick = 0
    for absolute_tick, label in sorted(markers or [], key=lambda item: item[0]):
        conductor.append(MetaMessage("marker", text=label, time=absolute_tick - previous_tick))
        previous_tick = absolute_tick
    conductor.append(MetaMessage("end_of_track", time=0))

    for name, events, program, channel in tracks:
        add_instrument_track(midi, name, events, program, channel)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    midi.save(output_path)
