from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from project_snapshot_core import (
    SnapshotError,
    default_output_path,
    render_markdown,
    scan_project,
    write_snapshot,
)


class ProjectSnapshotTests(unittest.TestCase):
    def make_project(self) -> tuple[tempfile.TemporaryDirectory, Path]:
        temp = tempfile.TemporaryDirectory()
        root = Path(temp.name) / "demo project"
        (root / "src").mkdir(parents=True)
        (root / "build").mkdir()
        (root / "node_modules" / "pkg").mkdir(parents=True)
        (root / "src" / "main.py").write_text("print('ok')\n", encoding="utf-8")
        (root / "README.md").write_text("# Demo\n", encoding="utf-8")
        (root / "build" / "bundle.js").write_text("x" * 32, encoding="utf-8")
        (root / "node_modules" / "pkg" / "index.js").write_text("ignored", encoding="utf-8")
        return temp, root

    def test_scan_counts_files_and_skips_common_dependency_dirs(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        snap = scan_project(root)
        self.assertEqual(snap.total_files, 3)
        self.assertEqual(snap.total_dirs, 2)
        self.assertTrue(any("node_modules/" in item for item in snap.skipped_paths))

    def test_extension_breakdown(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        snap = scan_project(root)
        self.assertEqual(snap.extensions[".py"], 1)
        self.assertEqual(snap.extensions[".md"], 1)
        self.assertEqual(snap.extensions[".js"], 1)

    def test_gitignore_candidate_detects_generated_build_dir(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        snap = scan_project(root)
        self.assertIn("build", snap.gitignore_candidates)

    def test_existing_literal_gitignore_suppresses_candidate(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        (root / ".gitignore").write_text("build/\n", encoding="utf-8")
        snap = scan_project(root)
        self.assertNotIn("build", snap.gitignore_candidates)

    def test_large_file_detection(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        snap = scan_project(root, large_file_threshold=16)
        paths = [item.relative_path for item in snap.largest_files]
        self.assertIn("build/bundle.js", paths)

    def test_markdown_contains_analysis_sections(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        text = render_markdown(scan_project(root))
        self.assertIn("## Tree", text)
        self.assertIn("## Extension breakdown", text)
        self.assertIn("## Large files", text)
        self.assertIn("## Git ignore candidates", text)

    def test_write_refuses_overwrite_by_default(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        output = Path(temp.name) / "snapshot.md"
        write_snapshot(root, output=output)
        with self.assertRaises(FileExistsError):
            write_snapshot(root, output=output)

    def test_folders_only_hides_file_lines_but_keeps_analysis(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        snap = scan_project(root, include_files_in_tree=False)
        text = render_markdown(snap, include_files_in_tree=False)
        tree = text.split("## Extension breakdown", 1)[0]
        self.assertNotIn("main.py", tree)
        self.assertIn(".py", text)

    def test_default_output_is_next_to_project(self) -> None:
        temp, root = self.make_project()
        self.addCleanup(temp.cleanup)
        self.assertEqual(
            default_output_path(root),
            root.parent / "snapshot_demo project.md",
        )

    def test_missing_project_is_rejected(self) -> None:
        with self.assertRaises(SnapshotError):
            scan_project(Path("Z:/definitely/not/here"))


if __name__ == "__main__":
    unittest.main()
