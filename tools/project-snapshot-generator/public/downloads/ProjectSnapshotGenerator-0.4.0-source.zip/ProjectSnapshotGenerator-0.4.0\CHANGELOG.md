# Changelog

## 0.4.0 - 2026-09-24

Initial release candidate of Project Snapshot Generator.

### Added

- rebuilt single-pass successor to the legacy DirTreeMaker.bat
- Windows Tkinter GUI and command-line interface
- Markdown project tree export
- project file/folder/size summary
- extension breakdown with percentage share
- large-file detection with configurable threshold
- common Git ignore candidate detection
- skipped-path and scan-issue reporting
- safe default exclusions for Git metadata, dependency folders, virtual environments and caches
- symbolic links are not followed
- explicit overwrite confirmation
- background-thread scanning in the GUI
- automatic Full / Compact tree selection based on project size
- read-only Markdown preview with one-click copy
- keyboard shortcuts for open, re-scan, save and copy
- real-repository QA against video-workbench, portfolio-site and ai-memory-vault
- reproducible source release packaging
