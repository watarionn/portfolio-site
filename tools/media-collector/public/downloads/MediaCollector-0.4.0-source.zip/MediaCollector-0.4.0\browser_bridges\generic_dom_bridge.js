(() => {
  "use strict";
  const MEDIA_EXT = /\.(?:jpe?g|png|webp|gif|avif|mp4|webm|mov|m4v)(?:$|[?#])/i;
  const found = new Set();
  const add = (raw) => {
    if (!raw) return;
    try {
      const url = new URL(raw, location.href);
      if (!/^https?:$/.test(url.protocol) || !MEDIA_EXT.test(url.href)) return;
      url.hash = "";
      found.add(url.href);
    } catch (_) {}
  };
  for (const image of document.querySelectorAll("img")) {
    add(image.currentSrc); add(image.src); add(image.getAttribute("src"));
    const srcset = image.getAttribute("srcset") || "";
    for (const part of srcset.split(",")) add(part.trim().split(/\s+/)[0]);
  }
  for (const video of document.querySelectorAll("video")) {
    add(video.currentSrc); add(video.src); add(video.getAttribute("src"));
  }
  for (const source of document.querySelectorAll("source")) {
    add(source.src); add(source.getAttribute("src"));
    const srcset = source.getAttribute("srcset") || "";
    for (const part of srcset.split(",")) add(part.trim().split(/\s+/)[0]);
  }
  for (const anchor of document.querySelectorAll("a[href]")) add(anchor.href);
  const urls = [...found].sort();
  const text = urls.join("\n") + (urls.length ? "\n" : "");
  console.log("[Media Collector / DOM] " + urls.length + " media URL(s)");
  console.log(text);
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).catch(() => {});
  }
  return urls;
})();
