# Phase 1 QA

Date: 2026-09-24

## Goal

Replace the legacy DirTreeMaker traversal with a safe single-pass project scanner and a reproducible Markdown report.

## Safety and behavior decisions

- no third-party dependencies
- no file modification inside the scanned project
- no symbolic-link following
- common dependency/cache directories excluded by default
- skipped paths and read errors are reported instead of silently treated as success
- output overwrite requires an explicit flag
- Markdown export defaults next to the selected project, not inside it

## Analysis surface

- structure tree
- file/folder totals
- extension counts
- large files
- Git ignore candidates
- skipped paths
- scan issues

## Automated QA

- Python compile: PASS
- unit tests: 10 / 10 PASS

## Real-project smoke

Target: local video-workbench repository

- elapsed: 114 ms
- files: 35
- directories: 6
- skipped paths: 3
- scan issues: 0
- Markdown export: PASS
- extension breakdown: PASS
- existing .gitignore suppression for dist: PASS

The generated smoke artifact lives under test-output and is excluded from Git.
