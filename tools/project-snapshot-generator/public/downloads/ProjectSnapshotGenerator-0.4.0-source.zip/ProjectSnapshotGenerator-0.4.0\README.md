# Project Snapshot Generator

Project Snapshot Generator turns a project folder into a compact Markdown snapshot for review, handoff and cleanup.

It is a rebuilt successor to the old DirTreeMaker.bat. The original tool only emitted a folder tree with counts and sizes. This version scans the project once and adds project-level analysis.

## Phase 1 features

- folder/file tree in Markdown
- aggregate file and directory counts
- total project size
- extension breakdown
- large-file detection
- common Git ignore candidates
- skipped-path reporting
- scan-error reporting
- safe default exclusions for .git, node_modules, virtual environments and caches
- symbolic links are not followed
- existing output is never overwritten unless explicitly requested

## CLI

Basic:

    py -3 snapshot.py "C:\Work\Project"

Folders-only tree:

    py -3 snapshot.py "C:\Work\Project" --folders-only

Explicit output and overwrite:

    py -3 snapshot.py "C:\Work\Project" -o ".\project-snapshot.md" --overwrite

No third-party Python packages are required.

## Tests

    py -3 -m unittest discover -s tests -v

## GUI

Windowsでは次をダブルクリックします。

    run_project_snapshot.bat

または:

    py -3 app.py

GUIではプロジェクトフォルダを選択して解析すると、Markdown Preview、拡張子集計、巨大ファイル、Git除外候補、スキップ項目、走査エラーを確認できます。

Markdown Previewの「ファイルも表示」は再走査なしで切り替えられます。保存も解析済みSnapshotから行うため、プレビューと保存内容が同じ解析結果を参照します。

## Phase 3 usability

大きなリポジトリでは、個別ファイル行を省いたCompact treeを自動選択します。500ファイル未満ではFull tree、500ファイル以上ではCompact treeが初期表示です。どちらもチェックボックスで切り替えられます。

拡張子一覧にはファイル数と構成比を表示します。巨大ファイル判定のしきい値を変更した場合は、再解析が必要であることをステータス欄に表示します。

ショートカット:

- Ctrl+O: プロジェクト選択
- F5: 再解析
- Ctrl+S: Markdown保存
- Ctrl+Shift+C: Preview全体をコピー

## Environment check

起動前チェックだけ行う場合:

    py -3 preflight.py

run_project_snapshot.bat から起動した場合も同じチェックを先に実行します。

必要環境:

- Windows
- Python 3.10以上
- Tkinter

追加のPythonパッケージは不要です。

## Distribution

ソースリリースを再生成する場合:

    powershell -ExecutionPolicy Bypass -File .\build_release.ps1 -Version 0.4.0

生成物:

    dist\ProjectSnapshotGenerator-0.4.0-source.zip

dist はGit管理対象外です。

## Current scope

Current release candidate: 0.4.0

Phase 4では再現可能なソース配布、preflight、GitHub Releaseまでを正式な配布経路として扱います。
