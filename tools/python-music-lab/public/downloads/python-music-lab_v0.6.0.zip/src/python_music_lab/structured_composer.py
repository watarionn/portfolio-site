from __future__ import annotations

import json
import random
from dataclasses import dataclass
from pathlib import Path

from .midi_writer import NoteEvent
from .music_theory import diatonic_triad, normalize_mode, scale_midi, supported_degrees


RHYTHM_STYLES = {"sparse", "flowing", "driving"}
CADENCES = {"none", "half", "authentic"}


@dataclass(frozen=True)
class SectionSpec:
    name: str
    bars: int
    progression: list[str]
    melody_density: float
    register_shift: int
    energy: float
    rhythm_style: str = "flowing"
    non_chord_tone_rate: float = 0.18
    cadence: str = "none"


@dataclass(frozen=True)
class StructuredSongConfig:
    title: str
    bpm: int
    key_root: str
    mode: str
    seed: int
    ticks_per_beat: int
    sections: list[SectionSpec]
    candidate_count: int = 1

    @property
    def bar_ticks(self) -> int:
        return self.ticks_per_beat * 4

    @property
    def total_bars(self) -> int:
        return sum(section.bars for section in self.sections)


@dataclass(frozen=True)
class MotifStep:
    scale_offset: int | None
    duration_steps: int = 1


def load_structured_config(path: Path) -> StructuredSongConfig:
    data = json.loads(path.read_text(encoding="utf-8"))
    mode = normalize_mode(str(data["mode"]))

    sections = [SectionSpec(**section) for section in data["sections"]]
    if not sections:
        raise ValueError("At least one section is required.")

    valid_degrees = supported_degrees(mode)
    for section in sections:
        if section.bars <= 0:
            raise ValueError(f"Section {section.name}: bars must be greater than 0.")
        if not section.progression:
            raise ValueError(f"Section {section.name}: progression must not be empty.")
        if not 0.0 <= section.melody_density <= 1.0:
            raise ValueError(f"Section {section.name}: melody_density must be 0..1.")
        if not 0.0 <= section.energy <= 1.0:
            raise ValueError(f"Section {section.name}: energy must be 0..1.")
        if section.rhythm_style not in RHYTHM_STYLES:
            raise ValueError(f"Section {section.name}: unsupported rhythm_style {section.rhythm_style!r}.")
        if not 0.0 <= section.non_chord_tone_rate <= 1.0:
            raise ValueError(f"Section {section.name}: non_chord_tone_rate must be 0..1.")
        if section.cadence not in CADENCES:
            raise ValueError(f"Section {section.name}: unsupported cadence {section.cadence!r}.")
        for degree in section.progression:
            if degree not in valid_degrees:
                raise ValueError(
                    f"Section {section.name}: unsupported chord degree {degree!r} for {mode}."
                )

    return StructuredSongConfig(
        title=str(data["title"]),
        bpm=int(data["bpm"]),
        key_root=str(data["key_root"]),
        mode=mode,
        seed=int(data["seed"]),
        ticks_per_beat=int(data.get("ticks_per_beat", 480)),
        sections=sections,
        candidate_count=max(1, int(data.get("candidate_count", 1))),
    )


def generate_base_motif(config: StructuredSongConfig) -> list[MotifStep]:
    """Create a one-bar motif on an eighth-note grid."""
    rng = random.Random(config.seed)
    contour = [0]
    for _ in range(7):
        move = rng.choices([-2, -1, 0, 1, 2], weights=[1, 4, 2, 4, 1], k=1)[0]
        contour.append(max(-4, min(5, contour[-1] + move)))

    motif: list[MotifStep] = []
    for step, offset in enumerate(contour):
        if step not in (0, 4) and rng.random() < 0.18:
            motif.append(MotifStep(None, 1))
            continue
        duration = 2 if step in (2, 6) and rng.random() < 0.40 else 1
        motif.append(MotifStep(offset, duration))
    return motif


def section_degree(config: StructuredSongConfig, section: SectionSpec, local_bar: int) -> str:
    """Resolve the harmony for one bar, applying the section cadence grammar."""
    tonic = "I" if config.mode == "major" else "i"
    dominant = "V"

    if section.cadence == "authentic" and section.bars >= 2:
        if local_bar == section.bars - 2:
            return dominant
        if local_bar == section.bars - 1:
            return tonic
    if section.cadence == "half" and local_bar == section.bars - 1:
        return dominant
    return section.progression[local_bar % len(section.progression)]


def section_chord(
    config: StructuredSongConfig,
    section: SectionSpec,
    local_bar: int,
    octave: int = 4,
) -> list[int]:
    degree = section_degree(config, section, local_bar)
    return diatonic_triad(config.key_root, degree, octave, mode=config.mode)


def chord_for_global_bar(config: StructuredSongConfig, global_bar: int, octave: int = 4) -> list[int]:
    cursor = 0
    for section in config.sections:
        if cursor <= global_bar < cursor + section.bars:
            return section_chord(config, section, global_bar - cursor, octave)
        cursor += section.bars
    raise IndexError(f"Bar out of range: {global_bar}")


def _nearest_scale_note(scale: list[int], target: int) -> int:
    return min(scale, key=lambda n: abs(n - target))


def _non_chord_neighbor(scale: list[int], note: int, chord: list[int], rng: random.Random) -> int:
    chord_pcs = {value % 12 for value in chord}
    candidates = [
        value for value in scale
        if value % 12 not in chord_pcs and 0 < abs(value - note) <= 4
    ]
    if not candidates:
        return note
    nearest_distance = min(abs(value - note) for value in candidates)
    nearest = [value for value in candidates if abs(value - note) == nearest_distance]
    return rng.choice(nearest)


def _cadence_target(config: StructuredSongConfig, section: SectionSpec, scale: list[int]) -> int | None:
    if section.cadence == "authentic":
        return scale[0]
    if section.cadence == "half":
        return scale[4]
    return None


def _keep_rhythm_position(section: SectionSpec, step: int, rng: random.Random) -> bool:
    if step in (0, 4):
        return True
    density = section.melody_density
    if section.rhythm_style == "sparse":
        density *= 0.74 if step % 2 else 0.88
    elif section.rhythm_style == "driving":
        density = min(1.0, density + (0.12 if step % 2 else 0.06))
    return rng.random() <= density


def _duration_steps(section: SectionSpec, motif_step: MotifStep, step: int, rng: random.Random) -> int:
    if section.rhythm_style == "driving":
        return 1
    if section.rhythm_style == "sparse" and step not in (0, 4) and rng.random() < 0.35:
        return min(2, motif_step.duration_steps + 1)
    return motif_step.duration_steps


def _render_motif_bar(
    config: StructuredSongConfig,
    section: SectionSpec,
    motif: list[MotifStep],
    global_bar: int,
    local_bar: int,
    rng: random.Random,
) -> list[NoteEvent]:
    eighth = config.ticks_per_beat // 2
    base_tick = global_bar * config.bar_ticks
    scale = scale_midi(config.key_root, config.mode, octave=4)
    scale_ext = [n - 12 for n in scale] + scale + [n + 12 for n in scale] + [n + 24 for n in scale]
    chord = section_chord(config, section, local_bar, octave=4)
    chord_ext = chord + [n + 12 for n in chord]

    events: list[NoteEvent] = []
    section_name = section.name.lower()
    for step, motif_step in enumerate(motif):
        if motif_step.scale_offset is None:
            continue
        if not _keep_rhythm_position(section, step, rng):
            continue

        offset = motif_step.scale_offset
        if "b" in section_name or "pre" in section_name:
            offset += (local_bar % 4) // 2
        elif "chorus" in section_name or "サビ" in section_name:
            offset = int(round(offset * 1.35)) + 2

        target = scale[3] + offset * 2 + section.register_shift
        note = _nearest_scale_note(scale_ext, target)

        # Strong beats anchor the current harmony.
        if step in (0, 4):
            note = min(chord_ext, key=lambda n: abs(n - note))
        elif rng.random() < section.non_chord_tone_rate:
            note = _non_chord_neighbor(scale_ext, note, chord_ext, rng)

        # Apply local phrase resolution every fourth bar, then explicit section cadence.
        if local_bar % 4 == 3 and step >= 6:
            tonic_candidates = [n for n in (scale[0], scale[0] + 12, scale[0] + 24) if 52 <= n <= 91]
            note = min(tonic_candidates, key=lambda n: abs(n - note))
        if local_bar == section.bars - 1 and step >= 6:
            cadence_target = _cadence_target(config, section, scale)
            if cadence_target is not None:
                targets = [n for n in (cadence_target, cadence_target + 12, cadence_target + 24) if 52 <= n <= 91]
                note = min(targets, key=lambda n: abs(n - note))

        note = max(52, min(91, note))
        duration_steps = _duration_steps(section, motif_step, step, rng)
        if step + duration_steps > 8:
            duration_steps = 8 - step
        velocity = int(70 + 28 * section.energy + rng.randint(-5, 5))
        velocity = max(45, min(118, velocity))

        if events and base_tick + step * eighth < events[-1].start + events[-1].duration:
            continue

        events.append(
            NoteEvent(
                start=base_tick + step * eighth,
                duration=max(eighth, duration_steps * eighth),
                note=note,
                velocity=velocity,
                channel=0,
            )
        )

    if not events:
        root_candidates = [section_chord(config, section, local_bar, octave=4)[0] + 12 * shift for shift in (-1, 0, 1, 2)]
        register_target = scale[3] + section.register_shift
        root = min(root_candidates, key=lambda n: abs(n - register_target))
        events.append(NoteEvent(base_tick, config.ticks_per_beat, root, 82, channel=0))

    # The actual last sounding note of a cadential section must land on the
    # requested target even when the motif ends with a rest or overlapping note.
    if local_bar == section.bars - 1 and section.cadence != "none":
        cadence_target = _cadence_target(config, section, scale)
        if cadence_target is not None:
            targets = [n for n in (cadence_target, cadence_target + 12, cadence_target + 24) if 52 <= n <= 91]
            last = max(events, key=lambda event: event.start)
            target_note = min(targets, key=lambda n: abs(n - last.note))
            target_note = max(52, min(91, target_note))
            index = events.index(last)
            events[index] = NoteEvent(last.start, last.duration, target_note, last.velocity, last.channel)
    return events


def compose_structured_melody(config: StructuredSongConfig, motif: list[MotifStep]) -> list[NoteEvent]:
    rng = random.Random(config.seed + 101)
    events: list[NoteEvent] = []
    global_bar = 0
    for section in config.sections:
        for local_bar in range(section.bars):
            events.extend(_render_motif_bar(config, section, motif, global_bar, local_bar, rng))
            global_bar += 1
    return events


def compose_structured_chords(config: StructuredSongConfig) -> list[NoteEvent]:
    events: list[NoteEvent] = []
    global_bar = 0
    for section in config.sections:
        for local_bar in range(section.bars):
            chord = section_chord(config, section, local_bar, octave=4)
            velocity = int(52 + 25 * section.energy)
            for note in chord:
                events.append(NoteEvent(global_bar * config.bar_ticks, config.bar_ticks, note, velocity, channel=1))
            global_bar += 1
    return events


def _next_section(config: StructuredSongConfig, section_index: int) -> SectionSpec | None:
    if section_index + 1 >= len(config.sections):
        return None
    return config.sections[section_index + 1]


def compose_structured_bass(config: StructuredSongConfig) -> list[NoteEvent]:
    events: list[NoteEvent] = []
    beat = config.ticks_per_beat
    global_bar = 0
    for section_index, section in enumerate(config.sections):
        next_section = _next_section(config, section_index)
        for local_bar in range(section.bars):
            chord = section_chord(config, section, local_bar, octave=3)
            root = chord[0] - 12
            fifth = chord[2] - 12
            base = global_bar * config.bar_ticks
            notes = [root, root + 12, fifth, root + 12]
            if section.energy >= 0.85:
                notes[1] = fifth

            # Chromatic approach into a more energetic next section.
            if (
                local_bar == section.bars - 1
                and next_section is not None
                and next_section.energy > section.energy
            ):
                next_root = section_chord(config, next_section, 0, octave=3)[0] - 12
                notes[3] = next_root - 1

            for beat_index, note in enumerate(notes):
                velocity = int(68 + 24 * section.energy + (6 if beat_index in (0, 2) else 0))
                events.append(NoteEvent(base + beat_index * beat, beat, note, velocity, channel=2))
            global_bar += 1
    return events


def compose_structured_drums(config: StructuredSongConfig) -> list[NoteEvent]:
    events: list[NoteEvent] = []
    eighth = config.ticks_per_beat // 2
    beat = config.ticks_per_beat
    global_bar = 0

    for section_index, section in enumerate(config.sections):
        next_section = _next_section(config, section_index)
        for local_bar in range(section.bars):
            base = global_bar * config.bar_ticks
            if local_bar == 0 and section.energy >= 0.78:
                events.append(NoteEvent(base, beat, 49, 108, channel=9))

            for step in range(8):
                hat_note = 46 if section.energy >= 0.90 and step == 7 else 42
                velocity = int(42 + 30 * section.energy + (5 if step % 2 == 0 else 0))
                events.append(NoteEvent(base + step * eighth, eighth // 2, hat_note, velocity, channel=9))

            kicks = [0, 2]
            if section.energy >= 0.75:
                kicks.append(3)
            if section.energy >= 0.90:
                events.append(NoteEvent(base + 3 * eighth, eighth // 2, 36, 86, channel=9))
            for beat_index in kicks:
                events.append(NoteEvent(base + beat_index * beat, beat // 2, 36, 96, channel=9))
            for beat_index in (1, 3):
                events.append(NoteEvent(base + beat_index * beat, beat // 2, 38, 92, channel=9))

            # Small tom fill when energy rises into the next section.
            if (
                local_bar == section.bars - 1
                and next_section is not None
                and next_section.energy > section.energy
            ):
                for fill_step, drum_note in zip((5, 6, 7), (45, 47, 50)):
                    events.append(NoteEvent(base + fill_step * eighth, eighth // 2, drum_note, 88 + fill_step, channel=9))

            global_bar += 1
    return events


def section_markers(config: StructuredSongConfig) -> list[tuple[int, str]]:
    markers: list[tuple[int, str]] = []
    global_bar = 0
    for section in config.sections:
        markers.append((global_bar * config.bar_ticks, section.name))
        global_bar += section.bars
    return markers


def compose_structured_song(config: StructuredSongConfig) -> tuple[dict[str, list[NoteEvent]], list[MotifStep]]:
    motif = generate_base_motif(config)
    song = {
        "Melody": compose_structured_melody(config, motif),
        "Chords": compose_structured_chords(config),
        "Bass": compose_structured_bass(config),
        "Drums": compose_structured_drums(config),
    }
    return song, motif
