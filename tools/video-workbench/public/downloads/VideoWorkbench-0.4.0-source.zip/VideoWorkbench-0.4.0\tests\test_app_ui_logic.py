from __future__ import annotations

import tkinter as tk
import unittest
from pathlib import Path

from app import VideoWorkbenchApp, attach_footer, configure_style
from video_workbench_core import MediaInfo


class AppUiLogicTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = tk.Tk()
        self.root.withdraw()
        configure_style(self.root)
        self.app = VideoWorkbenchApp(self.root)
        attach_footer(self.app)
        self.app.current_media = MediaInfo(
            path=Path(r"C:\\tmp\\sample.mp4"),
            duration=125.5,
            width=1920,
            height=1080,
            fps=30.0,
            video_streams=1,
            audio_streams=1,
            size_bytes=1000,
        )

    def tearDown(self) -> None:
        self.root.destroy()

    def test_live_trim_summary(self) -> None:
        self.app.trim_start.set("10")
        self.app.trim_end.set("20.5")
        self.app._refresh_summaries()
        self.assertIn("00:10.500", self.app.trim_summary_var.get())

    def test_frame_estimate(self) -> None:
        self.app.frame_mode.set("fps")
        self.app.frame_fps.set("2")
        self.app._refresh_summaries()
        self.assertIn("251", self.app.frame_summary_var.get())

    def test_contextual_control_states(self) -> None:
        self.app.frame_format.set("png")
        self.app.frame_mode.set("all")
        self.app._sync_frame_mode()
        self.assertEqual(str(self.app.frame_quality_spin.cget("state")), "disabled")
        self.assertEqual(str(self.app.frame_fps_entry.cget("state")), "disabled")


if __name__ == "__main__":
    unittest.main()
