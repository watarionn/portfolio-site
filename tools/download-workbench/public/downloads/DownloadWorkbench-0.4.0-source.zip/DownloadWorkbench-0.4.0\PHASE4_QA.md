# Phase 4 QA

Date: 2026-09-25
Version: 0.4.0 Release Candidate

## Goal

Close the release and distribution boundary for Download Workbench.

## Preflight

preflight.py validates:

- Python 3.10+
- Tkinter GUI availability
- required source files
- yt-dlp on PATH
- ffmpeg on PATH

## Runtime safety boundary

- Analyze does not download media.
- Download requires explicit rights/permission confirmation in the GUI.
- yt-dlp is always invoked with --ignore-config.
- no-overwrite remains enabled.
- embedded URL credentials are rejected.
- token/signature-like query values are redacted in Command Preview.
- no Cookie / Authorization / browser-profile controls exist.
- no DRM or access-control bypass logic exists.

## Real integration coverage

The Phase 3 integration test uses a generated local MP4 and a byte-range-capable localhost HTTP server.

It verifies the real installed yt-dlp / ffmpeg / ffprobe path for:

- Analyze
- Video
- Audio extraction
- explicit Format ID
- precise range clip
- output duration
- output stream types

No external website or authenticated account is used.

## Automated QA

- Python: 3.14.5
- Tkinter: 8.6
- yt-dlp: 2026.03.17
- ffmpeg: 2026-06-04 git build
- preflight: PASS
- Python compile: PASS
- Phase 1-3 tests: 28 / 28 PASS
- tests also pass with ResourceWarning promoted to error
- real yt-dlp/ffmpeg localhost integration: PASS
- screenshot Pillow verification: PASS
- repository secret scan: PASS
- authentication-argument scan: PASS
- git diff check: PASS

## Visual QA

- real application screenshot: `qa/screenshots/phase4-main.png`
- direct target-window PrintWindow capture
- screenshot size: 1256 x 879
- no taskbar or overlapping application window
- formats, range settings, Thumbnail option, tool versions and rights gate are visible

## Distribution

- run_download_workbench.bat runs preflight before opening the GUI
- build_release.ps1 creates a source ZIP
- package includes source, tests, QA documents and real application screenshots
- runtime Python dependencies are standard library only
- yt-dlp and ffmpeg are external prerequisites

## Extracted-package verification

The generated source ZIP was expanded into a separate temporary directory and tested from there.

- package preflight: PASS
- package unit/integration tests: 28 / 28 PASS
- real yt-dlp / ffmpeg localhost integration from extracted package: PASS
- package file count: 26

This verifies that the release package does not depend on unlisted files in the development working tree.
