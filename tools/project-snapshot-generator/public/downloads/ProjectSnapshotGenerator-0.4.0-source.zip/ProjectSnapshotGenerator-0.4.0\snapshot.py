from __future__ import annotations

import argparse

from project_snapshot_core import SnapshotError, write_snapshot


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate a Markdown project-structure snapshot."
    )
    parser.add_argument("project", help="Project folder to inspect")
    parser.add_argument("-o", "--output", help="Markdown output path")
    parser.add_argument(
        "--folders-only",
        action="store_true",
        help="Hide individual files from the tree while keeping aggregate analysis.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow replacing an existing output file.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        path, snapshot = write_snapshot(
            args.project,
            output=args.output,
            include_files_in_tree=not args.folders_only,
            overwrite=args.overwrite,
        )
    except (SnapshotError, OSError, ValueError) as exc:
        print(f"ERROR: {exc}")
        return 1

    print(f"Output: {path}")
    print(f"Files: {snapshot.total_files:,}")
    print(f"Directories: {snapshot.total_dirs:,}")
    print(f"Skipped: {len(snapshot.skipped_paths):,}")
    print(f"Issues: {len(snapshot.issues):,}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
