# Portfolio Integration Plan

## Goal

Expose selected Python Music Lab experiments on Portfolio City without coupling the portfolio to the Python runtime.

## Export boundary

Python Music Lab generates static artifacts that a web frontend can consume:

- MIDI files during Phase 01/02
- `manifest.json` metadata catalogs
- WAV/OGG preview audio from Phase 03 onward
- optional piano-roll / waveform data and cover assets later

The portfolio reads exported artifacts rather than importing the composition engine itself.

## Phase 01.5 candidate contract

Each candidate folder contains:

- `candidate_01.mid` ...
- `manifest.json`

The manifest includes stable candidate IDs, Seed, BPM, key, bars, progression, duration, note counts, relative MIDI filename, and SHA-256.

## Phase 02 structured-song contract

`output/phase02/manifest.json` adds presentation data for a complete song experiment:

- A / B / Chorus section names
- section start bars and lengths
- chord progressions
- melody density
- register shift
- section energy
- generated motif data
- note counts
- duration
- MIDI SHA-256

The MIDI conductor track also contains section marker events. This makes it possible to keep DAW inspection and future browser visualization aligned to the same boundaries.

## Future Portfolio City presentation

Recommended presentation:

1. Project overview: `Python作曲研究所`
2. Experiment timeline by phase
3. Published piece card with title, BPM, key, Seed and generation method
4. A/B/Chorus timeline synchronized with playback
5. Browser audio player after WAV/OGG export is available
6. Optional piano-roll view highlighting motif reuse and variation
7. Candidate comparison view showing how changing only the Seed changes the result
8. Source/repository link if a public repository is later created

## Browser playback note

MIDI is useful as a research artifact but is not a dependable native browser playback format. Phase 03 should export WAV/OGG previews for the actual portfolio player while retaining MIDI for inspection and download.

## Important architectural rule

Do not require Python on the portfolio server for ordinary viewing. Generate/publish static output during the research workflow, then let the existing portfolio render those files.

## Phase 02B additions

Phase 02B exports transparent ranking data for a future Portfolio City exhibit. The site can show candidate cards with score breakdowns without running Python.

Recommended UI model:

```text
Python Music Lab
  candidate ranking
  -> score breakdown
  -> MIDI now / WAV or OGG from Phase 03
  -> A / B / Chorus timeline
  -> Seed / BPM / Key / cadence / rhythm style
```

The portfolio should label the score as an algorithmic heuristic, not a universal quality score. Human-selected favorites are stored separately in `selection.json`.

## Phase 03A audio contract

Phase 03Aでブラウザ再生用の最初の実音源が追加された。

`output/phase03a/`:

- `best_candidate.wav`
- `manifest.json`

manifestにはsource MIDI SHA-256、WAV SHA-256、BPM、section marker、sample rate、channels、duration、peak、RMS、track note countを保持する。

これによりPortfolio CityはPython runtimeなしで `<audio>` 相当のplayerを持てる。Phase 03Bでは同じ契約を拡張し、OGG previewを追加して転送サイズを下げる。

## Phase 03B browser audio contract

Phase 03Bで実展示用のaudio contractを追加した。

`output/phase03b/`:

- `best_candidate_master.wav`: lossless-ish master/fallback
- `best_candidate_preview.ogg`: lightweight preferred preview when ffmpeg is available
- `manifest.json`: synthesis / effect / render / hash詳細
- `portfolio_audio.json`: Portfolio Cityが直接読みやすい最小契約

`portfolio_audio.json`の`sources`はOGGを先頭、WAVをfallbackとして並べる。A / B / Chorus markerは`start_seconds`も持つため、ブラウザplayerのcurrentTimeとsection timelineを同期できる。

Portfolio City本番ではPython Synthを実行せず、公開時に生成済み静的成果物を配置する。
