from __future__ import annotations

import shutil
import subprocess
import sys
import tkinter


def version_line(command: str) -> str:
    result = subprocess.run(
        [command, "-version"],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=10,
    )
    if result.returncode != 0:
        raise RuntimeError(f"{command} -version failed")
    return (result.stdout or result.stderr).splitlines()[0]


def main() -> int:
    failures: list[str] = []
    print("Video Workbench preflight")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Tkinter: {tkinter.TkVersion}")

    for command in ("ffmpeg", "ffprobe"):
        path = shutil.which(command)
        if not path:
            failures.append(f"{command} was not found on PATH")
            continue
        try:
            print(f"{command}: {version_line(command)}")
        except Exception as exc:
            failures.append(f"{command}: {exc}")

    if failures:
        print("\nPreflight FAILED")
        for item in failures:
            print(f"- {item}")
        return 1

    print("\nPreflight PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
