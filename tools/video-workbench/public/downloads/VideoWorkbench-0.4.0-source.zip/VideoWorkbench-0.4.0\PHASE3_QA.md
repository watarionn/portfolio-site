# Phase 3 QA

Date: 2026-09-24

## Scope

Phase 3 improves usability without adding unrelated editing features.

- open the selected input video from the UI
- reset trim start to 0 seconds with one click
- set trim end to the detected video end with one click
- show the currently selected trim duration live
- explain Fast Cut and Precise Cut in the trim panel
- provide common FPS values while still allowing custom FPS input
- estimate the number of frames before export
- disable JPG quality when PNG is selected
- disable FPS input when exporting every frame
- clear stale metadata when the input path changes

## Regression QA

- Python compile: PASS
- unit tests: 12 / 12 PASS
- Tkinter UI construction: PASS
- window size: 1120 x 760
- live trim summary: PASS
- live frame-count estimate: PASS
- PNG JPG-quality disabled state: PASS
- JPG JPG-quality enabled state: PASS
- all-frame FPS disabled state: PASS

## Real FFmpeg smoke

Synthetic 4-second H.264/AAC input with Japanese characters and spaces in the path:

- precise trim 1.0 -> 3.0 sec: 2.000 sec
- fast-copy trim 1.0 -> 3.0 sec: 2.167 sec
- PNG 2 fps: 8 frames
- JPG 1 fps: 4 frames
- Unicode / spaces path: PASS

Fast Cut remains intentionally approximate because stream copy is constrained by keyframes.
