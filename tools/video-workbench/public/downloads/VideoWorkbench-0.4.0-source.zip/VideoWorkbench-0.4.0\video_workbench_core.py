from __future__ import annotations

import json
import math
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


class VideoWorkbenchError(RuntimeError):
    pass


@dataclass(frozen=True)
class MediaInfo:
    path: Path
    duration: float
    width: int | None
    height: int | None
    fps: float | None
    video_streams: int
    audio_streams: int
    size_bytes: int
def require_toolchain() -> tuple[str, str]:
    ffmpeg = shutil.which("ffmpeg")
    ffprobe = shutil.which("ffprobe")
    if not ffmpeg or not ffprobe:
        raise VideoWorkbenchError(
            "ffmpeg / ffprobe が見つかりません。PATH を確認してください。"
        )
    return ffmpeg, ffprobe


def _resolve_input(value: str | Path) -> Path:
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"動画ファイルが見つかりません: {path}")
    return path


def parse_time(value: str | int | float) -> float:
    text = str(value).strip()
    if not text:
        raise ValueError("時間を入力してください。")
    if ":" not in text:
        try:
            seconds = float(text)
        except ValueError as exc:
            raise ValueError(f"時間の形式が不正です: {text}") from exc
        if not math.isfinite(seconds) or seconds < 0:
            raise ValueError("時間は0以上の有限値にしてください。")
        return seconds

    parts = text.split(":")
    if len(parts) not in {2, 3}:
        raise ValueError("時間は 秒 / MM:SS / HH:MM:SS 形式で入力してください。")
    try:
        numbers = [float(part) for part in parts]
    except ValueError as exc:
        raise ValueError(f"時間の形式が不正です: {text}") from exc
    if any((not math.isfinite(v) or v < 0) for v in numbers):
        raise ValueError("時間は0以上の有限値にしてください。")
    if numbers[-1] >= 60:
        raise ValueError("秒の部分は60未満にしてください。")
    if len(numbers) == 3 and numbers[-2] >= 60:
        raise ValueError("分の部分は60未満にしてください。")
    if len(numbers) == 2:
        return numbers[0] * 60 + numbers[1]
    return numbers[0] * 3600 + numbers[1] * 60 + numbers[2]


def format_time(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:06.3f}"
    return f"{minutes:02d}:{secs:06.3f}"


def _parse_fraction(value: str | None) -> float | None:
    if not value or value in {"0/0", "N/A"}:
        return None
    try:
        if "/" in value:
            numerator, denominator = value.split("/", 1)
            denominator_value = float(denominator)
            if denominator_value == 0:
                return None
            return float(numerator) / denominator_value
        return float(value)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def _run(command: Sequence[str], *, timeout: int | None = None) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        list(command),
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=timeout,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        if len(detail) > 6000:
            detail = detail[-6000:]
        raise VideoWorkbenchError(
            f"外部コマンドが失敗しました (exit={result.returncode})\n{detail}"
        )
    return result


def probe_media(value: str | Path) -> MediaInfo:
    _, ffprobe = require_toolchain()
    path = _resolve_input(value)
    result = _run(
        [
            ffprobe,
            "-v", "error",
            "-print_format", "json",
            "-show_format",
            "-show_streams",
            str(path),
        ],
        timeout=30,
    )
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise VideoWorkbenchError("ffprobe の結果を解析できませんでした。") from exc
    streams = payload.get("streams") or []
    video_streams = [s for s in streams if s.get("codec_type") == "video"]
    audio_streams = [s for s in streams if s.get("codec_type") == "audio"]

    duration = 0.0
    format_duration = (payload.get("format") or {}).get("duration")
    try:
        duration = float(format_duration or 0)
    except (TypeError, ValueError):
        duration = 0.0
    if duration <= 0:
        candidates: list[float] = []
        for stream in streams:
            try:
                candidates.append(float(stream.get("duration") or 0))
            except (TypeError, ValueError):
                pass
        duration = max(candidates, default=0.0)
    if duration <= 0:
        raise VideoWorkbenchError("動画の長さを取得できませんでした。")

    first_video = video_streams[0] if video_streams else {}
    fps = _parse_fraction(first_video.get("avg_frame_rate"))
    if fps is None:
        fps = _parse_fraction(first_video.get("r_frame_rate"))

    return MediaInfo(
        path=path,
        duration=duration,
        width=first_video.get("width"),
        height=first_video.get("height"),
        fps=fps,
        video_streams=len(video_streams),
        audio_streams=len(audio_streams),
        size_bytes=path.stat().st_size,
    )


def _time_label(value: str | int | float) -> str:
    return str(value).strip().replace(":", "-").replace(".", "p").replace(" ", "")


def default_trim_path(
    input_path: Path,
    start: str | int | float,
    end: str | int | float,
    *,
    precise: bool,
) -> Path:
    suffix = ".mp4" if precise else input_path.suffix
    mode = "precise" if precise else "fast"
    return input_path.with_name(
        f"{input_path.stem}_{_time_label(start)}-{_time_label(end)}_{mode}{suffix}"
    )


def _prepare_output_file(
    input_path: Path,
    output_path: Path,
    *,
    overwrite: bool,
) -> Path:
    output_path = output_path.expanduser().resolve()
    if output_path == input_path:
        raise ValueError("入力動画そのものを出力先にはできません。")
    if output_path.exists() and not overwrite:
        raise FileExistsError(f"出力ファイルが既にあります: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    return output_path
def trim_video(
    input_file: str | Path,
    start: str | int | float,
    end: str | int | float,
    *,
    output_file: str | Path | None = None,
    precise: bool = False,
    overwrite: bool = False,
) -> tuple[Path, MediaInfo]:
    ffmpeg, _ = require_toolchain()
    input_path = _resolve_input(input_file)
    media = probe_media(input_path)
    start_seconds = parse_time(start)
    end_seconds = parse_time(end)

    if end_seconds <= start_seconds:
        raise ValueError("終了時間は開始時間より後にしてください。")
    if start_seconds >= media.duration:
        raise ValueError("開始時間が動画の長さを超えています。")
    if end_seconds > media.duration + 0.25:
        raise ValueError(
            f"終了時間が動画の長さ ({format_time(media.duration)}) を超えています。"
        )
    if output_file is None:
        output_path = default_trim_path(
            input_path, start, end, precise=precise
        )
    else:
        output_path = Path(output_file)

    if precise and output_path.suffix.lower() not in {".mp4", ".m4v", ".mov", ".mkv"}:
        raise ValueError(
            "正確カットの出力は mp4 / m4v / mov / mkv を指定してください。"
        )
    output_path = _prepare_output_file(
        input_path, output_path, overwrite=overwrite
    )

    command = [
        ffmpeg,
        "-nostdin",
        "-hide_banner",
        "-loglevel", "error",
        "-y" if overwrite else "-n",
    ]
    duration = end_seconds - start_seconds
    if precise:
        command += [
            "-i", str(input_path),
            "-ss", f"{start_seconds:.6f}",
            "-t", f"{duration:.6f}",
            "-map", "0:v:0?",
            "-map", "0:a:0?",
            "-c:v", "libx264",
            "-preset", "veryfast",
            "-crf", "18",
            "-c:a", "aac",
            "-b:a", "192k",
            "-movflags", "+faststart",
        ]
    else:
        command += [
            "-ss", f"{start_seconds:.6f}",
            "-i", str(input_path),
            "-t", f"{duration:.6f}",
            "-map", "0:v:0?",
            "-map", "0:a:0?",
            "-c", "copy",
        ]
    command.append(str(output_path))
    _run(command)

    if not output_path.is_file() or output_path.stat().st_size <= 0:
        raise VideoWorkbenchError("出力動画が作成されませんでした。")
    output_info = probe_media(output_path)
    if output_info.video_streams <= 0:
        raise VideoWorkbenchError("出力動画に映像ストリームがありません。")
    return output_path, output_info


def default_frame_dir(
    input_path: Path,
    image_format: str,
    fps: float | None,
) -> Path:
    ext = "jpg" if image_format.lower() == "jpeg" else image_format.lower()
    suffix = ext if fps is None else f"{str(fps).replace('.', 'p')}fps_{ext}"
    return input_path.parent / f"frames_{input_path.stem}_{suffix}"


def export_frames(
    input_file: str | Path,
    *,
    image_format: str = "png",
    fps: float | None = None,
    output_dir: str | Path | None = None,
    jpg_quality: int = 2,
    overwrite: bool = False,
) -> tuple[Path, int]:
    ffmpeg, _ = require_toolchain()
    input_path = _resolve_input(input_file)
    image_format = image_format.lower().strip()
    if image_format not in {"png", "jpg", "jpeg"}:
        raise ValueError("画像形式は png / jpg / jpeg にしてください。")
    if fps is not None:
        if not math.isfinite(fps) or fps <= 0:
            raise ValueError("FPSは0より大きい値にしてください。")
    if not 2 <= int(jpg_quality) <= 31:
        raise ValueError("JPG品質は2〜31の範囲にしてください。")

    out_dir = (
        Path(output_dir).expanduser().resolve()
        if output_dir
        else default_frame_dir(input_path, image_format, fps)
    )
    if out_dir.exists() and any(out_dir.iterdir()) and not overwrite:
        raise FileExistsError(
            f"出力フォルダが空ではありません: {out_dir}"
        )
    out_dir.mkdir(parents=True, exist_ok=True)

    ext = "jpg" if image_format == "jpeg" else image_format
    pattern = out_dir / f"frame_%06d.{ext}"
    command = [
        ffmpeg,
        "-nostdin",
        "-hide_banner",
        "-loglevel", "error",
        "-y" if overwrite else "-n",
        "-i", str(input_path),
    ]
    if fps is None:
        command += ["-vsync", "0"]
    else:
        command += ["-vf", f"fps={fps:g}"]
    if ext == "jpg":
        command += ["-q:v", str(int(jpg_quality))]
    command.append(str(pattern))
    _run(command)
    files = sorted(out_dir.glob(f"frame_*.{ext}"))
    if not files:
        raise VideoWorkbenchError("フレーム画像が1枚も出力されませんでした。")
    return out_dir, len(files)


def describe_media(media: MediaInfo) -> dict[str, str]:
    resolution = (
        f"{media.width} × {media.height}"
        if media.width and media.height
        else "不明"
    )
    fps = f"{media.fps:.3f}" if media.fps else "不明"
    size_mb = media.size_bytes / (1024 * 1024)
    return {
        "duration": format_time(media.duration),
        "resolution": resolution,
        "fps": fps,
        "streams": f"映像 {media.video_streams} / 音声 {media.audio_streams}",
        "size": f"{size_mb:.2f} MiB",
    }
