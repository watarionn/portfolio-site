# Origin / clean rebuild notes

Date: 2026-09-25

## Explicitly searched legacy assets

The active memory-vault asset directory contains:

- `extract_dmm_tsv.R`
- `crawl_shabulism_cid.R`

The first script extracts repeated cards from saved HTML and writes TSV.
The second script fetches list pages, discovers detail-page URLs, caches repeated pages, extracts text/attributes, applies regular expressions, and writes TSV.

## Reusable ideas

The new work keeps the generic ideas, not the site-specific selectors.

Reusable patterns:

1. read HTML
2. select repeated records
3. extract text
4. extract attributes
5. resolve relative URLs
6. extract IDs with regular expressions
7. follow list -> detail links
8. delay/retry requests
9. cache duplicate detail pages
10. export structured rows

## Clean-rebuild decision

Phase 1 begins offline-only.

No site-specific URL, cookie, login state, browser profile, token, or historical output is copied into the runtime implementation.

The public examples use synthetic example.test HTML only.

## Phase 3 reuse from crawl_shabulism_cid.R

The generic crawl layer intentionally preserves these old design ideas:

- explicit request delay
- timeout
- retry
- list -> detail traversal
- duplicate detail-page cache
- source-page provenance

The site-specific hostname, selectors, browser-like User-Agent and CID rules are not part of the runtime defaults.