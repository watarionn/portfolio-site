@echo off
setlocal
cd /d "%~dp0"
python src\phase03b_render_master.py
if errorlevel 1 (
  echo.
  echo Phase 03B render failed.
  exit /b 1
)
echo.
echo Phase 03B render complete.
echo WAV: output\phase03b\best_candidate_master.wav
echo OGG: output\phase03b\best_candidate_preview.ogg ^(when ffmpeg is available^)
endlocal
