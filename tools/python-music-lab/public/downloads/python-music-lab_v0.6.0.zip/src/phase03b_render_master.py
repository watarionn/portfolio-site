from __future__ import annotations

import json
from pathlib import Path

from mido import MidiFile, tempo2bpm, tick2second

from python_music_lab.synth import file_sha256, parse_midi_notes
from python_music_lab.synth_fx import (
    export_ogg_vorbis,
    load_phase03b_config,
    render_midi_to_enhanced_wav,
)


def section_markers(midi_path: Path) -> list[dict[str, int | float | str]]:
    midi = MidiFile(midi_path)
    tempos = [
        message.tempo
        for track in midi.tracks
        for message in track
        if message.type == "set_tempo"
    ]
    tempo = tempos[0] if tempos else 500000
    absolute_tick = 0
    result: list[dict[str, int | float | str]] = []
    for message in midi.tracks[0]:
        absolute_tick += message.time
        if message.type == "marker":
            result.append({
                "tick": absolute_tick,
                "start_seconds": round(tick2second(absolute_tick, midi.ticks_per_beat, tempo), 6),
                "label": message.text,
            })
    return result


def _voice_manifest(config: dict) -> dict:
    result = {}
    for name, preset in config["voices"].items():
        result[name] = {
            "gain": preset.gain,
            "pan": preset.pan,
            "adsr": {
                "attack": preset.adsr.attack,
                "decay": preset.adsr.decay,
                "sustain": preset.adsr.sustain,
                "release": preset.adsr.release,
            },
            "layers": [
                {
                    "waveform": layer.waveform,
                    "amplitude": layer.amplitude,
                    "octave": layer.octave,
                    "detune_cents": layer.detune_cents,
                }
                for layer in preset.layers
            ],
            "lowpass_hz": preset.lowpass_hz,
            "lowpass_stages": preset.lowpass_stages,
        }
    return result


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    config_path = project_root / "config" / "phase03b_synth.json"
    source_midi = project_root / "output" / "phase02b" / "best_candidate.mid"
    output_dir = project_root / "output" / "phase03b"
    wav_path = output_dir / "best_candidate_master.wav"
    ogg_path = output_dir / "best_candidate_preview.ogg"
    manifest_path = output_dir / "manifest.json"
    portfolio_path = output_dir / "portfolio_audio.json"

    config = load_phase03b_config(config_path)
    stats, track_stats = render_midi_to_enhanced_wav(
        source_midi,
        wav_path,
        sample_rate=config["sample_rate"],
        target_peak=config["target_peak"],
        tail_seconds=config["tail_seconds"],
        voices=config["voices"],
        track_gain=config["track_gain"],
        delay=config["delay"],
        reverb=config["reverb"],
        saturation_drive=config["saturation_drive"],
    )
    ogg = export_ogg_vorbis(wav_path, ogg_path, config["ogg_quality"])
    notes, ticks_per_beat, tempo = parse_midi_notes(source_midi)

    markers = section_markers(source_midi)

    manifest = {
        "schema_version": 2,
        "generator": "Python Music Lab Phase 03B",
        "source_midi": str(source_midi.relative_to(project_root)).replace("\\", "/"),
        "source_midi_sha256": file_sha256(source_midi),
        "wav_file": wav_path.name,
        "wav_sha256": file_sha256(wav_path),
        "wav_size_bytes": wav_path.stat().st_size,
        "ogg_file": ogg_path.name if ogg.created else None,
        "ogg": ogg.to_dict(),
        "bpm": round(float(tempo2bpm(tempo)), 6),
        "ticks_per_beat": ticks_per_beat,
        "section_markers": markers,
        "render": stats.to_dict(),
        "track_stats": track_stats,
        "track_note_counts": {
            track: sum(1 for note in notes if note.track == track)
            for track in sorted({note.track for note in notes})
        },
        "synthesis": {
            "voices": _voice_manifest(config),
            "track_gain": config["track_gain"],
            "filter": "deterministic moving-average low-pass",
            "delay": config["delay"],
            "reverb": config["reverb"],
            "master_saturation_drive": config["saturation_drive"],
            "normalization": "peak normalization",
        },
        "portfolio_ready": True,
        "browser_playback": ["OGG/Vorbis", "WAV"] if ogg.created else ["WAV"],
        "portfolio_preferred_audio": ogg_path.name if ogg.created else wav_path.name,
        "reproducibility": {
            "wav": "byte-level deterministic for identical input/config/runtime",
            "ogg": "encoder-dependent; manifest records exact artifact hash",
        },
    }
    portfolio_audio = {
        "schema_version": 1,
        "project": "Python作曲研究所",
        "phase": "03B",
        "title": "Phase 03B Best Candidate",
        "duration_seconds": stats.duration_seconds,
        "sources": ([
            {"src": ogg_path.name, "type": "audio/ogg", "role": "preferred"},
            {"src": wav_path.name, "type": "audio/wav", "role": "fallback"},
        ] if ogg.created else [
            {"src": wav_path.name, "type": "audio/wav", "role": "preferred"},
        ]),
        "sections": markers,
        "metadata": {
            "bpm": round(float(tempo2bpm(tempo)), 6),
            "source_midi_sha256": file_sha256(source_midi),
            "audio_manifest": manifest_path.name,
        },
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    portfolio_path.write_text(json.dumps(portfolio_audio, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"Source MIDI : {source_midi}")
    print(f"Master WAV  : {wav_path}")
    print(f"Preview OGG : {ogg_path if ogg.created else 'not created'}")
    print(f"Duration    : {stats.duration_seconds:.3f} sec")
    print(f"Sample rate : {stats.sample_rate} Hz")
    print(f"Peak        : {stats.output_peak:.6f}")
    print(f"RMS         : {stats.rms:.6f}")
    print(f"Crest       : {stats.crest_factor_db:.3f} dB")
    print(f"Notes       : {stats.note_count}")
    print(f"WAV SHA-256 : {file_sha256(wav_path)}")
    if ogg.created:
        print(f"OGG SHA-256 : {ogg.sha256}")
        print(f"OGG bytes   : {ogg.size_bytes}")
    else:
        print(f"OGG status  : {ogg.error}")
    print(f"Manifest    : {manifest_path}")
    print(f"Portfolio   : {portfolio_path}")


if __name__ == "__main__":
    main()
