# Phase 1 QA

Date: 2026-09-24

## Goal

Create a clean common core for Media Collector before building source-specific GUI adapters.

## Security decision

Legacy source code was reviewed only as reference material.

Hard-coded tokens, cookies, credentials, private keys and old download history are not copied into this repository.

## Phase 1 scope

- common MediaItem model
- X media URL normalization
- generic URL handling
- URL extraction from text/TSV/CSV-like input
- normalized URL deduplication
- safe filenames
- plan JSON/TSV manifests
- verified direct-media download path
- Content-Type validation
- per-item size limit
- SHA-256 calculation
- duplicate-content suppression
- download JSON/TSV manifests
- CLI plan-only mode by default

## Non-goals

- bypassing authentication
- bypassing access controls
- scraping paywalled/private content
- persisting browser cookies or credentials
- direct source account automation in Phase 1

## Next

Phase 2 will add the Windows GUI and source adapters while keeping the core safety boundary unchanged.
