from __future__ import annotations

import json
import random
from dataclasses import dataclass
from pathlib import Path

from .midi_writer import NoteEvent
from .music_theory import diatonic_triad, major_scale_midi


@dataclass(frozen=True)
class SongConfig:
    title: str
    bpm: int
    key_root: str
    mode: str
    seed: int
    bars: int
    progression: list[str]
    ticks_per_beat: int

    @property
    def bar_ticks(self) -> int:
        return self.ticks_per_beat * 4


def load_config(path: Path) -> SongConfig:
    data = json.loads(path.read_text(encoding="utf-8"))
    config = SongConfig(**data)
    if config.mode != "major":
        raise ValueError("Phase 01 currently supports mode='major' only.")
    if config.bars <= 0:
        raise ValueError("bars must be greater than 0.")
    if not config.progression:
        raise ValueError("progression must not be empty.")
    return config


def chord_for_bar(config: SongConfig, bar: int, octave: int = 4) -> list[int]:
    degree = config.progression[bar % len(config.progression)]
    return diatonic_triad(config.key_root, degree, octave)


def compose_chords(config: SongConfig) -> list[NoteEvent]:
    events: list[NoteEvent] = []
    for bar in range(config.bars):
        start = bar * config.bar_ticks
        chord = chord_for_bar(config, bar, octave=4)
        for note in chord:
            events.append(NoteEvent(start, config.bar_ticks, note, 64, channel=1))
    return events


def compose_bass(config: SongConfig) -> list[NoteEvent]:
    events: list[NoteEvent] = []
    beat = config.ticks_per_beat
    for bar in range(config.bars):
        root = chord_for_bar(config, bar, octave=3)[0] - 12
        for beat_index in range(4):
            note = root if beat_index in (0, 2) else root + 12
            start = bar * config.bar_ticks + beat_index * beat
            events.append(NoteEvent(start, beat, note, 82, channel=2))
    return events


def compose_drums(config: SongConfig) -> list[NoteEvent]:
    events: list[NoteEvent] = []
    eighth = config.ticks_per_beat // 2
    beat = config.ticks_per_beat

    for bar in range(config.bars):
        base = bar * config.bar_ticks

        # Closed hi-hat: 8th notes.
        for step in range(8):
            events.append(NoteEvent(base + step * eighth, eighth // 2, 42, 55, channel=9))

        # Kick: beats 1 and 3.
        for beat_index in (0, 2):
            events.append(NoteEvent(base + beat_index * beat, beat // 2, 36, 100, channel=9))

        # Snare: beats 2 and 4.
        for beat_index in (1, 3):
            events.append(NoteEvent(base + beat_index * beat, beat // 2, 38, 94, channel=9))

    return events


def compose_melody(config: SongConfig) -> list[NoteEvent]:
    rng = random.Random(config.seed)
    events: list[NoteEvent] = []
    eighth = config.ticks_per_beat // 2
    scale = major_scale_midi(config.key_root, octave=4)
    scale_two_octaves = scale + [note + 12 for note in scale]

    previous_note = scale_two_octaves[4]

    for bar in range(config.bars):
        chord = chord_for_bar(config, bar, octave=4)
        chord_tones = chord + [note + 12 for note in chord]

        for step in range(8):
            # A small amount of silence gives the phrase room to breathe.
            if rng.random() < 0.16:
                continue

            strong_position = step in (0, 4)
            candidates = chord_tones if strong_position else scale_two_octaves

            # Favor nearby notes to avoid random-jump melodies.
            ranked = sorted(candidates, key=lambda note: abs(note - previous_note))
            pool = ranked[: min(5, len(ranked))]
            note = rng.choice(pool)
            note = max(60, min(84, note))

            duration_steps = 2 if step in (2, 6) and rng.random() < 0.40 else 1
            duration = eighth * duration_steps
            start = bar * config.bar_ticks + step * eighth
            velocity = rng.randint(78, 108)

            events.append(NoteEvent(start, duration, note, velocity, channel=0))
            previous_note = note

    return events


def compose_song(config: SongConfig) -> dict[str, list[NoteEvent]]:
    return {
        "Melody": compose_melody(config),
        "Chords": compose_chords(config),
        "Bass": compose_bass(config),
        "Drums": compose_drums(config),
    }
