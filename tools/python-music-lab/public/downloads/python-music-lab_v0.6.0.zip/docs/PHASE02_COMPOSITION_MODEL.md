# Phase 02A Composition Model

Phase 02A adds musical form and motif development on top of the deterministic Phase 01 engine.

## Song form

Default form:

- A: 8 bars
- B: 8 bars
- Chorus: 8 bars

Each section owns its chord progression, melody density, register shift, and energy value.

## Motif model

A base one-bar motif is generated from the song Seed on an eighth-note grid. The motif stores scale-relative motion rather than fixed MIDI notes. This lets the same musical identity survive chord and section changes.

Development rules:

- A: presents the motif in a restrained register and density.
- B: gradually develops the contour upward and increases energy.
- Chorus: widens the contour, raises the register, increases density, and adds stronger drum accents.
- Phrase endings: bars 4 and 8 resolve toward the tonic to create punctuation.

## Arrangement model

- Melody: motif-driven, harmony-aware on strong beats.
- Chords: one diatonic triad per bar.
- Bass: root/fifth movement with section-energy variation.
- Drums: section-dependent hi-hat, kick density, crash accents, and chorus lift.

## MIDI structure markers

The conductor track contains MIDI marker events at section boundaries:

- A
- B
- Chorus

These markers are useful both in DAWs and for future portfolio visualizations.

## Determinism

A fixed Seed must produce byte-identical MIDI output for the same config and source version. `manifest.json` stores the SHA-256 for verification.

## Remaining Phase 02 work

Phase 02A does not yet complete the full Phase 02 roadmap. Remaining work includes:

- minor keys
- richer rhythm grammar
- non-chord tones and approach tones
- motif scoring and candidate ranking
- section-level candidate comparison
- stronger cadence and transition handling
