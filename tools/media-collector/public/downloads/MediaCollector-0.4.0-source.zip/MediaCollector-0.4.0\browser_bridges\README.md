# Browser Bridges

Browser Bridges are small console scripts that extract direct media URLs already exposed in the current page.

They intentionally do not read cookies, localStorage, sessionStorage, authentication headers, account tokens, or passwords. They also do not download the media themselves.

## X

Run browser_bridges/x_media_bridge.js on an X page you are already allowed to view.

It returns visible pbs.twimg.com/media URLs normalized to name=orig.

## Pixiv

Run browser_bridges/pixiv_media_bridge.js on a Pixiv page you are already allowed to view.

It returns visible i.pximg.net direct image URLs.

## Generic DOM

Run browser_bridges/generic_dom_bridge.js on another page.

It inspects img, video, source, and direct-media a[href] elements.

## Workflow

1. Run the appropriate Bridge in the page console.
2. Copy the URL list.
3. Paste it into Media Collector.
4. Press Plan作成.
5. Review normalization and duplicates before any download.

The browser remains responsible for authentication. Media Collector receives only URLs.
