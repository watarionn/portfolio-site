# Web Extraction Recipes Phase 3 Handoff

Date: 2026-09-25

## Current checkpoint

Repository:

    C:\Users\watar\Documents\GitHub\web-extraction-recipes

Branch:

    main

Latest commits:

    fafbcc6 Harden Web Extraction Recipes Phase 3 crawl safety
    2750a20 Complete Web Extraction Recipes Phase 3 HTTP crawl
    8e729d2 Build Web Extraction Recipes Phase 2 GUI
    961a26b Build Web Extraction Recipes Phase 1 core

## Completed phases

### Phase 1

Offline recipe engine:

- local HTML parsing
- JSON extraction recipes
- repeated-row selectors
- text / attribute extraction
- relative URL resolution
- regex capture groups
- TSV / CSV / JSON export
- UTF-8 / CP932 input
- standard-library-only core

### Phase 2

Windows GUI:

- HTML picker
- Recipe JSON editor / validation / save
- extraction Preview
- summary
- result export
- stale-result invalidation
- background extraction worker

### Phase 3

HTTP Collection + List -> Detail Crawl:

- one or more start/list URLs
- configurable detail-link selector
- relative URL resolution
- list -> detail two-stage crawl
- Phase 1 detail recipe reuse
- source_url / detail_url provenance
- request delay
- timeout
- retry for 429 / 5xx / network failures
- normalized URL cache
- max_pages guard
- same-origin policy
- robots.txt policy
- HTML / XHTML only
- 4 MiB response limit
- declared charset support
- embedded URL credential rejection

## HTTP safety defaults

Default policy:

- delay_seconds: 1.0
- timeout_seconds: 20
- max_retries: 2
- max_pages: 100
- same_origin: true
- respect_robots: true
- allow_private_hosts: false

Private/local targets such as localhost, loopback, private IP, link-local and reserved ranges are blocked by default.

Development localhost can be used only when the Crawl Recipe explicitly sets:

    "allow_private_hosts": true

robots.txt 404 / 410 is treated as no robots file.
Other robots fetch failures fail closed.

Runtime requests do not add:

- Cookie
- Authorization
- browser profile
- login session

There is no CAPTCHA, paywall, DRM or access-control bypass logic.

## QA state

Final Phase 3 verification:

- 28 / 28 tests PASS
- ResourceWarning promoted to error: PASS
- localhost list -> detail CLI smoke: PASS
- retry after HTTP 500: PASS
- robots deny: PASS
- same-origin filter: PASS
- cross-origin redirect block: PASS
- duplicate detail cache: PASS
- provenance retention: PASS
- max_pages stop: PASS
- XHTML + charset: PASS
- private/local host default block: PASS
- no Cookie / Authorization headers: PASS
- secret scan: PASS
- mojibake scan: clean
- screenshot verification: PASS
- git diff check: PASS

Formal Phase 3 screenshot:

    qa/screenshots/phase3-main.png

Size:

    1256 x 859

SHA-256:

    FFFEB4403393A617FC9050E732FD6D640EB5FFF7510ECBA2092AB68188E32204

## Legacy sources used as design references

Explicitly searched assets:

- extract_dmm_tsv.R
- crawl_shabulism_cid.R

Site-specific selectors, URLs and state were not copied into the new runtime.
Only reusable extraction/crawl patterns were generalized.

## Resume point

Next phase:

    Phase 4 - Release Candidate

Recommended sequence:

1. add VERSION and CHANGELOG
2. add preflight
3. add release build script
4. run final compile / 28-test / security / screenshot gates
5. build source ZIP and SHA-256
6. extract ZIP into a separate temp directory and rerun QA
7. create public GitHub repository
8. create v0.4.0 Release Candidate
9. redownload release assets and verify hashes
10. register on the current normal portfolio site as the next work
11. complete production deployment and live verification

Portfolio City remains paused unless explicitly resumed.