from __future__ import annotations

import sys
import tkinter


MIN_PYTHON = (3, 10)


def main() -> int:
    failures: list[str] = []

    print("Project Snapshot Generator preflight")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Tkinter: {tkinter.TkVersion}")

    if sys.version_info < MIN_PYTHON:
        failures.append(
            f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer is required"
        )

    try:
        root = tkinter.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
        print("Tk GUI: available")
    except tkinter.TclError as exc:
        failures.append(f"Tk GUI unavailable: {exc}")

    if failures:
        print("\nPreflight FAILED")
        for item in failures:
            print(f"- {item}")
        return 1

    print("\nPreflight PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
