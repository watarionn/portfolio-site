from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable


class DownloadWorkbenchError(RuntimeError):
    pass


SENSITIVE_QUERY_KEYS = {
    "token",
    "access_token",
    "refresh_token",
    "auth",
    "authorization",
    "signature",
    "sig",
    "key",
    "api_key",
    "apikey",
    "x-amz-signature",
    "x-amz-credential",
    "x-goog-signature",
    "x-goog-credential",
    "policy",
    "key-pair-id",
}


@dataclass(frozen=True)
class ToolStatus:
    name: str
    path: str | None
    version: str | None
    available: bool


@dataclass(frozen=True)
class FormatOption:
    format_id: str
    ext: str
    resolution: str
    fps: float | None
    vcodec: str
    acodec: str
    filesize: int | None
    protocol: str
    note: str


@dataclass(frozen=True)
class SubtitleTrack:
    language: str
    automatic: bool
    ext: str


@dataclass(frozen=True)
class MediaInfo:
    url: str
    webpage_url: str
    media_id: str
    title: str
    uploader: str
    duration: float | None
    extractor: str
    formats: tuple[FormatOption, ...]
    subtitles: tuple[SubtitleTrack, ...]


@dataclass(frozen=True)
class DownloadRequest:
    url: str
    output_dir: Path
    mode: str = "video"
    format_id: str = ""
    audio_format: str = "m4a"
    range_start: str = ""
    range_end: str = ""
    precise_range: bool = False
    subtitle_languages: tuple[str, ...] = ()
    include_auto_subtitles: bool = False
    write_metadata: bool = True
    write_thumbnail: bool = False


@dataclass(frozen=True)
class DownloadExecution:
    args: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str


def validate_http_url(raw_url: str) -> str:
    value = raw_url.strip()
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise DownloadWorkbenchError("URL must use http or https.")
    if not parsed.hostname:
        raise DownloadWorkbenchError("URL has no hostname.")
    if parsed.username is not None or parsed.password is not None:
        raise DownloadWorkbenchError("URLs containing embedded credentials are not accepted.")
    return value


def _is_sensitive_query_key(key: str) -> bool:
    normalized = key.strip().lower()
    if normalized in SENSITIVE_QUERY_KEYS:
        return True
    return normalized.endswith(
        ("token", "signature", "credential", "api_key", "apikey")
    )


def redact_url(raw_url: str) -> str:
    parsed = urllib.parse.urlsplit(raw_url.strip())
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        return raw_url.strip()
    netloc = parsed.hostname.lower()
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    redacted = [
        (key, "REDACTED" if _is_sensitive_query_key(key) else value)
        for key, value in query
    ]
    return urllib.parse.urlunsplit(
        (
            parsed.scheme.lower(),
            netloc,
            parsed.path or "/",
            urllib.parse.urlencode(redacted, doseq=True),
            "",
        )
    )


def parse_timecode(value: str) -> float:
    text = value.strip()
    if not text:
        raise ValueError("timecode is empty")
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        return float(text)

    parts = text.split(":")
    if len(parts) not in {2, 3}:
        raise ValueError("timecode must be seconds, MM:SS, or HH:MM:SS")

    try:
        numbers = [float(part) for part in parts]
    except ValueError as exc:
        raise ValueError("timecode contains a non-numeric component") from exc

    if any(number < 0 for number in numbers):
        raise ValueError("timecode cannot be negative")
    if len(numbers) == 2:
        minutes, seconds = numbers
        if seconds >= 60:
            raise ValueError("seconds must be below 60")
        return minutes * 60 + seconds

    hours, minutes, seconds = numbers
    if minutes >= 60 or seconds >= 60:
        raise ValueError("minutes and seconds must be below 60")
    return hours * 3600 + minutes * 60 + seconds


def format_timecode(seconds: float) -> str:
    if seconds < 0:
        raise ValueError("seconds cannot be negative")
    whole = int(seconds)
    fraction = seconds - whole
    hours, remainder = divmod(whole, 3600)
    minutes, secs = divmod(remainder, 60)
    if fraction:
        sec_text = f"{secs + fraction:06.3f}".rstrip("0").rstrip(".")
        if float(sec_text) < 10 and not sec_text.startswith("0"):
            sec_text = "0" + sec_text
    else:
        sec_text = f"{secs:02d}"
    return f"{hours:02d}:{minutes:02d}:{sec_text}"


def _run_version(executable: str, args: list[str]) -> str | None:
    try:
        completed = subprocess.run(
            [executable, *args],
            shell=False,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    first = (completed.stdout or "").splitlines()
    return first[0].strip() if first else None


def detect_tools() -> tuple[ToolStatus, ToolStatus]:
    ytdlp = shutil.which("yt-dlp")
    ffmpeg = shutil.which("ffmpeg")
    return (
        ToolStatus(
            "yt-dlp",
            ytdlp,
            _run_version(ytdlp, ["--version"]) if ytdlp else None,
            bool(ytdlp),
        ),
        ToolStatus(
            "ffmpeg",
            ffmpeg,
            _run_version(ffmpeg, ["-version"]) if ffmpeg else None,
            bool(ffmpeg),
        ),
    )


def _base_ytdlp_args(ytdlp_executable: str) -> list[str]:
    return [
        ytdlp_executable,
        "--ignore-config",
        "--no-colors",
        "--newline",
        "--encoding",
        "utf-8",
        "--no-playlist",
    ]


def build_analyze_args(url: str, ytdlp_executable: str = "yt-dlp") -> list[str]:
    clean = validate_http_url(url)
    return [
        *_base_ytdlp_args(ytdlp_executable),
        "--dump-single-json",
        "--skip-download",
        "--no-warnings",
        "--",
        clean,
    ]


def _format_resolution(info: dict) -> str:
    resolution = info.get("resolution")
    if resolution and resolution != "audio only":
        return str(resolution)
    width = info.get("width")
    height = info.get("height")
    if width and height:
        return f"{width}x{height}"
    if str(info.get("vcodec") or "none") == "none":
        return "audio only"
    return ""


def _format_filesize(info: dict) -> int | None:
    for key in ("filesize", "filesize_approx"):
        value = info.get(key)
        try:
            if value is not None:
                return int(value)
        except (TypeError, ValueError):
            pass
    return None


def media_info_from_json(data: dict, source_url: str) -> MediaInfo:
    formats: list[FormatOption] = []
    for entry in data.get("formats") or []:
        if not isinstance(entry, dict):
            continue
        format_id = str(entry.get("format_id") or "")
        if not format_id:
            continue
        try:
            fps = float(entry["fps"]) if entry.get("fps") is not None else None
        except (TypeError, ValueError):
            fps = None
        formats.append(
            FormatOption(
                format_id=format_id,
                ext=str(entry.get("ext") or ""),
                resolution=_format_resolution(entry),
                fps=fps,
                vcodec=str(entry.get("vcodec") or ""),
                acodec=str(entry.get("acodec") or ""),
                filesize=_format_filesize(entry),
                protocol=str(entry.get("protocol") or ""),
                note=str(entry.get("format_note") or ""),
            )
        )

    subtitles: list[SubtitleTrack] = []
    for automatic, key in ((False, "subtitles"), (True, "automatic_captions")):
        tracks = data.get(key) or {}
        if not isinstance(tracks, dict):
            continue
        for language, variants in tracks.items():
            ext = ""
            if isinstance(variants, list) and variants and isinstance(variants[0], dict):
                ext = str(variants[0].get("ext") or "")
            subtitles.append(
                SubtitleTrack(str(language), automatic, ext)
            )

    duration = data.get("duration")
    try:
        duration_value = float(duration) if duration is not None else None
    except (TypeError, ValueError):
        duration_value = None

    webpage_url = str(data.get("webpage_url") or source_url)
    return MediaInfo(
        url=source_url,
        webpage_url=webpage_url,
        media_id=str(data.get("id") or ""),
        title=str(data.get("title") or "(untitled)"),
        uploader=str(data.get("uploader") or data.get("channel") or ""),
        duration=duration_value,
        extractor=str(data.get("extractor_key") or data.get("extractor") or ""),
        formats=tuple(formats),
        subtitles=tuple(subtitles),
    )


def analyze_url(
    url: str,
    *,
    ytdlp_executable: str = "yt-dlp",
    timeout: float = 60.0,
) -> MediaInfo:
    args = build_analyze_args(url, ytdlp_executable)
    try:
        completed = subprocess.run(
            args,
            shell=False,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise DownloadWorkbenchError("URL analysis timed out.") from exc
    except OSError as exc:
        raise DownloadWorkbenchError(f"Could not start yt-dlp: {exc}") from exc

    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()
        raise DownloadWorkbenchError(detail[-3000:] or "yt-dlp analysis failed.")

    try:
        data = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise DownloadWorkbenchError("yt-dlp returned invalid JSON.") from exc
    if not isinstance(data, dict):
        raise DownloadWorkbenchError("yt-dlp returned an unexpected response.")
    return media_info_from_json(data, validate_http_url(url))


def _validate_request(request: DownloadRequest) -> tuple[float | None, float | None]:
    validate_http_url(request.url)
    if request.mode not in {"video", "audio", "format"}:
        raise DownloadWorkbenchError(f"Unsupported mode: {request.mode}")
    if request.mode == "format" and not request.format_id.strip():
        raise DownloadWorkbenchError("A format ID is required in format mode.")
    if request.audio_format not in {"m4a", "mp3", "wav", "flac", "opus"}:
        raise DownloadWorkbenchError("Unsupported audio format.")

    start = parse_timecode(request.range_start) if request.range_start.strip() else None
    end = parse_timecode(request.range_end) if request.range_end.strip() else None
    if (start is None) != (end is None):
        raise DownloadWorkbenchError("Range start and end must be provided together.")
    if start is not None and end is not None and start >= end:
        raise DownloadWorkbenchError("Range end must be after range start.")
    return start, end


def build_download_args(
    request: DownloadRequest,
    *,
    ytdlp_executable: str = "yt-dlp",
) -> list[str]:
    start, end = _validate_request(request)
    output_dir = request.output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    args = [
        *_base_ytdlp_args(ytdlp_executable),
        "--no-overwrites",
        "--paths",
        str(output_dir),
        "-o",
        "%(title).120s [%(id)s].%(ext)s",
    ]

    if request.mode == "audio":
        args.extend(["-f", "ba/b", "-x", "--audio-format", request.audio_format])
    elif request.mode == "format":
        args.extend(["-f", request.format_id.strip()])
    else:
        args.extend(["-f", "bv*+ba/b", "--merge-output-format", "mp4"])

    if start is not None and end is not None:
        args.extend(
            [
                "--download-sections",
                f"*{format_timecode(start)}-{format_timecode(end)}",
            ]
        )
        if request.precise_range:
            args.append("--force-keyframes-at-cuts")

    if request.subtitle_languages:
        args.extend(["--write-subs", "--sub-langs", ",".join(request.subtitle_languages)])
    if request.include_auto_subtitles:
        args.append("--write-auto-subs")
    if request.write_metadata:
        args.append("--write-info-json")
    if request.write_thumbnail:
        args.append("--write-thumbnail")

    args.extend(["--", validate_http_url(request.url)])
    return args


def run_download(
    request: DownloadRequest,
    *,
    ytdlp_executable: str = "yt-dlp",
    line_callback: Callable[[str], None] | None = None,
) -> DownloadExecution:
    args = build_download_args(request, ytdlp_executable=ytdlp_executable)
    try:
        process = subprocess.Popen(
            args,
            shell=False,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
        )
    except OSError as exc:
        raise DownloadWorkbenchError(f"Could not start yt-dlp: {exc}") from exc

    lines: list[str] = []
    assert process.stdout is not None
    try:
        for line in process.stdout:
            clean = line.rstrip("\r\n")
            lines.append(clean)
            if line_callback:
                line_callback(clean)
    finally:
        process.stdout.close()
    returncode = process.wait()
    output = "\n".join(lines)
    return DownloadExecution(tuple(args), returncode, output, "")


def format_command_preview(args: Iterable[str]) -> str:
    values = [str(value) for value in args]
    if os.name == "nt":
        return subprocess.list2cmdline(values)
    return shlex.join(values)


def format_size(value: int | None) -> str:
    if value is None:
        return ""
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB"):
        if size < 1024 or unit == "GiB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{value} B"
