from __future__ import annotations

import json
from pathlib import Path

from mido import MidiFile, tempo2bpm

from python_music_lab.synth import (
    file_sha256,
    load_render_config,
    parse_midi_notes,
    render_midi_to_wav,
)


def section_markers(midi_path: Path) -> list[dict[str, int | str]]:
    midi = MidiFile(midi_path)
    absolute_tick = 0
    result: list[dict[str, int | str]] = []
    for message in midi.tracks[0]:
        absolute_tick += message.time
        if message.type == "marker":
            result.append({"tick": absolute_tick, "label": message.text})
    return result


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    config_path = project_root / "config" / "phase03a_synth.json"
    source_midi = project_root / "output" / "phase02b" / "best_candidate.mid"
    output_dir = project_root / "output" / "phase03a"
    wav_path = output_dir / "best_candidate.wav"
    manifest_path = output_dir / "manifest.json"

    render_config = load_render_config(config_path)
    stats = render_midi_to_wav(source_midi, wav_path, **render_config)
    notes, ticks_per_beat, tempo = parse_midi_notes(source_midi)

    manifest = {
        "schema_version": 1,
        "generator": "Python Music Lab Phase 03A",
        "source_midi": str(source_midi.relative_to(project_root)).replace("\\", "/"),
        "source_midi_sha256": file_sha256(source_midi),
        "wav_file": wav_path.name,
        "wav_sha256": file_sha256(wav_path),
        "bpm": round(float(tempo2bpm(tempo)), 6),
        "ticks_per_beat": ticks_per_beat,
        "section_markers": section_markers(source_midi),
        "render": stats.to_dict(),
        "track_note_counts": {
            track: sum(1 for note in notes if note.track == track)
            for track in sorted({note.track for note in notes})
        },
        "synthesis": {
            "tonal": "deterministic additive sine harmonics + ADSR",
            "drums": "deterministic procedural kick/snare/hat/crash",
            "normalization": "peak normalization",
            "effects": [],
        },
        "portfolio_ready": True,
        "browser_playback": "WAV",
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"Source MIDI : {source_midi}")
    print(f"WAV         : {wav_path}")
    print(f"Duration    : {stats.duration_seconds:.3f} sec")
    print(f"Sample rate : {stats.sample_rate} Hz")
    print(f"Peak        : {stats.output_peak:.6f}")
    print(f"RMS         : {stats.rms:.6f}")
    print(f"Notes       : {stats.note_count}")
    print(f"SHA-256     : {file_sha256(wav_path)}")
    print(f"Manifest    : {manifest_path}")


if __name__ == "__main__":
    main()
