# Phase 02B: Musicality and Evaluation

## Goal

Phase 02B moves candidate generation from “generate several and inspect manually” to “generate several, calculate transparent musical heuristics, narrow the set, then let a human make the final listening decision.”

The numeric score is not treated as musical truth. It is a reproducible filter for experiments.

## New composition grammar

### Tonality

- `major`
- `minor` using the natural-minor scale
- uppercase `V` in minor uses a raised leading tone to form a harmonic-minor dominant

### Rhythm styles

- `sparse`: more breathing space and occasional longer values
- `flowing`: balanced default motif rendering
- `driving`: stronger eighth-note retention and shorter attacks

### Non-chord tones

`non_chord_tone_rate` allows weak positions to move to nearby diatonic notes outside the current triad. Strong beats remain harmony-anchored.

### Cadences

- `none`
- `half`: section ends on V and melody lands on scale degree 5
- `authentic`: final two bars are V -> tonic and melody lands on the tonic

### Section transitions

When the following section has higher energy:

- bass adds a chromatic approach into the next root
- drums add a short tom fill

## Evaluation model

Each candidate receives a 0..100 score from six transparent components:

| Component | Weight | Intent |
|---|---:|---|
| Harmony | 25% | Strong-beat chord-tone stability |
| Motion | 20% | Preference for mostly stepwise melodic movement |
| Range | 15% | Avoid overly narrow or extreme melodic range |
| Section contrast | 15% | Chorus/last-section lift in register and density |
| Cadence | 15% | Requested section endings reach their target degree |
| Rhythm | 10% | Useful onset and duration variety |

The evaluator writes the raw metrics into `output/phase02b/manifest.json` so future UI can explain why a candidate received its score.

## Selection rule

`algorithm_selected` is the highest heuristic score.

`human_selected` stays `null` until a person actually listens and chooses. The project intentionally does not equate algorithmic ranking with artistic preference.

## Default experiment

- Key: A minor
- BPM: 128
- Form: A 8 -> B 8 -> Chorus 8
- Candidate count: 8
- Base seed: 2026091802

Run:

```text
run_phase02b.bat
```
