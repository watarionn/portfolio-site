from __future__ import annotations

import re
import urllib.parse
from typing import Iterable

from media_collector_core import (
    MediaCollectorError,
    MediaItem,
    build_plan,
    canonicalize_url,
    infer_generic_identity,
    media_kind,
)

PIXIV_HOSTS = {"i.pximg.net"}
PIXIV_RE = re.compile(
    r"/(?:img-original|img-master)/img/(?:\d{4}/\d{2}/\d{2}/\d{2}/\d{2}/\d{2}/)?"
    r"(?P<illust>\d+)_p(?P<page>\d+)",
    re.IGNORECASE,
)


def normalize_pixiv_media_url(raw_url: str) -> tuple[str, str, str]:
    canonical = canonicalize_url(raw_url)
    parsed = urllib.parse.urlsplit(canonical)
    if parsed.hostname not in PIXIV_HOSTS:
        raise MediaCollectorError("not a Pixiv media URL")

    normalized = urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, "", "")
    )
    match = PIXIV_RE.search(parsed.path)
    if match:
        media_id = f"{match.group('illust')}_p{match.group('page')}"
    else:
        media_id, _ = infer_generic_identity(normalized)
    _, ext = infer_generic_identity(normalized)
    return normalized, media_id, ext


def make_adapter_item(raw_url: str, adapter: str = "auto") -> MediaItem:
    canonical = canonicalize_url(raw_url)
    host = urllib.parse.urlsplit(canonical).hostname or ""

    if adapter == "pixiv" or host in PIXIV_HOSTS:
        normalized, media_id, ext = normalize_pixiv_media_url(canonical)
        return MediaItem(
            source="pixiv",
            source_url=raw_url.strip(),
            normalized_url=normalized,
            media_id=media_id,
            extension=ext,
            kind=media_kind(ext),
        )

    source_hint = None if adapter == "auto" else adapter
    return build_plan([raw_url], source_hint=source_hint)[0]


def build_adapter_plan(
    urls: Iterable[str],
    *,
    adapter: str = "auto",
) -> list[MediaItem]:
    items: list[MediaItem] = []
    seen: set[str] = set()
    for raw_url in urls:
        if not raw_url or not raw_url.strip():
            continue
        item = make_adapter_item(raw_url, adapter=adapter)
        if item.normalized_url in seen:
            continue
        seen.add(item.normalized_url)
        items.append(item)
    return items
