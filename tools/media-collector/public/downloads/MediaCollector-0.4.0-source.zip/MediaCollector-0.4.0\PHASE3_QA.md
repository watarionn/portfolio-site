# Phase 3 QA

Date: 2026-09-24

## Goal

Add source adapters without importing legacy credentials or coupling the core to site login state.

## Architecture

Browser side:
- X Browser Bridge
- Pixiv Browser Bridge
- Generic DOM Bridge

Desktop side:
- source_adapters.py converts supplied URLs into the common MediaItem model
- the existing core owns normalization, deduplication, download verification and manifests

## Privacy and credential boundary

Browser Bridges inspect only URLs already exposed in the current DOM.

They do not intentionally access:
- document.cookie
- localStorage
- sessionStorage
- authorization headers
- passwords
- access tokens
- refresh tokens

Media Collector receives only URL text.

## Pixiv decision

Pixiv master URLs are not blindly rewritten to img-original because the original file extension can differ. The adapter keeps the supplied direct pximg URL, strips query parameters for stable identity, and extracts illustration/page identity when possible.

## X decision

The X Bridge normalizes visible pbs.twimg.com/media URLs to name=orig, matching the clean normalization already covered by the desktop core.

## Generic DOM decision

The generic Bridge only emits http/https links that look like direct image/video resources. It does not follow links or crawl additional pages.

## Manifest privacy

Sensitive-looking query keys such as token, signature, credential, api_key and common cloud-signature variants are redacted only when URLs are written to manifests or displayed in the parsed Plan.

The in-memory URL remains available for the requested download, so signed media URLs can still work without persisting their secret values into output logs.

## Pixiv download header

Direct Pixiv media requests use only:

- normal Media Collector User-Agent
- Accept
- Referer: https://www.pixiv.net/

No Authorization header, Cookie header, access token or refresh token is attached.

## Automated QA

- Python compile: PASS
- Phase 1–3 tests: 33 / 33 PASS
- Browser Bridge JavaScript syntax: PASS
- Browser Bridge credential-access static scan: PASS
- manifest secret redaction: PASS
- Plan UI secret redaction: PASS
- Pixiv public Referer test: PASS

## Browser-engine runtime QA

The three Bridges were executed in headless Chrome against controlled DOM fixtures.

- X Bridge: one pbs.twimg.com image found and normalized to name=orig
- Pixiv Bridge: one i.pximg.net image found; query removed
- Generic DOM Bridge: image, video and direct image link found; non-media page link ignored
- overall result: PASS

## Visual QA

- real application screenshot: qa/screenshots/phase3-main.png
- capture method: direct target-window PrintWindow
- screenshot size: 1216 x 839
- X / Pixiv / Generic sources shown together
- no taskbar or overlapping application window
