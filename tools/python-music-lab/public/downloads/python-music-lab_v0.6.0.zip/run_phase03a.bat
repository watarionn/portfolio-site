@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run setup.bat first.
  exit /b 1
)
.venv\Scripts\python.exe src\phase03a_render_wav.py
if errorlevel 1 (
  echo Phase 03A render failed.
  exit /b 1
)
echo.
echo Phase 03A complete. See output\phase03a\manifest.json
endlocal
