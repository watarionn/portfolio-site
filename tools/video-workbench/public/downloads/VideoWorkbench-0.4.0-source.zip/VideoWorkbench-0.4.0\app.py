from __future__ import annotations

import os
import threading
import traceback
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from video_workbench_core import (
    VideoWorkbenchError,
    describe_media,
    export_frames,
    format_time,
    parse_time,
    probe_media,
    trim_video,
)


VIDEO_TYPES = [
    ("動画ファイル", "*.mp4 *.mov *.mkv *.webm *.avi *.m4v"),
    ("すべてのファイル", "*.*"),
]


class VideoWorkbenchApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Video Workbench")
        self.root.geometry("1120x760")
        self.root.minsize(980, 680)
        self.input_var = tk.StringVar()
        self.status_var = tk.StringVar(value="動画を選択してください")
        self.meta_vars = {
            key: tk.StringVar(value="—")
            for key in ("duration", "resolution", "fps", "streams", "size")
        }

        self.trim_start = tk.StringVar(value="0")
        self.trim_end = tk.StringVar(value="10")
        self.trim_precise = tk.BooleanVar(value=False)
        self.trim_output = tk.StringVar()
        self.trim_overwrite = tk.BooleanVar(value=False)

        self.frame_format = tk.StringVar(value="png")
        self.frame_mode = tk.StringVar(value="fps")
        self.frame_fps = tk.StringVar(value="1")
        self.frame_quality = tk.StringVar(value="2")
        self.frame_output = tk.StringVar()
        self.frame_overwrite = tk.BooleanVar(value=False)

        self.trim_summary_var = tk.StringVar(value="選択範囲: 動画読み込み後に表示")
        self.trim_mode_note_var = tk.StringVar()
        self.frame_summary_var = tk.StringVar(value="予想枚数: 動画読み込み後に表示")
        self.current_media = None

        self._busy = False
        self._build_ui()
        self._bind_live_updates()
        self._sync_trim_mode()
        self._sync_frame_mode()
    def _build_ui(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(2, weight=1)
        self.root.rowconfigure(4, weight=1)

        source = ttk.LabelFrame(self.root, text="入力動画", padding=12)
        source.grid(row=0, column=0, sticky="ew", padx=14, pady=(14, 8))
        source.columnconfigure(1, weight=1)

        ttk.Label(source, text="ファイル").grid(row=0, column=0, sticky="w")
        ttk.Entry(source, textvariable=self.input_var).grid(
            row=0, column=1, sticky="ew", padx=8
        )
        ttk.Button(source, text="選択", command=self.browse_input).grid(
            row=0, column=2, padx=(0, 6)
        )
        ttk.Button(source, text="解析", command=self.inspect_input).grid(
            row=0, column=3
        )
        ttk.Button(source, text="動画を開く", command=self.open_input).grid(
            row=0, column=4, padx=(6, 0)
        )

        meta = ttk.Frame(source)
        meta.grid(row=1, column=0, columnspan=5, sticky="ew", pady=(12, 0))
        labels = [
            ("長さ", "duration"),
            ("解像度", "resolution"),
            ("FPS", "fps"),
            ("ストリーム", "streams"),
            ("サイズ", "size"),
        ]
        for index, (label, key) in enumerate(labels):
            block = ttk.Frame(meta)
            block.grid(row=0, column=index, sticky="w", padx=(0, 28))
            ttk.Label(block, text=label).grid(row=0, column=0, sticky="w")
            ttk.Label(
                block,
                textvariable=self.meta_vars[key],
                font=("Segoe UI", 10, "bold"),
            ).grid(row=1, column=0, sticky="w")

        work = ttk.Frame(self.root)
        work.grid(row=2, column=0, sticky="nsew", padx=14, pady=8)
        work.columnconfigure(0, weight=1)
        work.columnconfigure(1, weight=1)
        work.rowconfigure(0, weight=1)

        self._build_trim_panel(work)
        self._build_frame_panel(work)
    def _build_trim_panel(self, parent: ttk.Frame) -> None:
        panel = ttk.LabelFrame(parent, text="範囲カット", padding=14)
        panel.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        panel.columnconfigure(1, weight=1)

        ttk.Label(panel, text="開始").grid(row=0, column=0, sticky="w", pady=4)
        ttk.Entry(panel, textvariable=self.trim_start).grid(
            row=0, column=1, sticky="ew", pady=4
        )
        ttk.Label(panel, text="秒 / MM:SS / HH:MM:SS").grid(
            row=0, column=2, sticky="w", padx=(8, 0)
        )
        ttk.Button(panel, text="0秒", command=self.set_trim_start_zero).grid(
            row=0, column=3, padx=(8, 0)
        )

        ttk.Label(panel, text="終了").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(panel, textvariable=self.trim_end).grid(
            row=1, column=1, sticky="ew", pady=4
        )
        ttk.Button(panel, text="動画末尾", command=self.set_trim_end_to_duration).grid(
            row=1, column=3, padx=(8, 0)
        )

        ttk.Label(panel, text="方式").grid(row=2, column=0, sticky="nw", pady=8)
        modes = ttk.Frame(panel)
        modes.grid(row=2, column=1, columnspan=2, sticky="w", pady=8)
        ttk.Radiobutton(
            modes,
            text="高速カット（コピー / 位置は近似）",
            variable=self.trim_precise,
            value=False,
            command=self._sync_trim_mode,
        ).grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(
            modes,
            text="正確カット（再エンコード）",
            variable=self.trim_precise,
            value=True,
            command=self._sync_trim_mode,
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Label(
            modes,
            textvariable=self.trim_mode_note_var,
            wraplength=420,
        ).grid(row=2, column=0, sticky="w", pady=(6, 0))

        ttk.Label(panel, text="出力").grid(row=3, column=0, sticky="w", pady=4)
        ttk.Entry(panel, textvariable=self.trim_output).grid(
            row=3, column=1, sticky="ew", pady=4
        )
        ttk.Button(panel, text="指定", command=self.browse_trim_output).grid(
            row=3, column=2, padx=(8, 0)
        )

        ttk.Label(
            panel,
            text="空欄なら入力動画の隣に自動命名します。",
        ).grid(row=4, column=1, columnspan=2, sticky="w")

        ttk.Checkbutton(
            panel,
            text="既存ファイルを上書きする",
            variable=self.trim_overwrite,
        ).grid(row=5, column=1, columnspan=3, sticky="w", pady=(12, 4))
        ttk.Label(
            panel,
            textvariable=self.trim_summary_var,
            font=("Segoe UI", 9, "bold"),
        ).grid(row=6, column=0, columnspan=4, sticky="w", pady=(8, 0))
        ttk.Button(
            panel,
            text="この範囲を書き出す",
            command=self.run_trim,
        ).grid(row=7, column=0, columnspan=4, sticky="ew", pady=(14, 0))

    def _build_frame_panel(self, parent: ttk.Frame) -> None:
        panel = ttk.LabelFrame(parent, text="フレーム書き出し", padding=14)
        panel.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        panel.columnconfigure(1, weight=1)

        ttk.Label(panel, text="形式").grid(row=0, column=0, sticky="w", pady=4)
        self.frame_format_combo = ttk.Combobox(
            panel,
            textvariable=self.frame_format,
            values=("png", "jpg"),
            state="readonly",
            width=10,
        )
        self.frame_format_combo.grid(row=0, column=1, sticky="w", pady=4)
        self.frame_format_combo.bind(
            "<<ComboboxSelected>>",
            lambda _event: self._sync_frame_mode(),
        )

        ttk.Label(panel, text="出力頻度").grid(
            row=1, column=0, sticky="w", pady=4
        )
        mode_frame = ttk.Frame(panel)
        mode_frame.grid(row=1, column=1, columnspan=2, sticky="w", pady=4)
        ttk.Radiobutton(
            mode_frame,
            text="FPS指定",
            variable=self.frame_mode,
            value="fps",
            command=self._sync_frame_mode,
        ).grid(row=0, column=0)
        ttk.Radiobutton(
            mode_frame,
            text="全フレーム",
            variable=self.frame_mode,
            value="all",
            command=self._sync_frame_mode,
        ).grid(row=0, column=1, padx=(14, 0))

        ttk.Label(panel, text="FPS").grid(row=2, column=0, sticky="w", pady=4)
        self.frame_fps_entry = ttk.Combobox(
            panel,
            textvariable=self.frame_fps,
            values=("0.5", "1", "2", "5", "10", "30"),
        )
        self.frame_fps_entry.grid(row=2, column=1, sticky="ew", pady=4)

        ttk.Label(panel, text="JPG品質").grid(
            row=3, column=0, sticky="w", pady=4
        )
        self.frame_quality_spin = ttk.Spinbox(
            panel,
            from_=2,
            to=31,
            textvariable=self.frame_quality,
            width=8,
        )
        self.frame_quality_spin.grid(row=3, column=1, sticky="w", pady=4)
        ttk.Label(panel, text="2が高画質、31が低画質").grid(
            row=3, column=2, sticky="w", padx=(8, 0)
        )

        ttk.Label(panel, text="出力").grid(row=4, column=0, sticky="w", pady=4)
        ttk.Entry(panel, textvariable=self.frame_output).grid(
            row=4, column=1, sticky="ew", pady=4
        )
        ttk.Button(panel, text="指定", command=self.browse_frame_output).grid(
            row=4, column=2, padx=(8, 0)
        )
        ttk.Label(
            panel,
            text="空欄なら入力動画の隣に自動フォルダを作ります。",
        ).grid(row=5, column=1, columnspan=2, sticky="w")

        ttk.Checkbutton(
            panel,
            text="既存フォルダ内への上書きを許可する",
            variable=self.frame_overwrite,
        ).grid(row=6, column=1, columnspan=2, sticky="w", pady=(12, 4))
        ttk.Label(
            panel,
            textvariable=self.frame_summary_var,
            font=("Segoe UI", 9, "bold"),
        ).grid(row=7, column=0, columnspan=3, sticky="w", pady=(8, 0))

        ttk.Button(
            panel,
            text="フレームを書き出す",
            command=self.run_frames,
        ).grid(row=8, column=0, columnspan=3, sticky="ew", pady=(14, 0))

    def _build_log_area(self) -> None:
        pass
        # kept for compatibility with early Phase 2 drafts

    def _finish_ui(self) -> None:
        pass

    def browse_input(self) -> None:
        selected = filedialog.askopenfilename(filetypes=VIDEO_TYPES)
        if selected:
            self.input_var.set(selected)
            self.current_media = None
            self.trim_output.set("")
            self.frame_output.set("")
            self._refresh_summaries()
            self.inspect_input()

    def browse_trim_output(self) -> None:
        selected = filedialog.asksaveasfilename(
            defaultextension=".mp4",
            filetypes=[
                ("MP4", "*.mp4"),
                ("Matroska", "*.mkv"),
                ("QuickTime", "*.mov"),
                ("すべてのファイル", "*.*"),
            ],
        )
        if selected:
            self.trim_output.set(selected)

    def browse_frame_output(self) -> None:
        selected = filedialog.askdirectory()
        if selected:
            self.frame_output.set(selected)

    def open_input(self) -> None:
        source = self.input_var.get().strip()
        if not source:
            messagebox.showinfo("Video Workbench", "動画を選択してください。")
            return
        path = Path(source).expanduser()
        if not path.is_file():
            messagebox.showerror("Video Workbench", f"動画が見つかりません: {path}")
            return
        try:
            os.startfile(path)
        except OSError as exc:
            messagebox.showerror("Video Workbench", str(exc))

    def set_trim_start_zero(self) -> None:
        self.trim_start.set("0")

    def set_trim_end_to_duration(self) -> None:
        if self.current_media is None:
            messagebox.showinfo("Video Workbench", "先に動画を解析してください。")
            return
        self.trim_end.set(format_time(self.current_media.duration))

    def _bind_live_updates(self) -> None:
        self.input_var.trace_add("write", lambda *_args: self._input_changed())
        for variable in (
            self.trim_start,
            self.trim_end,
            self.frame_fps,
            self.frame_mode,
            self.frame_format,
        ):
            variable.trace_add("write", lambda *_args: self._refresh_summaries())

    def _input_changed(self) -> None:
        if self.current_media is not None:
            current = str(self.current_media.path)
            incoming = self.input_var.get().strip()
            if incoming == current:
                return
        self.current_media = None
        for value in self.meta_vars.values():
            value.set("—")
        self._refresh_summaries()

    def _sync_trim_mode(self) -> None:
        if self.trim_precise.get():
            self.trim_mode_note_var.set(
                "指定時刻に合わせて再エンコードします。時間精度を優先するとき向けです。"
            )
        else:
            self.trim_mode_note_var.set(
                "映像・音声をコピーするため高速です。キーフレームの位置で前後する場合があります。"
            )
        self._refresh_summaries()

    def _sync_frame_mode(self) -> None:
        fps_state = "normal" if self.frame_mode.get() == "fps" else "disabled"
        self.frame_fps_entry.configure(state=fps_state)
        quality_state = "normal" if self.frame_format.get() == "jpg" else "disabled"
        self.frame_quality_spin.configure(state=quality_state)
        self._refresh_summaries()

    def _refresh_summaries(self) -> None:
        media = self.current_media
        if media is None:
            self.trim_summary_var.set("選択範囲: 動画読み込み後に表示")
            self.frame_summary_var.set("予想枚数: 動画読み込み後に表示")
            return

        try:
            start = parse_time(self.trim_start.get())
            end = parse_time(self.trim_end.get())
            if end <= start:
                raise ValueError
            selected = end - start
            if start >= media.duration:
                self.trim_summary_var.set("選択範囲: 開始位置が動画末尾より後です")
            elif end > media.duration + 0.25:
                self.trim_summary_var.set("選択範囲: 終了位置が動画末尾を超えています")
            else:
                self.trim_summary_var.set(
                    f"選択範囲: {format_time(selected)}  "
                    f"({format_time(start)} → {format_time(end)})"
                )
        except (ValueError, TypeError):
            self.trim_summary_var.set("選択範囲: 時間指定を確認してください")

        if self.frame_mode.get() == "all":
            if media.fps:
                estimate = max(1, round(media.duration * media.fps))
                self.frame_summary_var.set(
                    f"予想枚数: 約 {estimate:,} 枚（全フレーム）"
                )
            else:
                self.frame_summary_var.set("予想枚数: 全フレーム")
            return

        try:
            fps = float(self.frame_fps.get())
            if fps <= 0:
                raise ValueError
            estimate = max(1, round(media.duration * fps))
            self.frame_summary_var.set(
                f"予想枚数: 約 {estimate:,} 枚（{fps:g} fps）"
            )
        except ValueError:
            self.frame_summary_var.set("予想枚数: FPSを確認してください")

    def _set_busy(self, busy: bool, label: str | None = None) -> None:
        self._busy = busy
        if busy:
            self.status_var.set(label or "処理中…")
            self.progress.start(12)
        else:
            self.progress.stop()
            if label:
                self.status_var.set(label)

    def _log(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", text.rstrip() + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _run_background(self, label: str, worker, success) -> None:
        if self._busy:
            messagebox.showinfo("Video Workbench", "別の処理が実行中です。")
            return
        self._set_busy(True, label)
        def job() -> None:
            try:
                result = worker()
            except Exception as exc:
                trace = traceback.format_exc()
                self.root.after(0, lambda: self._task_failed(exc, trace))
                return
            self.root.after(0, lambda: self._task_succeeded(result, success))

        threading.Thread(target=job, daemon=True).start()

    def _task_failed(self, exc: Exception, trace: str) -> None:
        self._set_busy(False, "失敗")
        self._log(f"[ERROR] {exc}")
        if not isinstance(
            exc,
            (ValueError, FileNotFoundError, FileExistsError, VideoWorkbenchError),
        ):
            self._log(trace)
        messagebox.showerror("Video Workbench", str(exc))

    def _task_succeeded(self, result, success) -> None:
        try:
            success(result)
        finally:
            self._set_busy(False, "完了")

    def inspect_input(self) -> None:
        source = self.input_var.get().strip()
        if not source:
            messagebox.showinfo("Video Workbench", "動画を選択してください。")
            return

        def success(media) -> None:
            self.current_media = media
            values = describe_media(media)
            for key, value in values.items():
                self.meta_vars[key].set(value)
            if self.trim_end.get().strip() in {"", "10"}:
                self.trim_end.set(format_time(media.duration))
            self._refresh_summaries()
            self._log(
                f"[INFO] 読み込み: {media.path.name} / {values['duration']}"
            )

        self._run_background(
            "動画を解析中…",
            lambda: probe_media(source),
            success,
        )

    def run_trim(self) -> None:
        source = self.input_var.get().strip()
        start = self.trim_start.get().strip()
        end = self.trim_end.get().strip()
        output = self.trim_output.get().strip() or None
        precise = self.trim_precise.get()
        overwrite = self.trim_overwrite.get()

        def worker():
            return trim_video(
                source,
                start,
                end,
                output_file=output,
                precise=precise,
                overwrite=overwrite,
            )

        def success(result) -> None:
            path, info = result
            mode = "正確" if precise else "高速"
            self._log(
                f"[OK] {mode}カット: {path} / 出力長 {info.duration:.3f} 秒"
            )
            self._remember_output(path)

        self._run_background("動画を書き出し中…", worker, success)

    def run_frames(self) -> None:
        source = self.input_var.get().strip()
        output = self.frame_output.get().strip() or None
        image_format = self.frame_format.get()
        overwrite = self.frame_overwrite.get()
        try:
            quality = int(self.frame_quality.get())
            fps = (
                float(self.frame_fps.get())
                if self.frame_mode.get() == "fps"
                else None
            )
        except ValueError:
            messagebox.showerror(
                "Video Workbench",
                "FPSとJPG品質は数値で入力してください。",
            )
            return

        def worker():
            return export_frames(
                source,
                image_format=image_format,
                fps=fps,
                output_dir=output,
                jpg_quality=quality,
                overwrite=overwrite,
            )

        def success(result) -> None:
            path, count = result
            self._log(f"[OK] フレーム書き出し: {path} / {count} 枚")
            self._remember_output(path)
        self._run_background("フレームを書き出し中…", worker, success)

    def _remember_output(self, path: Path) -> None:
        self.last_output = path

    def open_last_output(self) -> None:
        path = getattr(self, "last_output", None)
        if not path:
            messagebox.showinfo("Video Workbench", "まだ出力がありません。")
            return
        target = path if path.is_dir() else path.parent
        try:
            os.startfile(target)
        except OSError as exc:
            messagebox.showerror("Video Workbench", str(exc))

    def clear_log(self) -> None:
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")


def attach_footer(app: VideoWorkbenchApp) -> None:
    footer = ttk.Frame(app.root)
    footer.grid(row=3, column=0, sticky="ew", padx=14, pady=(4, 8))
    footer.columnconfigure(1, weight=1)
    app.progress = ttk.Progressbar(
        footer,
        mode="indeterminate",
        length=180,
    )
    app.progress.grid(row=0, column=0, padx=(0, 10))
    ttk.Label(footer, textvariable=app.status_var).grid(
        row=0, column=1, sticky="w"
    )
    ttk.Button(
        footer,
        text="出力先を開く",
        command=app.open_last_output,
    ).grid(row=0, column=2, padx=(8, 0))

    log_frame = ttk.LabelFrame(app.root, text="処理ログ", padding=8)
    log_frame.grid(
        row=4,
        column=0,
        sticky="nsew",
        padx=14,
        pady=(0, 14),
    )
    log_frame.columnconfigure(0, weight=1)
    log_frame.rowconfigure(0, weight=1)
    app.log = tk.Text(
        log_frame,
        height=9,
        wrap="word",
        state="disabled",
        font=("Consolas", 9),
    )
    app.log.grid(row=0, column=0, sticky="nsew")
    scroll = ttk.Scrollbar(
        log_frame,
        orient="vertical",
        command=app.log.yview,
    )
    scroll.grid(row=0, column=1, sticky="ns")
    app.log.configure(yscrollcommand=scroll.set)
    ttk.Button(
        log_frame,
        text="ログを消す",
        command=app.clear_log,
    ).grid(row=1, column=0, sticky="e", pady=(6, 0))


def configure_style(root: tk.Tk) -> None:
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    style.configure("TButton", padding=(8, 5))
    style.configure("TLabelframe.Label", font=("Segoe UI", 10, "bold"))
def main() -> None:
    root = tk.Tk()
    configure_style(root)
    app = VideoWorkbenchApp(root)
    attach_footer(app)
    root.mainloop()


if __name__ == "__main__":
    main()
