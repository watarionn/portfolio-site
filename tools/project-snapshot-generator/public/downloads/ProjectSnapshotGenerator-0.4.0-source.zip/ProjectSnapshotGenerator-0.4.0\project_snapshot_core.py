from __future__ import annotations

import fnmatch
import os
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path


DEFAULT_EXCLUDE_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    ".next",
    ".cache",
}

GENERATED_DIR_CANDIDATES = {
    ".venv",
    "venv",
    "__pycache__",
    "node_modules",
    ".next",
    ".cache",
    "dist",
    "build",
    "coverage",
}


class SnapshotError(RuntimeError):
    pass


@dataclass(frozen=True)
class FileInfo:
    relative_path: str
    size_bytes: int
    extension: str


@dataclass
class DirectoryInfo:
    name: str
    relative_path: str
    size_bytes: int = 0
    file_count: int = 0
    children: list["DirectoryInfo"] = field(default_factory=list)
    files: list[FileInfo] = field(default_factory=list)


@dataclass(frozen=True)
class ScanIssue:
    relative_path: str
    message: str


@dataclass
class Snapshot:
    root: Path
    root_node: DirectoryInfo
    total_files: int
    total_dirs: int
    total_bytes: int
    extensions: Counter[str]
    largest_files: list[FileInfo]
    skipped_paths: list[str]
    issues: list[ScanIssue]
    gitignore_candidates: list[str]


def format_size(size: int) -> str:
    value = float(size)
    units = ("B", "KB", "MB", "GB", "TB")
    for unit in units:
        if value < 1024 or unit == units[-1]:
            if unit == "B":
                return f"{int(value)} B"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{size} B"


def _extension_for(path: Path) -> str:
    if not path.suffix:
        return "(no extension)"
    return path.suffix.lower()


def _read_gitignore_literals(root: Path) -> set[str]:
    path = root / ".gitignore"
    if not path.is_file():
        return set()
    patterns: set[str] = set()
    try:
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("!"):
                continue
            normalized = line.strip("/")
            if normalized and not any(ch in normalized for ch in "*?[]"):
                patterns.add(normalized.replace("\\", "/"))
    except OSError:
        return set()
    return patterns


def _is_excluded(name: str, relative: str, excludes: set[str]) -> bool:
    if name in excludes:
        return True
    rel = relative.replace("\\", "/")
    return any(fnmatch.fnmatch(rel, pattern) for pattern in excludes if "/" in pattern)


def scan_project(
    root: str | Path,
    *,
    include_files_in_tree: bool = True,
    exclude_dirs: set[str] | None = None,
    largest_limit: int = 20,
    large_file_threshold: int = 10 * 1024 * 1024,
) -> Snapshot:
    root_path = Path(root).expanduser().resolve()
    if not root_path.is_dir():
        raise SnapshotError(f"Project folder not found: {root_path}")

    excludes = set(DEFAULT_EXCLUDE_DIRS if exclude_dirs is None else exclude_dirs)
    extension_counts: Counter[str] = Counter()
    all_files: list[FileInfo] = []
    skipped: list[str] = []
    issues: list[ScanIssue] = []
    discovered_generated_dirs: set[str] = set()

    def walk(directory: Path, relative: Path) -> DirectoryInfo:
        nonlocal extension_counts
        node = DirectoryInfo(
            name=directory.name if relative.parts else root_path.name,
            relative_path="." if not relative.parts else relative.as_posix(),
        )
        try:
            entries = sorted(os.scandir(directory), key=lambda e: e.name.lower())
        except OSError as exc:
            issues.append(ScanIssue(node.relative_path, str(exc)))
            return node

        for entry in entries:
            child_rel = relative / entry.name
            rel_text = child_rel.as_posix()
            try:
                if entry.is_symlink():
                    skipped.append(f"{rel_text} (symlink)")
                    continue

                if entry.is_dir(follow_symlinks=False):
                    if entry.name in GENERATED_DIR_CANDIDATES:
                        discovered_generated_dirs.add(entry.name)
                    if _is_excluded(entry.name, rel_text, excludes):
                        skipped.append(f"{rel_text}/")
                        continue
                    child = walk(Path(entry.path), child_rel)
                    node.children.append(child)
                    node.size_bytes += child.size_bytes
                    node.file_count += child.file_count
                    continue

                if not entry.is_file(follow_symlinks=False):
                    skipped.append(f"{rel_text} (special)")
                    continue

                try:
                    stat = entry.stat(follow_symlinks=False)
                except OSError as exc:
                    issues.append(ScanIssue(rel_text, str(exc)))
                    continue

                info = FileInfo(
                    relative_path=rel_text,
                    size_bytes=int(stat.st_size),
                    extension=_extension_for(Path(entry.name)),
                )
                all_files.append(info)
                extension_counts[info.extension] += 1
                node.size_bytes += info.size_bytes
                node.file_count += 1
                if include_files_in_tree:
                    node.files.append(info)
            except OSError as exc:
                issues.append(ScanIssue(rel_text, str(exc)))
        return node

    root_node = walk(root_path, Path())
    existing_gitignore = _read_gitignore_literals(root_path)
    candidates = sorted(
        name
        for name in discovered_generated_dirs
        if name not in existing_gitignore
    )
    large_files = sorted(
        (f for f in all_files if f.size_bytes >= large_file_threshold),
        key=lambda f: (-f.size_bytes, f.relative_path.lower()),
    )[:largest_limit]

    def count_dirs(node: DirectoryInfo) -> int:
        return sum(1 + count_dirs(child) for child in node.children)

    return Snapshot(
        root=root_path,
        root_node=root_node,
        total_files=root_node.file_count,
        total_dirs=count_dirs(root_node),
        total_bytes=root_node.size_bytes,
        extensions=extension_counts,
        largest_files=large_files,
        skipped_paths=skipped,
        issues=issues,
        gitignore_candidates=candidates,
    )


def _tree_lines(node: DirectoryInfo, *, include_files: bool, depth: int = 0) -> list[str]:
    indent = "  " * depth
    label = f"{indent}- {node.name}/  ({node.file_count} files, {format_size(node.size_bytes)})"
    lines = [label]
    for child in node.children:
        lines.extend(_tree_lines(child, include_files=include_files, depth=depth + 1))
    if include_files:
        for file in node.files:
            lines.append(
                f"{'  ' * (depth + 1)}- {Path(file.relative_path).name}  ({format_size(file.size_bytes)})"
            )
    return lines


def render_markdown(snapshot: Snapshot, *, include_files_in_tree: bool = True) -> str:
    lines = [
        f"# Project Snapshot: {snapshot.root.name}",
        "",
        f"- Root: `{snapshot.root}`",
        f"- Directories: {snapshot.total_dirs:,}",
        f"- Files: {snapshot.total_files:,}",
        f"- Total size: {format_size(snapshot.total_bytes)}",
        f"- Skipped paths: {len(snapshot.skipped_paths):,}",
        f"- Scan issues: {len(snapshot.issues):,}",
        "",
        "## Tree",
        "",
    ]
    lines.extend(_tree_lines(snapshot.root_node, include_files=include_files_in_tree))

    lines += ["", "## Extension breakdown", "", "| Extension | Files |", "| --- | ---: |"]
    if snapshot.extensions:
        for ext, count in sorted(snapshot.extensions.items(), key=lambda x: (-x[1], x[0])):
            lines.append(f"| `{ext}` | {count:,} |")
    else:
        lines.append("| (none) | 0 |")

    lines += ["", "## Large files", ""]
    if snapshot.largest_files:
        lines += ["| Path | Size |", "| --- | ---: |"]
        for file in snapshot.largest_files:
            lines.append(f"| `{file.relative_path}` | {format_size(file.size_bytes)} |")
    else:
        lines.append("No files exceeded the large-file threshold.")

    lines += ["", "## Git ignore candidates", ""]
    if snapshot.gitignore_candidates:
        lines.extend(f"- `{name}/`" for name in snapshot.gitignore_candidates)
    else:
        lines.append("No new common generated-directory candidates were found.")

    lines += ["", "## Skipped paths", ""]
    if snapshot.skipped_paths:
        lines.extend(f"- `{item}`" for item in snapshot.skipped_paths)
    else:
        lines.append("None.")

    lines += ["", "## Scan issues", ""]
    if snapshot.issues:
        lines.extend(f"- `{issue.relative_path}`: {issue.message}" for issue in snapshot.issues)
    else:
        lines.append("None.")

    return "\n".join(lines).rstrip() + "\n"


def default_output_path(root: str | Path) -> Path:
    root_path = Path(root).expanduser().resolve()
    safe = "".join("_" if ch in '\\/:*?"<>|' else ch for ch in root_path.name)
    return root_path.parent / f"snapshot_{safe}.md"


def write_snapshot_report(
    snapshot: Snapshot,
    output: str | Path,
    *,
    include_files_in_tree: bool = True,
    overwrite: bool = False,
) -> Path:
    output_path = Path(output).expanduser().resolve()
    if output_path.exists() and not overwrite:
        raise FileExistsError(f"Output already exists: {output_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        render_markdown(snapshot, include_files_in_tree=include_files_in_tree),
        encoding="utf-8",
        newline="\n",
    )
    return output_path


def write_snapshot(
    root: str | Path,
    *,
    output: str | Path | None = None,
    include_files_in_tree: bool = True,
    overwrite: bool = False,
) -> tuple[Path, Snapshot]:
    snapshot = scan_project(root, include_files_in_tree=include_files_in_tree)
    output_path = (
        Path(output).expanduser().resolve()
        if output is not None
        else default_output_path(root)
    )
    output_path = write_snapshot_report(
        snapshot,
        output_path,
        include_files_in_tree=include_files_in_tree,
        overwrite=overwrite,
    )
    return output_path, snapshot
