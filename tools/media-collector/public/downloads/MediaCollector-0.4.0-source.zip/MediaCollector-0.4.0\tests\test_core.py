from __future__ import annotations

import io
import json
import tempfile
import unittest
from email.message import Message
from pathlib import Path

from media_collector_core import (
    MediaCollectorError,
    build_plan,
    build_plan_from_text,
    canonicalize_url,
    download_plan,
    extract_urls,
    normalize_x_media_url,
    redact_url_for_manifest,
    safe_component,
    suggested_filename,
    write_plan_manifest,
)


class FakeResponse:
    def __init__(self, body: bytes, content_type: str, content_length: int | None = None):
        self._stream = io.BytesIO(body)
        self.headers = Message()
        self.headers["Content-Type"] = content_type
        if content_length is not None:
            self.headers["Content-Length"] = str(content_length)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self, size=-1):
        return self._stream.read(size)


class CoreTests(unittest.TestCase):
    def test_x_current_url_normalizes_to_orig(self):
        url, media_id, ext = normalize_x_media_url(
            "https://pbs.twimg.com/media/ABC123?format=png&name=small"
        )
        self.assertEqual(
            url,
            "https://pbs.twimg.com/media/ABC123?format=png&name=orig",
        )
        self.assertEqual(media_id, "ABC123")
        self.assertEqual(ext, "png")

    def test_x_legacy_url_normalizes(self):
        url, media_id, ext = normalize_x_media_url(
            "https://pbs.twimg.com/media/XYZ999.jpg:large"
        )
        self.assertEqual(
            url,
            "https://pbs.twimg.com/media/XYZ999?format=jpg&name=orig",
        )
        self.assertEqual(media_id, "XYZ999")
        self.assertEqual(ext, "jpg")

    def test_non_x_url_rejected_by_x_normalizer(self):
        with self.assertRaises(MediaCollectorError):
            normalize_x_media_url("https://example.com/image.jpg")

    def test_canonicalize_removes_fragment(self):
        self.assertEqual(
            canonicalize_url("HTTPS://Example.COM/a.png?x=1#part"),
            "https://example.com/a.png?x=1",
        )

    def test_extract_urls_from_mixed_text(self):
        text = "name\thttps://example.com/a.jpg\nnext,https://example.com/b.png"
        self.assertEqual(
            extract_urls(text),
            ["https://example.com/a.jpg", "https://example.com/b.png"],
        )

    def test_build_plan_deduplicates_normalized_x_urls(self):
        plan = build_plan(
            [
                "https://pbs.twimg.com/media/A?format=jpg&name=small",
                "https://pbs.twimg.com/media/A?format=jpg&name=orig",
            ]
        )
        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0].source, "x")

    def test_build_plan_from_text_tracks_generic_media(self):
        plan = build_plan_from_text("https://example.com/path/photo.webp")
        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0].media_id, "photo")
        self.assertEqual(plan[0].extension, "webp")
        self.assertEqual(plan[0].kind, "image")

    def test_safe_component(self):
        self.assertEqual(safe_component(" a/b:c* "), "a_b_c")

    def test_suggested_filename_is_stable(self):
        item = build_plan(["https://example.com/hello world.jpg".replace(" ", "%20")])[0]
        name = suggested_filename(item, 7)
        self.assertTrue(name.startswith("generic_000007_"))
        self.assertTrue(name.endswith(".jpg"))

    def test_plan_manifest_writes_json_and_tsv(self):
        plan = build_plan(["https://example.com/a.png"])
        with tempfile.TemporaryDirectory() as temp:
            json_path, tsv_path = write_plan_manifest(plan, Path(temp))
            self.assertTrue(json_path.exists())
            self.assertTrue(tsv_path.exists())
            data = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(data[0]["media_id"], "a")
            self.assertIn("normalized_url", tsv_path.read_text(encoding="utf-8"))

    def test_manifest_url_redaction_hides_sensitive_values(self):
        redacted = redact_url_for_manifest(
            "https://user:pass@example.com/a.jpg?token=secret&x=1&X-Amz-Signature=abcdef#part"
        )
        self.assertNotIn("user:pass@", redacted)
        self.assertIn("token=REDACTED", redacted)
        self.assertIn("X-Amz-Signature=REDACTED", redacted)
        self.assertIn("x=1", redacted)
        self.assertNotIn("secret", redacted)
        self.assertNotIn("abcdef", redacted)

    def test_plan_manifest_redacts_sensitive_query_values(self):
        plan = build_plan(
            ["https://example.com/a.jpg?token=secret&safe=yes"]
        )
        with tempfile.TemporaryDirectory() as temp:
            json_path, tsv_path = write_plan_manifest(plan, Path(temp))
            json_text = json_path.read_text(encoding="utf-8")
            tsv_text = tsv_path.read_text(encoding="utf-8")
            self.assertNotIn("secret", json_text)
            self.assertNotIn("secret", tsv_text)
            self.assertIn("REDACTED", json_text)
            self.assertIn("REDACTED", tsv_text)
            self.assertIn("safe=yes", json_text)

    def test_download_saves_valid_image(self):
        plan = build_plan(["https://example.com/a.jpg"])
        body = b"\xff\xd8\xff\xe0fake-jpeg-bytes"

        def opener(_request, timeout):
            self.assertEqual(timeout, 30.0)
            return FakeResponse(body, "image/jpeg", len(body))

        with tempfile.TemporaryDirectory() as temp:
            results = download_plan(plan, Path(temp), opener=opener)
            self.assertEqual(results[0].status, "saved")
            path = Path(temp) / results[0].filename
            self.assertEqual(path.read_bytes(), body)
            self.assertEqual(results[0].size_bytes, len(body))
            self.assertEqual(len(results[0].sha256), 64)

    def test_download_rejects_html(self):
        plan = build_plan(["https://example.com/a.jpg"])

        def opener(_request, timeout):
            return FakeResponse(b"<html></html>", "text/html")

        with tempfile.TemporaryDirectory() as temp:
            results = download_plan(plan, Path(temp), opener=opener)
            self.assertEqual(results[0].status, "error")
            self.assertIn("content type", results[0].error)

    def test_download_respects_declared_size_limit(self):
        plan = build_plan(["https://example.com/a.jpg"])

        def opener(_request, timeout):
            return FakeResponse(b"x", "image/jpeg", 999)

        with tempfile.TemporaryDirectory() as temp:
            results = download_plan(plan, Path(temp), max_bytes=10, opener=opener)
            self.assertEqual(results[0].status, "error")
            self.assertIn("exceeds limit", results[0].error)

    def test_content_duplicate_is_not_saved_twice(self):
        plan = build_plan(
            [
                "https://example.com/a.jpg",
                "https://example.com/b.jpg",
            ]
        )

        def opener(_request, timeout):
            return FakeResponse(b"\xff\xd8\xff\xe0same-bytes", "image/jpeg")

        with tempfile.TemporaryDirectory() as temp:
            results = download_plan(plan, Path(temp), opener=opener)
            self.assertEqual(results[0].status, "saved")
            self.assertEqual(results[1].status, "duplicate-content")
            files = [p for p in Path(temp).iterdir() if p.is_file()]
            self.assertEqual(len(files), 1)

    def test_mislabeled_image_signature_is_rejected(self):
        plan = build_plan(["https://example.com/fake.png"])

        def opener(_request, timeout):
            return FakeResponse(b"<html>not a png</html>", "image/png")

        with tempfile.TemporaryDirectory() as temp:
            results = download_plan(plan, Path(temp), opener=opener)
            self.assertEqual(results[0].status, "error")
            self.assertIn("signature", results[0].error)

    def test_empty_media_is_rejected(self):
        plan = build_plan(["https://example.com/empty.jpg"])

        def opener(_request, timeout):
            return FakeResponse(b"", "image/jpeg")

        with tempfile.TemporaryDirectory() as temp:
            results = download_plan(plan, Path(temp), opener=opener)
            self.assertEqual(results[0].status, "error")
            self.assertIn("empty", results[0].error)

    def test_video_is_skipped_by_default(self):
        plan = build_plan(["https://example.com/a.mp4"])
        with tempfile.TemporaryDirectory() as temp:
            results = download_plan(plan, Path(temp))
            self.assertEqual(results[0].status, "skipped")


if __name__ == "__main__":
    unittest.main()
