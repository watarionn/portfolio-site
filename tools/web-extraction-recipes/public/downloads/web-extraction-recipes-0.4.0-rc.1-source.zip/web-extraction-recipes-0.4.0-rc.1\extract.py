from __future__ import annotations

import argparse
from pathlib import Path

from extraction_core import extract_records, load_recipe, read_html_file, write_records


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Apply a JSON extraction recipe to a local HTML file."
    )
    parser.add_argument("html", type=Path)
    parser.add_argument("recipe", type=Path)
    parser.add_argument("-o", "--output", type=Path, required=True)
    parser.add_argument(
        "--format",
        choices=("tsv", "csv", "json"),
        default=None,
        help="Override output format; otherwise inferred from extension.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    recipe = load_recipe(args.recipe)
    html_text = read_html_file(args.html)
    records = extract_records(html_text, recipe)
    write_records(records, args.output, format_name=args.format)
    print(f"Recipe : {recipe.name}")
    print(f"Rows   : {len(records)}")
    print(f"Output : {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
