# Phase 1 QA

Date: 2026-09-25

## Goal

Build a clean Download Workbench core from the mature ytdlp_desktop concept without importing authentication state, cookies, browser profiles, provider containers, archives, logs, or historical downloads.

## Runtime baseline

- Python 3.14.5
- yt-dlp 2026.03.17
- ffmpeg 2026-06-04

## Safety decisions

- yt-dlp is always invoked with --ignore-config
- no playlist is downloaded implicitly
- existing files are not overwritten
- embedded URL credentials are rejected
- token/signature-like query values can be redacted for display/logging
- subprocess execution uses shell=False
- no Cookie / Authorization arguments are generated
- no DRM/access-control bypass logic

## Phase 1 test scope

- URL validation
- sensitive query redaction
- timecode parsing/formatting
- analysis command construction
- metadata/format/subtitle parsing
- video mode
- audio mode
- explicit format ID
- range clipping
- precise range flag
- subtitle/metadata/thumbnail flags

## Next

Phase 2 will add the Windows GUI and background analysis/download workers while keeping the clean authorization boundary unchanged.
