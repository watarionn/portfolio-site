# Phase 3 QA

Date: 2026-09-24

## Goal

Polish the Phase 2 GUI using real repositories with very different sizes and information density.

## Real-project comparison

| Project | Files | Directories | Full preview | Compact preview | Initial scan |
| --- | ---: | ---: | ---: | ---: | ---: |
| video-workbench | 35 | 6 | 1,912 bytes report | full view retained | 110 ms |
| ai-memory-vault | 996 | 161 | 47,054 chars | 6,995 chars | 174 ms baseline |
| portfolio-site | 1,974 | 367 | 95,967 chars | 15,957 chars | 468 ms baseline |

For large repositories the compact tree removes individual file lines while keeping folder aggregates, extension analysis, large files and audit sections.

Observed preview reduction:

- portfolio-site: about 83% smaller
- ai-memory-vault: about 85% smaller

## Phase 3 UX changes

- projects with 500 or more files open in Compact tree mode automatically
- projects below 500 files open in Full tree mode automatically
- project size profile: Small / Medium / Large / Very Large
- Preview shows current mode and character count
- Preview can be copied as one action
- Preview and Audit text are read-only to avoid accidental edits
- extension table now shows percentage share
- extension and large-file tables have scrollbars
- changing the large-file threshold clearly marks results as requiring re-analysis
- F5 re-runs analysis
- Ctrl+O opens the project picker
- Ctrl+S opens Markdown save
- Ctrl+Shift+C copies the full Preview
- tighter ttk spacing and table row height for desktop readability

## Automated QA

- Python compile: PASS
- Phase 1–3 tests: 20 / 20 PASS
- large-project compact auto-selection: PASS
- compact-to-full reset on next small project: PASS
- threshold stale-state notice: PASS
- extension share calculation: PASS
- read-only Preview rendering: PASS

## Visual QA artifact

- real application screenshot: `qa/screenshots/phase3-main.png`
- captured with portfolio-site loaded
- screenshot size: 1196 x 829
- generated from the running Tkinter application, not from image generation

## Product decision

The generated Markdown remains complete and deterministic. Compact vs Full affects only whether individual file lines are included in the tree. Project totals and analysis sections remain available in both modes.

No third-party Python packages are required.
