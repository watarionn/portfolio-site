param(
    [switch]$RequireCleanGit
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location -LiteralPath $root

Write-Host '== Web Extraction Recipes preflight =='
$version = (Get-Content -LiteralPath 'VERSION' -Raw).Trim()
if ($version -notmatch '^0\.4\.0-rc\.\d+$') {
    throw "Unexpected VERSION: $version"
}
Write-Host "VERSION=$version"

$required = @(
    'README.md','CHANGELOG.md','VERSION','app.py','crawl.py','crawl_core.py',
    'extract.py','extraction_core.py','run_web_extraction_recipes.bat',
    'recipes/generic_cards.json','recipes/generic_crawl.json',
    'qa/screenshots/phase3-main.png'
)
foreach ($item in $required) {
    if (-not (Test-Path -LiteralPath $item)) { throw "Missing required file: $item" }
}
Write-Host 'REQUIRED_FILES=PASS'

$pythonFiles = @('app.py','crawl.py','crawl_core.py','extract.py','extraction_core.py')
py -3 -m compileall -q @pythonFiles
if ($LASTEXITCODE -ne 0) { throw 'compileall failed' }
Write-Host 'PY_COMPILE=PASS'

py -3 -W error::ResourceWarning -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw 'unit tests failed' }
Write-Host 'UNIT_TESTS=PASS'

$runtime = Get-ChildItem -LiteralPath $root -File -Filter '*.py'
$secret = $runtime | Select-String -Pattern 'password\s*=|access_token\s*=|refresh_token\s*=|BEGIN .*PRIVATE KEY' -CaseSensitive:$false
if ($secret) { $secret | Format-Table Path,LineNumber,Line -AutoSize; throw 'secret scan failed' }
Write-Host 'SECRET_SCAN=PASS'

$auth = $runtime | Select-String -Pattern '["'']Cookie["'']\s*:|["'']Authorization["'']\s*:|add_header\(.{0,20}(Cookie|Authorization)' -CaseSensitive:$false
if ($auth) { $auth | Format-Table Path,LineNumber,Line -AutoSize; throw 'auth header scan failed' }
Write-Host 'AUTH_HEADER_SCAN=PASS'

$browser = $runtime | Select-String -Pattern 'selenium|playwright|browser_profile|cookies-from-browser' -CaseSensitive:$false
if ($browser) { $browser | Format-Table Path,LineNumber,Line -AutoSize; throw 'browser automation scan failed' }
Write-Host 'BROWSER_AUTOMATION_SCAN=PASS'

$siteSpecific = $runtime | Select-String -Pattern 'dmm\.co\.jp|fanza|shabulism\.com' -CaseSensitive:$false
if ($siteSpecific) { $siteSpecific | Format-Table Path,LineNumber,Line -AutoSize; throw 'site-specific runtime scan failed' }
Write-Host 'SITE_SPECIFIC_RUNTIME_SCAN=PASS'

$shot = 'qa/screenshots/phase3-main.png'
$expected = 'FFFEB4403393A617FC9050E732FD6D640EB5FFF7510ECBA2092AB68188E32204'
$actual = (Get-FileHash -LiteralPath $shot -Algorithm SHA256).Hash
if ($actual -ne $expected) { throw "Screenshot hash mismatch: $actual" }
Write-Host 'SCREENSHOT_HASH=PASS'

if (Test-Path -LiteralPath '.git') {
    git diff --check
    if ($LASTEXITCODE -ne 0) { throw 'git diff --check failed' }
    Write-Host 'GIT_DIFF_CHECK=PASS'
    if ($RequireCleanGit) {
        $dirty = git status --porcelain --untracked-files=all
        if ($dirty) { $dirty | Write-Host; throw 'git worktree is not clean' }
        Write-Host 'GIT_CLEAN=PASS'
    }
}
Write-Host 'PREFLIGHT=PASS'
