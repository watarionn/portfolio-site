from __future__ import annotations

import csv
import json
import re
import urllib.parse
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable


class ExtractionError(RuntimeError):
    pass


@dataclass
class Node:
    tag: str
    attrs: dict[str, str] = field(default_factory=dict)
    children: list["Node | str"] = field(default_factory=list)
    parent: "Node | None" = None

    def text(self) -> str:
        parts: list[str] = []
        for child in self.children:
            if isinstance(child, str):
                parts.append(child)
            else:
                parts.append(child.text())
        return normalize_text(" ".join(parts))

    def attr(self, name: str) -> str | None:
        return self.attrs.get(name.lower())

    def descendants(self) -> Iterable["Node"]:
        for child in self.children:
            if isinstance(child, Node):
                yield child
                yield from child.descendants()


class TreeBuilder(HTMLParser):
    VOID_TAGS = {
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr",
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = Node("document")
        self.stack = [self.root]

    def handle_starttag(self, tag: str, attrs) -> None:
        node = Node(
            tag=tag.lower(),
            attrs={str(k).lower(): "" if v is None else str(v) for k, v in attrs},
            parent=self.stack[-1],
        )
        self.stack[-1].children.append(node)
        if node.tag not in self.VOID_TAGS:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs) -> None:
        node = Node(
            tag=tag.lower(),
            attrs={str(k).lower(): "" if v is None else str(v) for k, v in attrs},
            parent=self.stack[-1],
        )
        self.stack[-1].children.append(node)

    def handle_endtag(self, tag: str) -> None:
        wanted = tag.lower()
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == wanted:
                del self.stack[index:]
                return

    def handle_data(self, data: str) -> None:
        if data:
            self.stack[-1].children.append(data)


@dataclass(frozen=True)
class AttrTest:
    name: str
    operator: str
    value: str


@dataclass(frozen=True)
class SimpleSelector:
    tag: str | None
    element_id: str | None
    classes: tuple[str, ...]
    attrs: tuple[AttrTest, ...]


@dataclass(frozen=True)
class FieldSpec:
    name: str
    selector: str
    source: str = "text"
    attr: str = ""
    regex: str = ""
    group: int = 0
    urljoin: bool = False
    default: str = ""


@dataclass(frozen=True)
class Recipe:
    name: str
    row_selector: str
    fields: tuple[FieldSpec, ...]
    base_url: str = ""


def normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def parse_html(text: str) -> Node:
    parser = TreeBuilder()
    parser.feed(text)
    parser.close()
    return parser.root


def _split_selector(selector: str) -> list[str]:
    tokens: list[str] = []
    buf: list[str] = []
    bracket_depth = 0
    quote: str | None = None

    for char in selector.strip():
        if quote:
            buf.append(char)
            if char == quote:
                quote = None
            continue
        if char in {"'", '"'}:
            quote = char
            buf.append(char)
            continue
        if char == "[":
            bracket_depth += 1
            buf.append(char)
            continue
        if char == "]":
            bracket_depth -= 1
            buf.append(char)
            continue
        if char.isspace() and bracket_depth == 0:
            if buf:
                tokens.append("".join(buf))
                buf = []
            continue
        buf.append(char)

    if buf:
        tokens.append("".join(buf))
    if not tokens:
        raise ExtractionError("selector is empty")
    return tokens


_ATTR_RE = re.compile(
    r"\[([A-Za-z_:][\w:.-]*)(?:\s*(=|\*=|~=)\s*(['\"]?)(.*?)\3)?\]"
)


def _parse_simple_selector(token: str) -> SimpleSelector:
    attrs: list[AttrTest] = []

    def repl(match: re.Match[str]) -> str:
        attrs.append(
            AttrTest(
                name=match.group(1).lower(),
                operator=match.group(2) or "exists",
                value=match.group(4) or "",
            )
        )
        return ""

    remainder = _ATTR_RE.sub(repl, token)
    if "[" in remainder or "]" in remainder:
        raise ExtractionError(f"unsupported attribute selector: {token}")

    id_match = re.search(r"#([A-Za-z_][\w-]*)", remainder)
    classes = tuple(re.findall(r"\.([A-Za-z_][\w-]*)", remainder))
    tag_match = re.match(r"^[A-Za-z][\w-]*|^\*", remainder)
    tag = tag_match.group(0).lower() if tag_match else None
    if tag == "*":
        tag = None

    cleaned = remainder
    if tag_match:
        cleaned = cleaned[tag_match.end():]
    cleaned = re.sub(r"#[A-Za-z_][\w-]*", "", cleaned)
    cleaned = re.sub(r"\.[A-Za-z_][\w-]*", "", cleaned)
    if cleaned:
        raise ExtractionError(f"unsupported selector syntax: {token}")

    return SimpleSelector(
        tag=tag,
        element_id=id_match.group(1) if id_match else None,
        classes=classes,
        attrs=tuple(attrs),
    )


def _matches(node: Node, selector: SimpleSelector) -> bool:
    if selector.tag and node.tag != selector.tag:
        return False
    if selector.element_id and node.attr("id") != selector.element_id:
        return False

    class_tokens = set((node.attr("class") or "").split())
    if any(item not in class_tokens for item in selector.classes):
        return False

    for test in selector.attrs:
        actual = node.attr(test.name)
        if test.operator == "exists":
            if actual is None:
                return False
        elif actual is None:
            return False
        elif test.operator == "=" and actual != test.value:
            return False
        elif test.operator == "*=" and test.value not in actual:
            return False
        elif test.operator == "~=" and test.value not in actual.split():
            return False
    return True


def select(root: Node, selector: str) -> list[Node]:
    current = [root]
    for raw_token in _split_selector(selector):
        simple = _parse_simple_selector(raw_token)
        next_nodes: list[Node] = []
        for candidate in current:
            for node in candidate.descendants():
                if _matches(node, simple):
                    next_nodes.append(node)
        current = next_nodes
    return current


def select_one(root: Node, selector: str) -> Node | None:
    rows = select(root, selector)
    return rows[0] if rows else None


def _field_value(row: Node, field: FieldSpec, base_url: str) -> str:
    node = select_one(row, field.selector) if field.selector else row
    if node is None:
        return field.default

    if field.source == "text":
        value = node.text()
    elif field.source == "attr":
        if not field.attr:
            raise ExtractionError(f"field {field.name!r} requires attr")
        value = node.attr(field.attr) or field.default
    else:
        raise ExtractionError(f"unsupported field source: {field.source}")

    if field.urljoin and value:
        value = urllib.parse.urljoin(base_url, value)

    if field.regex and value:
        match = re.search(field.regex, value)
        if not match:
            return field.default
        try:
            value = match.group(field.group)
        except IndexError as exc:
            raise ExtractionError(
                f"field {field.name!r} requested missing regex group {field.group}"
            ) from exc

    return normalize_text(value)


def extract_records(html_text: str, recipe: Recipe) -> list[dict[str, str]]:
    root = parse_html(html_text)
    rows = select(root, recipe.row_selector)
    output: list[dict[str, str]] = []

    for row in rows:
        record = {
            field.name: _field_value(row, field, recipe.base_url)
            for field in recipe.fields
        }
        output.append(record)
    return output


def recipe_from_dict(data: dict) -> Recipe:
    if not isinstance(data, dict):
        raise ExtractionError("recipe must be an object")
    name = str(data.get("name") or "").strip()
    row_selector = str(data.get("row_selector") or "").strip()
    fields_data = data.get("fields")

    if not name:
        raise ExtractionError("recipe name is required")
    if not row_selector:
        raise ExtractionError("row_selector is required")
    if not isinstance(fields_data, list) or not fields_data:
        raise ExtractionError("fields must be a non-empty list")

    fields: list[FieldSpec] = []
    seen_names: set[str] = set()
    for item in fields_data:
        if not isinstance(item, dict):
            raise ExtractionError("each field must be an object")
        field_name = str(item.get("name") or "").strip()
        if not field_name:
            raise ExtractionError("field name is required")
        if field_name in seen_names:
            raise ExtractionError(f"duplicate field name: {field_name}")
        seen_names.add(field_name)
        fields.append(
            FieldSpec(
                name=field_name,
                selector=str(item.get("selector") or "").strip(),
                source=str(item.get("source") or "text").strip(),
                attr=str(item.get("attr") or "").strip(),
                regex=str(item.get("regex") or ""),
                group=int(item.get("group", 0)),
                urljoin=bool(item.get("urljoin", False)),
                default=str(item.get("default") or ""),
            )
        )

    return Recipe(
        name=name,
        row_selector=row_selector,
        fields=tuple(fields),
        base_url=str(data.get("base_url") or "").strip(),
    )


def load_recipe(path: str | Path) -> Recipe:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return recipe_from_dict(data)


def read_html_file(path: str | Path) -> str:
    raw = Path(path).read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp932"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ExtractionError("HTML encoding is not UTF-8 or CP932")


def write_records(
    records: list[dict[str, str]],
    output: str | Path,
    *,
    format_name: str | None = None,
) -> Path:
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)

    fmt = (format_name or target.suffix.lstrip(".") or "tsv").lower()
    if fmt == "json":
        target.write_text(
            json.dumps(records, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return target

    if fmt not in {"csv", "tsv"}:
        raise ExtractionError(f"unsupported output format: {fmt}")
    delimiter = "," if fmt == "csv" else "\t"
    fieldnames = list(records[0].keys()) if records else []

    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter=delimiter)
        if fieldnames:
            writer.writeheader()
            writer.writerows(records)
    return target
