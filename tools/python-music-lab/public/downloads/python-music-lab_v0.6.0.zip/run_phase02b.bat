@echo off
setlocal
cd /d "%~dp0"
python src\phase02b_generate_and_rank.py
if errorlevel 1 (
  echo Phase 02B generation failed.
  exit /b 1
)
echo.
echo Phase 02B complete. See output\phase02b\manifest.json
endlocal
