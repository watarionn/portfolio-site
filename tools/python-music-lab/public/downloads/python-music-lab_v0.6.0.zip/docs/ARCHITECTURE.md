# Architecture

## 基本方針

Python作曲研究所では、作曲を次の層へ分離します。

1. Music Theory Layer
   - Key
   - Scale
   - Chord
   - Interval

2. Composition Layer
   - Harmony
   - Melody
   - Bass
   - Rhythm
   - Song Structure

3. Event Layer
   - Note start
   - Duration
   - Velocity
   - Channel

4. Rendering Layer
   - MIDI
   - Python Synth / WAV
   - AI Music Generator

この分離により、「作曲内容」と「音の鳴らし方」を独立して研究できます。

## Seed方針

自動生成処理はSeedを設定可能にし、気に入った結果を再現できることを原則とします。

## Phase 01の制限

- Major keyのみ
- 4/4拍子固定
- 8分音符中心の単純なメロディ
- General MIDIを利用

これは意図的な制限です。Phase 02以降で音楽理論と構成生成を追加します。

## Phase 03A Rendering Layer

Phase 03AからRendering Layerを実装する。

`mido`はMIDI event parsing、`numpy`は波形生成・mixingに使用する。外部General MIDI synthesizerには依存しない。

```text
MIDI -> TimedNote -> Voice -> ADSR -> Stereo Mixer -> PCM16 WAV
```

Noiseを含むdrum synthesisもevent由来seedで固定し、WAV byte-level reproducibilityを維持する。

Composition Layerは音色に依存しない。Phase 03B以降で音色を変更しても、Phase 02の作曲結果を変更せず再renderできる。

## Phase 03B Enhanced Rendering Layer

Phase 03BはPhase 03Aを置換せず、別rendererとして追加する。

```text
Phase 02B MIDI
  ├─ Phase 03A: reference deterministic dry renderer
  └─ Phase 03B: enhanced renderer
       ├─ layered oscillator palette
       ├─ track low-pass
       ├─ delay / reverb
       ├─ track balance
       ├─ soft saturation
       ├─ master WAV
       └─ optional OGG preview
```

`src/python_music_lab/synth.py`は03A referenceを保持し、03B固有処理は`src/python_music_lab/synth_fx.py`へ分離する。これにより音色改善で過去の基準レンダーを破壊しない。

Portfolio境界は`output/phase03b/portfolio_audio.json`。フロントエンドはこの静的JSONと音声ファイルだけを利用する。
